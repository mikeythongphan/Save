﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.SalesCoordinators
{
    public interface ICustomerCreditBureauService
    {
        CustomerCreditBureauViewModel GetById(int? Id);

        CustomerCreditBureauViewModel GetAll();

        //application_information GetApplicationInformation(int? Id);        

        void Create(CustomerCreditBureauViewModel obj);

        void Delete(CustomerCreditBureauViewModel obj);

        void Save();
    }
}
