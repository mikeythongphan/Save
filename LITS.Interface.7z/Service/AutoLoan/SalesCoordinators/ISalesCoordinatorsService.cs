﻿using System.Threading.Tasks;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Service.AutoLoan.SalesCoordinators
{
    public interface ISalesCoordinatorsService
    {
        Task<SalesCoordinatorsViewModel> LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Save(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Submit(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
