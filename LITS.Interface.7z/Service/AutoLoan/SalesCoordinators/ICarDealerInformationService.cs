﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.SalesCoordinators
{
    public interface ICarDealerInformationService
    {
        CarDealerInformationViewModel GetById(int? Id);

        CarDealerInformationViewModel GetAll();

        //application_information GetApplicationInformation(int? Id);        

        void Create(CarDealerInformationViewModel obj);

        void Delete(CarDealerInformationViewModel obj);

    }
}
