﻿using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface ILendingOperationService
    {
        LendingOperationViewModel LoadIndex(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel Save(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel Submit(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel SendBackSC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel LOModifySC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel LOModify(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel PrintApprovalLetter(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel PrintApprovalWorksheet(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
