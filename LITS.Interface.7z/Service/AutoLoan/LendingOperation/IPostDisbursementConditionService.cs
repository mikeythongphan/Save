﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface IPostDisbursementConditionService
    {
        PostDisbursementConditionViewModel GetById(int? Id);

        PostDisbursementConditionViewModel GetAll();

        // application_information GetDisbursementInformation(int? Id);

        void Create(PostDisbursementConditionViewModel obj);

        void Delete(PostDisbursementConditionViewModel obj);

        void Update(PostDisbursementConditionViewModel obj);
    }
}
