﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface IInsuranceService
    {
        InsuranceViewModel LoadIndex(InsuranceViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        InsuranceViewModel Save(InsuranceViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
