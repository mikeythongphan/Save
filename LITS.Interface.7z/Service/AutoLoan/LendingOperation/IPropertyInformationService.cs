﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface IPropertyInformationService
    {
        PropertyInformationViewModel LoadIndex(PropertyInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        PropertyInformationViewModel Save(PropertyInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
