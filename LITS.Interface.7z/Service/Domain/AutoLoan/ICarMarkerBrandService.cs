﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Interface.Service.Domain.AutoLoan
{
    public interface ICarMarkerBrandService
    {
        List<CarMarkerBrandViewModel> GetListAll();

        List<CarMarkerBrandViewModel> GetListById(int? Id);

        List<CarMarkerBrandViewModel> GetListByStatusId(int? StatusId);

        List<CarMarkerBrandViewModel> GetListByTypeId(int? TypeId);

        List<CarMarkerBrandViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarMarkerBrandViewModel> GetListActiveAll();

        List<CarMarkerBrandViewModel> GetListActiveById(int? Id);

        List<CarMarkerBrandViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarMarkerBrandViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarMarkerBrandViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarMarkerBrandViewModel objModel);

        bool Update(CarMarkerBrandViewModel objModel);

        bool Delete(CarMarkerBrandViewModel objModel);
    }
}
