﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Interface.Service.Domain.AutoLoan
{
    public interface ICarDealerService
    {
        List<CarDealerViewModel> GetListAll();

        List<CarDealerViewModel> GetListById(int? Id);

        List<CarDealerViewModel> GetListByStatusId(int? StatusId);

        List<CarDealerViewModel> GetListByTypeId(int? TypeId);

        List<CarDealerViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarDealerViewModel> GetListActiveAll();

        List<CarDealerViewModel> GetListActiveById(int? Id);

        List<CarDealerViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarDealerViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarDealerViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarDealerViewModel objModel);

        bool Update(CarDealerViewModel objModel);

        bool Delete(CarDealerViewModel objModel);
    }
}
