﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Interface.Service.Domain.AutoLoan
{
    public interface ICarSalesInformationService
    {
        List<CarSalesInformationViewModel> GetListAll();

        List<CarSalesInformationViewModel> GetListById(int? Id);

        List<CarSalesInformationViewModel> GetListByStatusId(int? StatusId);

        List<CarSalesInformationViewModel> GetListByTypeId(int? TypeId);

        List<CarSalesInformationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarSalesInformationViewModel> GetListActiveAll();

        List<CarSalesInformationViewModel> GetListActiveById(int? Id);

        List<CarSalesInformationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarSalesInformationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarSalesInformationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarSalesInformationViewModel objModel);

        bool Update(CarSalesInformationViewModel objModel);

        bool Delete(CarSalesInformationViewModel objModel);
    }
}
