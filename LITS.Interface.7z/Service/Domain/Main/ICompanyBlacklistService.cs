﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Interface.Service.Domain.Main
{
    public interface ICompanyBlacklistService
    {
        List<CompanyBlacklistViewModel> GetListAll();

        List<CompanyBlacklistViewModel> GetListById(int? Id);

        List<CompanyBlacklistViewModel> GetListByStatusId(int? StatusId);

        List<CompanyBlacklistViewModel> GetListByTypeId(int? TypeId);

        List<CompanyBlacklistViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CompanyBlacklistViewModel> GetListActiveAll();

        List<CompanyBlacklistViewModel> GetListActiveById(int? Id);

        List<CompanyBlacklistViewModel> GetListActiveByStatusId(int? StatusId);

        List<CompanyBlacklistViewModel> GetListActiveByTypeId(int? TypeId);

        List<CompanyBlacklistViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CompanyBlacklistViewModel objModel);

        bool Update(CompanyBlacklistViewModel objModel);

        bool Delete(CompanyBlacklistViewModel objModel);
    }
}
