﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Interface.Service.Domain.Main
{
    public interface ICustomerBlacklistService
    {
        List<CustomerBlacklistViewModel> GetListAll();

        List<CustomerBlacklistViewModel> GetListById(int? Id);

        List<CustomerBlacklistViewModel> GetListByStatusId(int? StatusId);

        List<CustomerBlacklistViewModel> GetListByTypeId(int? TypeId);

        List<CustomerBlacklistViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerBlacklistViewModel> GetListActiveAll();

        List<CustomerBlacklistViewModel> GetListActiveById(int? Id);

        List<CustomerBlacklistViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerBlacklistViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerBlacklistViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerBlacklistViewModel objModel);

        bool Update(CustomerBlacklistViewModel objModel);

        bool Delete(CustomerBlacklistViewModel objModel);
    }
}
