﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.WorkInProgress
{
    public interface IWorkInProgressService
    {
        Task<WorkInProgressViewModel> LoadIndex(WorkInProgressViewModel obj, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> SearchData(WorkInProgressViewModel obj , string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel obj, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> VisibleControl(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> ReadonlyControl(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> LoadMetaData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
