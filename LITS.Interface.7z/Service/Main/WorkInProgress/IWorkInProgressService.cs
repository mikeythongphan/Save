﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.WorkInProgress
{
    public interface IWorkInProgressService
    {
        WorkInProgressViewModel LoadIndex(WorkInProgressViewModel obj, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        WorkInProgressViewModel SearchData(WorkInProgressViewModel obj , string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        WorkInProgressViewModel LoadChildDetail(WorkInProgressViewModel obj, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
