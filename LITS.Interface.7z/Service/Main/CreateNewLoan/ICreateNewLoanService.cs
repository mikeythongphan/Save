﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.CreateNewLoan
{
    public interface ICreateNewLoanService
    {
        Task<CreateNewLoanViewModel> LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> VisibleControl(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> ReadonlyControl(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadMetaData(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadMetaDataStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadMetaDataStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadMetaDataStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
