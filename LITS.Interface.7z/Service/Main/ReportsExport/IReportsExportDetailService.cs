﻿using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Interface.Service.Main.ReportsExport
{
    public interface IReportsExportDetailService
    {
        ReportsExportDetailViewModel GetById(int? Id);

        ReportsExportDetailViewModel GetAll();      

        void Create(ReportsExportDetailViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
