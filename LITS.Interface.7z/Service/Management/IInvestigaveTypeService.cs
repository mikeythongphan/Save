﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IInvestigaveTypeService
    {
        List<InvestigaveTypeViewModel> GetListAll();

        List<InvestigaveTypeViewModel> GetListById(int? Id);

        List<InvestigaveTypeViewModel> GetListByStatusId(int? StatusId);

        List<InvestigaveTypeViewModel> GetListByTypeId(int? TypeId);

        List<InvestigaveTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<InvestigaveTypeViewModel> GetListActiveAll();

        List<InvestigaveTypeViewModel> GetListActiveById(int? Id);

        List<InvestigaveTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<InvestigaveTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<InvestigaveTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(InvestigaveTypeViewModel objModel);

        bool Update(InvestigaveTypeViewModel objModel);

        bool Delete(InvestigaveTypeViewModel objModel);
    }
}
