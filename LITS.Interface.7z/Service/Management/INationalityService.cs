﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface INationalityService
    {
        List<NationalityViewModel> GetListAll();

        List<NationalityViewModel> GetListById(int? Id);

        List<NationalityViewModel> GetListByStatusId(int? StatusId);

        List<NationalityViewModel> GetListByTypeId(int? TypeId);

        List<NationalityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<NationalityViewModel> GetListActiveAll();

        List<NationalityViewModel> GetListActiveById(int? Id);

        List<NationalityViewModel> GetListActiveByStatusId(int? StatusId);

        List<NationalityViewModel> GetListActiveByTypeId(int? TypeId);

        List<NationalityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(NationalityViewModel objModel);

        bool Update(NationalityViewModel objModel);

        bool Delete(NationalityViewModel objModel);
    }
}
