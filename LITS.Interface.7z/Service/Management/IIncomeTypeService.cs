﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IIncomeTypeService
    {
        List<IncomeTypeViewModel> GetListAll();

        List<IncomeTypeViewModel> GetListById(int? Id);

        List<IncomeTypeViewModel> GetListByStatusId(int? StatusId);

        List<IncomeTypeViewModel> GetListByTypeId(int? TypeId);

        List<IncomeTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<IncomeTypeViewModel> GetListActiveAll();

        List<IncomeTypeViewModel> GetListActiveById(int? Id);

        List<IncomeTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<IncomeTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<IncomeTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(IncomeTypeViewModel objModel);

        bool Update(IncomeTypeViewModel objModel);

        bool Delete(IncomeTypeViewModel objModel);
    }
}
