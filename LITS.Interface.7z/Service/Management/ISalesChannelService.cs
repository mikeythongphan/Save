﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ISalesChannelService
    {
        List<SalesChannelViewModel> GetListAll();

        List<SalesChannelViewModel> GetListById(int? Id);

        List<SalesChannelViewModel> GetListByStatusId(int? StatusId);

        List<SalesChannelViewModel> GetListByTypeId(int? TypeId);

        List<SalesChannelViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SalesChannelViewModel> GetListActiveAll();

        List<SalesChannelViewModel> GetListActiveById(int? Id);

        List<SalesChannelViewModel> GetListActiveByStatusId(int? StatusId);

        List<SalesChannelViewModel> GetListActiveByTypeId(int? TypeId);

        List<SalesChannelViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(SalesChannelViewModel objModel);

        bool Update(SalesChannelViewModel objModel);

        bool Delete(SalesChannelViewModel objModel);
    }
}
