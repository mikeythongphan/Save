﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface IProgramTypeService
    {
        List<ProgramTypeViewModel> GetListAll();

        List<ProgramTypeViewModel> GetListById(int? Id);

        List<ProgramTypeViewModel> GetListByStatusId(int? StatusId);

        List<ProgramTypeViewModel> GetListByTypeId(int? TypeId);

        List<ProgramTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ProgramTypeViewModel> GetListActiveAll();

        List<ProgramTypeViewModel> GetListActiveById(int? Id);

        List<ProgramTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<ProgramTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<ProgramTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ProgramTypeViewModel objModel);

        bool Update(ProgramTypeViewModel objModel);

        bool Delete(ProgramTypeViewModel objModel);
    }
}
