﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ICustomerSegmentService
    {
        List<CustomerSegmentViewModel> GetListAll();

        List<CustomerSegmentViewModel> GetListById(int? Id);

        List<CustomerSegmentViewModel> GetListByStatusId(int? StatusId);

        List<CustomerSegmentViewModel> GetListByTypeId(int? TypeId);

        List<CustomerSegmentViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerSegmentViewModel> GetListActiveAll();

        List<CustomerSegmentViewModel> GetListActiveById(int? Id);

        List<CustomerSegmentViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerSegmentViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerSegmentViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerSegmentViewModel objModel);

        bool Update(CustomerSegmentViewModel objModel);

        bool Delete(CustomerSegmentViewModel objModel);
    }
}
