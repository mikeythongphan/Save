﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICompanyCodeService
    {
        List<CompanyCodeViewModel> GetListAll();

        List<CompanyCodeViewModel> GetListById(int? Id);

        List<CompanyCodeViewModel> GetListByStatusId(int? StatusId);

        List<CompanyCodeViewModel> GetListByTypeId(int? TypeId);

        List<CompanyCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CompanyCodeViewModel> GetListActiveAll();

        List<CompanyCodeViewModel> GetListActiveById(int? Id);

        List<CompanyCodeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CompanyCodeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CompanyCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CompanyCodeViewModel objModel);

        bool Update(CompanyCodeViewModel objModel);

        bool Delete(CompanyCodeViewModel objModel);
    }
}
