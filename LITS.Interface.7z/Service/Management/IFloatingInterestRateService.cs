﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IFloatingInterestRateService
    {
        List<FloatingInterestRateViewModel> GetListAll();

        List<FloatingInterestRateViewModel> GetListById(int? Id);

        List<FloatingInterestRateViewModel> GetListByStatusId(int? StatusId);

        List<FloatingInterestRateViewModel> GetListByTypeId(int? TypeId);

        List<FloatingInterestRateViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<FloatingInterestRateViewModel> GetListActiveAll();

        List<FloatingInterestRateViewModel> GetListActiveById(int? Id);

        List<FloatingInterestRateViewModel> GetListActiveByStatusId(int? StatusId);

        List<FloatingInterestRateViewModel> GetListActiveByTypeId(int? TypeId);

        List<FloatingInterestRateViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(FloatingInterestRateViewModel objModel);

        bool Update(FloatingInterestRateViewModel objModel);

        bool Delete(FloatingInterestRateViewModel objModel);
    }
}
