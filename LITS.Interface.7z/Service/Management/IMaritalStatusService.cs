﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IMaritalStatusService
    {
        List<MaritalStatusViewModel> GetListAll();

        List<MaritalStatusViewModel> GetListById(int? Id);

        List<MaritalStatusViewModel> GetListByStatusId(int? StatusId);

        List<MaritalStatusViewModel> GetListByTypeId(int? TypeId);

        List<MaritalStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<MaritalStatusViewModel> GetListActiveAll();

        List<MaritalStatusViewModel> GetListActiveById(int? Id);

        List<MaritalStatusViewModel> GetListActiveByStatusId(int? StatusId);

        List<MaritalStatusViewModel> GetListActiveByTypeId(int? TypeId);

        List<MaritalStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(MaritalStatusViewModel objModel);

        bool Update(MaritalStatusViewModel objModel);

        bool Delete(MaritalStatusViewModel objModel);
    }
}
