﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IEmploymentTypeRepository : IRepository<m_employment_type>
    {
        List<EmploymentTypeViewModel> GetListAll();

        List<EmploymentTypeViewModel> GetListById(int? Id);

        List<EmploymentTypeViewModel> GetListByStatusId(int? StatusId);

        List<EmploymentTypeViewModel> GetListByTypeId(int? TypeId);

        List<EmploymentTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<EmploymentTypeViewModel> GetListActiveAll();

        List<EmploymentTypeViewModel> GetListActiveById(int? Id);

        List<EmploymentTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<EmploymentTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<EmploymentTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(EmploymentTypeViewModel objModel);

        bool Update(EmploymentTypeViewModel objModel);

        bool Delete(EmploymentTypeViewModel objModel);
    }
}
