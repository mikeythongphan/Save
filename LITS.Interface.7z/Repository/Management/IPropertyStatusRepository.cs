﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPropertyStatusRepository : IRepository<m_property_status>
    {
        List<PropertyStatusViewModel> GetListAll();

        List<PropertyStatusViewModel> GetListById(int? Id);

        List<PropertyStatusViewModel> GetListByStatusId(int? StatusId);

        List<PropertyStatusViewModel> GetListByTypeId(int? TypeId);

        List<PropertyStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PropertyStatusViewModel> GetListActiveAll();

        List<PropertyStatusViewModel> GetListActiveById(int? Id);

        List<PropertyStatusViewModel> GetListActiveByStatusId(int? StatusId);

        List<PropertyStatusViewModel> GetListActiveByTypeId(int? TypeId);

        List<PropertyStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PropertyStatusViewModel objModel);

        bool Update(PropertyStatusViewModel objModel);

        bool Delete(PropertyStatusViewModel objModel);
    }
}
