﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ILoanTrendRepository : IRepository<m_loan_trend>
    {
        List<LoanTrendViewModel> GetListAll();

        List<LoanTrendViewModel> GetListById(int? Id);

        List<LoanTrendViewModel> GetListByStatusId(int? StatusId);

        List<LoanTrendViewModel> GetListByTypeId(int? TypeId);

        List<LoanTrendViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<LoanTrendViewModel> GetListActiveAll();

        List<LoanTrendViewModel> GetListActiveById(int? Id);

        List<LoanTrendViewModel> GetListActiveByStatusId(int? StatusId);

        List<LoanTrendViewModel> GetListActiveByTypeId(int? TypeId);

        List<LoanTrendViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(LoanTrendViewModel objModel);

        bool Update(LoanTrendViewModel objModel);

        bool Delete(LoanTrendViewModel objModel);
    }
}
