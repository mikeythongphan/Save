﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IMessageTypeRepository : IRepository<m_message_type>
    {
        List<MessageTypeViewModel> GetListAll();

        List<MessageTypeViewModel> GetListById(int? Id);

        List<MessageTypeViewModel> GetListByStatusId(int? StatusId);

        List<MessageTypeViewModel> GetListByTypeId(int? TypeId);

        List<MessageTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<MessageTypeViewModel> GetListActiveAll();

        List<MessageTypeViewModel> GetListActiveById(int? Id);

        List<MessageTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<MessageTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<MessageTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(MessageTypeViewModel objModel);

        bool Update(MessageTypeViewModel objModel);

        bool Delete(MessageTypeViewModel objModel);
    }
}
