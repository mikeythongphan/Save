﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICreditDeviationRepository : IRepository<m_credit_deviation>
    {
        List<CreditDeviationViewModel> GetListAll();

        List<CreditDeviationViewModel> GetListById(int? Id);

        List<CreditDeviationViewModel> GetListByStatusId(int? StatusId);

        List<CreditDeviationViewModel> GetListByTypeId(int? TypeId);

        List<CreditDeviationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CreditDeviationViewModel> GetListActiveAll();

        List<CreditDeviationViewModel> GetListActiveById(int? Id);

        List<CreditDeviationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CreditDeviationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CreditDeviationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CreditDeviationViewModel objModel);

        bool Update(CreditDeviationViewModel objModel);

        bool Delete(CreditDeviationViewModel objModel);
    }
}
