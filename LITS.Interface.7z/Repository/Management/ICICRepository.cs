﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICICRepository : IRepository<m_cic>
    {
        List<CicViewModel> GetListAll();

        List<CicViewModel> GetListById(int? Id);

        List<CicViewModel> GetListByStatusId(int? StatusId);

        List<CicViewModel> GetListByTypeId(int? TypeId);

        List<CicViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CicViewModel> GetListActiveAll();

        List<CicViewModel> GetListActiveById(int? Id);

        List<CicViewModel> GetListActiveByStatusId(int? StatusId);

        List<CicViewModel> GetListActiveByTypeId(int? TypeId);

        List<CicViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CicViewModel objModel);

        bool Update(CicViewModel objModel);

        bool Delete(CicViewModel objModel);
    }
}
