﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IBusinessTypeRepository : IRepository<m_business_type>
    {
        List<BusinessTypeViewModel> GetListAll();

        List<BusinessTypeViewModel> GetListById(int? Id);

        List<BusinessTypeViewModel> GetListByStatusId(int? StatusId);

        List<BusinessTypeViewModel> GetListByTypeId(int? TypeId);

        List<BusinessTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BusinessTypeViewModel> GetListActiveAll();

        List<BusinessTypeViewModel> GetListActiveById(int? Id);

        List<BusinessTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<BusinessTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<BusinessTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BusinessTypeViewModel objModel);

        bool Update(BusinessTypeViewModel objModel);

        bool Delete(BusinessTypeViewModel objModel);
    }
}
