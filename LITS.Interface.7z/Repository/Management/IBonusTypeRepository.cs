﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IBonusTypeRepository : IRepository<m_bonus_type>
    {
        List<BonusTypeViewModel> GetListAll();

        List<BonusTypeViewModel> GetListById(int? Id);

        List<BonusTypeViewModel> GetListByStatusId(int? StatusId);

        List<BonusTypeViewModel> GetListByTypeId(int? TypeId);

        List<BonusTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BonusTypeViewModel> GetListActiveAll();

        List<BonusTypeViewModel> GetListActiveById(int? Id);

        List<BonusTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<BonusTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<BonusTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BonusTypeViewModel objModel);

        bool Update(BonusTypeViewModel objModel);

        bool Delete(BonusTypeViewModel objModel);
    }
}
