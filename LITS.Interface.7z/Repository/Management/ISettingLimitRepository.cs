﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ISettingLimitRepository : IRepository<m_setting_limit>
    {
        List<SettingLimitViewModel> GetListAll();

        List<SettingLimitViewModel> GetListById(int? Id);

        List<SettingLimitViewModel> GetListByStatusId(int? StatusId);

        List<SettingLimitViewModel> GetListByTypeId(int? TypeId);

        List<SettingLimitViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SettingLimitViewModel> GetListActiveAll();

        List<SettingLimitViewModel> GetListActiveById(int? Id);

        List<SettingLimitViewModel> GetListActiveByStatusId(int? StatusId);

        List<SettingLimitViewModel> GetListActiveByTypeId(int? TypeId);

        List<SettingLimitViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SettingLimitViewModel> GetListByParentId(int? ParentId);

        List<SettingLimitViewModel> GetListActiveByParentId(int? ParentId);

        bool Create(SettingLimitViewModel objModel);

        bool Update(SettingLimitViewModel objModel);

        bool Delete(SettingLimitViewModel objModel);
    }
}
