﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IDuplicationTypeRepository : IRepository<m_duplication_type>
    {
        List<DuplicationTypeViewModel> GetListAll();

        List<DuplicationTypeViewModel> GetListById(int? Id);

        List<DuplicationTypeViewModel> GetListByStatusId(int? StatusId);

        List<DuplicationTypeViewModel> GetListByTypeId(int? TypeId);

        List<DuplicationTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DuplicationTypeViewModel> GetListActiveAll();

        List<DuplicationTypeViewModel> GetListActiveById(int? Id);

        List<DuplicationTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<DuplicationTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<DuplicationTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(DuplicationTypeViewModel objModel);

        bool Update(DuplicationTypeViewModel objModel);

        bool Delete(DuplicationTypeViewModel objModel);
    }
}
