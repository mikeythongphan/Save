﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ISettingEqualRepository : IRepository<m_setting_equal>
    {
        List<SettingEqualViewModel> GetListAll();

        List<SettingEqualViewModel> GetListById(int? Id);

        List<SettingEqualViewModel> GetListByStatusId(int? StatusId);

        List<SettingEqualViewModel> GetListByTypeId(int? TypeId);

        List<SettingEqualViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SettingEqualViewModel> GetListActiveAll();

        List<SettingEqualViewModel> GetListActiveById(int? Id);

        List<SettingEqualViewModel> GetListActiveByStatusId(int? StatusId);

        List<SettingEqualViewModel> GetListActiveByTypeId(int? TypeId);

        List<SettingEqualViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SettingEqualViewModel> GetListByParentId(int? ParentId);

        List<SettingEqualViewModel> GetListActiveByParentId(int? ParentId);

        bool Create(SettingEqualViewModel objModel);

        bool Update(SettingEqualViewModel objModel);

        bool Delete(SettingEqualViewModel objModel);
    }
}
