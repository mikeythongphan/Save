﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IDefinitionTypeRepository : IRepository<m_definition_type>
    {
        List<DefinitionTypeViewModel> GetListAll();

        List<DefinitionTypeViewModel> GetListById(int? Id);

        List<DefinitionTypeViewModel> GetListByStatusId(int? StatusId);

        List<DefinitionTypeViewModel> GetListByTypeId(int? TypeId);

        List<DefinitionTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DefinitionTypeViewModel> GetListByParentId(int? ParentId);

        List<DefinitionTypeViewModel> GetListByGroupId(int? GroupId);

        List<DefinitionTypeViewModel> GetListActiveAll();

        List<DefinitionTypeViewModel> GetListActiveById(int? Id);

        List<DefinitionTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<DefinitionTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<DefinitionTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DefinitionTypeViewModel> GetListActiveByParentId(int? ParentId);

        List<DefinitionTypeViewModel> GetListActiveByGroupId(int? GroupId);

        bool Create(DefinitionTypeViewModel objModel);

        bool Update(DefinitionTypeViewModel objModel);

        bool Delete(DefinitionTypeViewModel objModel);
    }
}
