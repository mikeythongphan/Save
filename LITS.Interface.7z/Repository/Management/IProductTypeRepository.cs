﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IProductTypeRepository : IRepository<m_product_type>
    {
        List<ProductTypeViewModel> GetListAll();

        List<ProductTypeViewModel> GetListById(int? Id);

        List<ProductTypeViewModel> GetListByStatusId(int? StatusId);

        List<ProductTypeViewModel> GetListByTypeId(int? TypeId);

        List<ProductTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ProductTypeViewModel> GetListActiveAll();

        List<ProductTypeViewModel> GetListActiveById(int? Id);

        List<ProductTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<ProductTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<ProductTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ProductTypeViewModel objModel);

        bool Update(ProductTypeViewModel objModel);

        bool Delete(ProductTypeViewModel objModel);
    }
}
