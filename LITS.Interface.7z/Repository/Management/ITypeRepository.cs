﻿using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.Views.Management;

namespace LITS.Interface.Repository.Management
{
    public interface ITypeRepository : IRepository<m_type>
    {
        List<TypeViewModel> GetListAll();

        List<TypeViewModel> GetListById(int? Id);        

        List<TypeViewModel> GetListByParentId(int? ParentId);        

        List<TypeViewModel> GetListActiveAll();

        List<TypeViewModel> GetListActiveById(int? Id);        

        List<TypeViewModel> GetListActiveByParentId(int? ParentId);        

        bool Create(TypeViewModel objModel);

        bool Update(TypeViewModel objModel);

        bool Delete(TypeViewModel objModel);
    }
}
