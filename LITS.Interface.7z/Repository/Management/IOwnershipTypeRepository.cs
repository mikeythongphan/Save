﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IOwnershipTypeRepository : IRepository<m_ownership_type>
    {
        List<OwnershipTypeViewModel> GetListAll();

        List<OwnershipTypeViewModel> GetListById(int? Id);

        List<OwnershipTypeViewModel> GetListByStatusId(int? StatusId);

        List<OwnershipTypeViewModel> GetListByTypeId(int? TypeId);

        List<OwnershipTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<OwnershipTypeViewModel> GetListActiveAll();

        List<OwnershipTypeViewModel> GetListActiveById(int? Id);

        List<OwnershipTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<OwnershipTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<OwnershipTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(OwnershipTypeViewModel objModel);

        bool Update(OwnershipTypeViewModel objModel);

        bool Delete(OwnershipTypeViewModel objModel);
    }
}
