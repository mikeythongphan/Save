﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IDisbursalScenarioConditionRepository : IRepository<m_disbursal_scenario_condition>
    {
        List<DisbursalScenarioConditionViewModel> GetListAll();

        List<DisbursalScenarioConditionViewModel> GetListById(int? Id);

        List<DisbursalScenarioConditionViewModel> GetListByStatusId(int? StatusId);

        List<DisbursalScenarioConditionViewModel> GetListByTypeId(int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListActiveAll();

        List<DisbursalScenarioConditionViewModel> GetListActiveById(int? Id);

        List<DisbursalScenarioConditionViewModel> GetListActiveByStatusId(int? StatusId);

        List<DisbursalScenarioConditionViewModel> GetListActiveByTypeId(int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(DisbursalScenarioConditionViewModel objModel);

        bool Update(DisbursalScenarioConditionViewModel objModel);

        bool Delete(DisbursalScenarioConditionViewModel objModel);
    }
}
