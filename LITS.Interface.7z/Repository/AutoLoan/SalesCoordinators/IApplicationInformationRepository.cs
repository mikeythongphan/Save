﻿using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface IApplicationInformationRepository : IRepository<ApplicationInformationViewModel>
    {
        Task<ApplicationInformationViewModel> LoadIndex(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<ApplicationInformationViewModel> Save(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
