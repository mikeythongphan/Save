﻿using System;
using System.Linq;
using System.Threading.Tasks;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Factory;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface ICustomerDemostrationRepository : IRepository<CustomerDemostrationViewModel>
    {
        Task<CustomerDemostrationViewModel> LoadIndex(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CustomerDemostrationViewModel> Save(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
