﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface ICustomerInformationRepository : IRepository<CustomerInformationViewModel>
    {
        Task<CustomerInformationViewModel> LoadIndex(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CustomerInformationViewModel> Save(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
