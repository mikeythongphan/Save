﻿using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface ISalesCoordinatorsRepository : IRepository<SalesCoordinatorsViewModel>
    {
        Task<SalesCoordinatorsViewModel> LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Save (SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Submit (SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<SalesCoordinatorsViewModel> FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
