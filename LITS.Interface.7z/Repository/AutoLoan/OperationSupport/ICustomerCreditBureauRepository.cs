﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface ICustomerCreditBureauRepository : IRepository<CustomerCreditBureauViewModel>
    {
        CustomerCreditBureauViewModel LoadIndex(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CustomerCreditBureauViewModel Save(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
