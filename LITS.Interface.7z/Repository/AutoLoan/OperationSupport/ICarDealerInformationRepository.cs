﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface ICarDealerInformationRepository : IRepository<CarDealerInformationViewModel>
    {
        CarDealerInformationViewModel LoadIndex(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CarDealerInformationViewModel Save(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
