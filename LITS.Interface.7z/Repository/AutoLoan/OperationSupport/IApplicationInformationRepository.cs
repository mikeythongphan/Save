﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface IApplicationInformationRepository : IRepository<ApplicationInformationViewModel>
    {
        ApplicationInformationViewModel LoadIndex(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        ApplicationInformationViewModel Save(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
