﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Interface.Repository.AutoLoan.LendingOperation
{
    public interface IPostDisbursementConditionRepository : IRepository<PostDisbursementConditionViewModel>
    {
        PostDisbursementConditionViewModel LoadIndex(PostDisbursementConditionViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        PostDisbursementConditionViewModel Save(PostDisbursementConditionViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
