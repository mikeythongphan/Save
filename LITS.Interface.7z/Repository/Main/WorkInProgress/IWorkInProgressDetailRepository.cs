﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Interface.Repository.Main.WorkInProgress
{
    public interface IWorkInProgressDetailRepository : IRepository<WorkInProgressDetailViewModel>
    { }
}
