﻿using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.WorkInProgress
{
    public interface IWorkInProgressDetailRepository : IRepository<WorkInProgressDetailViewModel>
    {
        Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
