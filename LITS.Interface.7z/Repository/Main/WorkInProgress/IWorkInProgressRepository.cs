﻿using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.WorkInProgress
{
    public interface IWorkInProgressRepository : IRepository<WorkInProgressViewModel>
    {
        Task<WorkInProgressViewModel> LoadIndex(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> SearchData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
