﻿
using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.WorkInProgress
{
    public interface IWorkInProgressRepository : IRepository<WorkInProgressViewModel>
    {
        WorkInProgressViewModel SearchData(WorkInProgressViewModel obj, string strAreaName, string strControllerName);

        WorkInProgressViewModel LoadChildDetail(int appId, string strAreaName, string strControllerName);
    }
}
