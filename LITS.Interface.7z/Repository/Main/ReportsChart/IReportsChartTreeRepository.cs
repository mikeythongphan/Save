﻿using LITS.Infrastructure.Factory;
using System.Collections.Generic;
using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Interface.Repository.Main.ReportsChart
{
    public interface IReportsChartTreeRepository : IRepository<ReportsChartTreeViewModel>
    {
        List<ReportsChartTreeViewModel> GetListTreeProductIsActive();
    }
}
