﻿using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.ReportsChart
{
    public interface IReportsChartRepository : IRepository<ReportsChartViewModel>
    {
        ReportsChartViewModel SearchData(ReportsChartViewModel obj, string strAreaName, string strControllerName);
    }
}
