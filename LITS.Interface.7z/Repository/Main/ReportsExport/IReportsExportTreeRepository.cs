﻿using LITS.Infrastructure.Factory;
using System.Collections.Generic;
using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Interface.Repository.Main.ReportsExport
{
    public interface IReportsExportTreeRepository : IRepository<ReportsExportTreeViewModel>
    {
        List<ReportsExportTreeViewModel> GetListTreeProductIsActive();
    }
}
