﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Interface.Repository.Main.ReportsExport
{
    public interface IReportsExportDetailRepository : IRepository<ReportsExportDetailViewModel>
    {
    }
}
