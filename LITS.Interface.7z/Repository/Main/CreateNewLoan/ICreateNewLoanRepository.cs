﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.CreateNewLoan
{
    public interface ICreateNewLoanRepository : IRepository<CreateNewLoanViewModel>
    {
        Task<CreateNewLoanViewModel> LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        Task<CreateNewLoanViewModel> LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel GetApplicationNextAppNo(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CheckBlackList(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CheckDeDuplicate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewApplication(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewCustomer(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewCustomerIdentification(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewAutoLoanPersonal(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewAutoLoanCorporate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewCustomerAutoLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewCompanyCorporate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewCompanyPersonal(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewLegalRepresentative(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel CreateNewLegalRepresentativeIdentification(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
