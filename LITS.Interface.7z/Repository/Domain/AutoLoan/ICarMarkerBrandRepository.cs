﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.AutoLoan
{
    public interface ICarMarkerBrandRepository : IRepository<al_car_marker_brand>
    {
        List<CarMarkerBrandViewModel> GetListAll();

        List<CarMarkerBrandViewModel> GetListById(int? Id);

        List<CarMarkerBrandViewModel> GetListByStatusId(int? StatusId);

        List<CarMarkerBrandViewModel> GetListByTypeId(int? TypeId);

        List<CarMarkerBrandViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarMarkerBrandViewModel> GetListActiveAll();

        List<CarMarkerBrandViewModel> GetListActiveById(int? Id);

        List<CarMarkerBrandViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarMarkerBrandViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarMarkerBrandViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarMarkerBrandViewModel objModel);

        bool Update(CarMarkerBrandViewModel objModel);

        bool Delete(CarMarkerBrandViewModel objModel);
    }
}
