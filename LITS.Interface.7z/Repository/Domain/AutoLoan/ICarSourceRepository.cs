﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.AutoLoan
{
    interface ICarSourceRepository : IRepository<al_car_source>
    {
        List<CarSourceViewModel> GetListAll();

        List<CarSourceViewModel> GetListById(int? Id);

        List<CarSourceViewModel> GetListByStatusId(int? StatusId);

        List<CarSourceViewModel> GetListByTypeId(int? TypeId);

        List<CarSourceViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarSourceViewModel> GetListActiveAll();

        List<CarSourceViewModel> GetListActiveById(int? Id);

        List<CarSourceViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarSourceViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarSourceViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarSourceViewModel objModel);

        bool Update(CarSourceViewModel objModel);

        bool Delete(CarSourceViewModel objModel);
    }
}
