﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.AutoLoan
{
    public interface ICarModelRepository : IRepository<al_car_model>
    {
        List<CarModelViewModel> GetListAll();

        List<CarModelViewModel> GetListById(int? Id);

        List<CarModelViewModel> GetListByStatusId(int? StatusId);

        List<CarModelViewModel> GetListByTypeId(int? TypeId);

        List<CarModelViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarModelViewModel> GetListActiveAll();

        List<CarModelViewModel> GetListActiveById(int? Id);

        List<CarModelViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarModelViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarModelViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarModelViewModel objModel);

        bool Update(CarModelViewModel objModel);

        bool Delete(CarModelViewModel objModel);
    }
}
