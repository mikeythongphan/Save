﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.AutoLoan
{
    public interface ICarSalesInformationRepository : IRepository<al_car_sales_information>
    {
        List<CarSalesInformationViewModel> GetListAll();

        List<CarSalesInformationViewModel> GetListById(int? Id);

        List<CarSalesInformationViewModel> GetListByStatusId(int? StatusId);

        List<CarSalesInformationViewModel> GetListByTypeId(int? TypeId);

        List<CarSalesInformationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarSalesInformationViewModel> GetListActiveAll();

        List<CarSalesInformationViewModel> GetListActiveById(int? Id);

        List<CarSalesInformationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarSalesInformationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarSalesInformationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarSalesInformationViewModel objModel);

        bool Update(CarSalesInformationViewModel objModel);

        bool Delete(CarSalesInformationViewModel objModel);
    }
}
