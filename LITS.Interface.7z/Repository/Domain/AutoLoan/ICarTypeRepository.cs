﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.AutoLoan
{
    public interface ICarTypeRepository : IRepository<al_car_type>
    {
        List<CarTypeViewModel> GetListAll();

        List<CarTypeViewModel> GetListById(int? Id);

        List<CarTypeViewModel> GetListByStatusId(int? StatusId);

        List<CarTypeViewModel> GetListByTypeId(int? TypeId);

        List<CarTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CarTypeViewModel> GetListActiveAll();

        List<CarTypeViewModel> GetListActiveById(int? Id);

        List<CarTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CarTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CarTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CarTypeViewModel objModel);

        bool Update(CarTypeViewModel objModel);

        bool Delete(CarTypeViewModel objModel);
    }
}
