﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.Main
{
    public interface ICompanyInformationRepository : IRepository<company_information>
    {
        List<CompanyInformationViewModel> GetListAll();

        List<CompanyInformationViewModel> GetListById(int? Id);

        List<CompanyInformationViewModel> GetListByStatusId(int? StatusId);

        List<CompanyInformationViewModel> GetListByTypeId(int? TypeId);

        List<CompanyInformationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CompanyInformationViewModel> GetListActiveAll();

        List<CompanyInformationViewModel> GetListActiveById(int? Id);

        List<CompanyInformationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CompanyInformationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CompanyInformationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CompanyInformationViewModel objModel);

        bool Update(CompanyInformationViewModel objModel);

        bool Delete(CompanyInformationViewModel objModel);
    }
}
