﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.Main
{
    public interface ICustomerIdentificationRepository : IRepository<customer_identification>
    {
        List<CustomerIdentificationViewModel> GetListAll();

        List<CustomerIdentificationViewModel> GetListById(int? Id);

        List<CustomerIdentificationViewModel> GetListByStatusId(int? StatusId);

        List<CustomerIdentificationViewModel> GetListByTypeId(int? TypeId);

        List<CustomerIdentificationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerIdentificationViewModel> GetListActiveAll();

        List<CustomerIdentificationViewModel> GetListActiveById(int? Id);

        List<CustomerIdentificationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerIdentificationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerIdentificationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerIdentificationViewModel objModel);

        bool Update(CustomerIdentificationViewModel objModel);

        bool Delete(CustomerIdentificationViewModel objModel);
    }
}
