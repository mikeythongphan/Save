﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Domain.Main
{
    public interface IApplicationDuplicationRepository : IRepository<application_duplication>
    {
        List<ApplicationDuplicationViewModel> GetListAll();

        List<ApplicationDuplicationViewModel> GetListById(int? Id);

        List<ApplicationDuplicationViewModel> GetListByStatusId(int? StatusId);

        List<ApplicationDuplicationViewModel> GetListByTypeId(int? TypeId);

        List<ApplicationDuplicationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ApplicationDuplicationViewModel> GetListActiveAll();

        List<ApplicationDuplicationViewModel> GetListActiveById(int? Id);

        List<ApplicationDuplicationViewModel> GetListActiveByStatusId(int? StatusId);

        List<ApplicationDuplicationViewModel> GetListActiveByTypeId(int? TypeId);

        List<ApplicationDuplicationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ApplicationDuplicationViewModel objModel);

        bool Update(ApplicationDuplicationViewModel objModel);

        bool Delete(ApplicationDuplicationViewModel objModel);
    }
}
