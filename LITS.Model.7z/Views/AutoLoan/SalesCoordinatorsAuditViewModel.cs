﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.Views.AutoLoan
{
    public class SalesCoordinatorsAuditViewModel
    {
        public SalesCoordinatorsAuditViewModel()
        { }

        #region SalesCoordinators
        private ApplicationInformationViewModel _objApplicationInformationViewModel = new ApplicationInformationViewModel();
        public ApplicationInformationViewModel _ApplicationInformationViewModel
        {
            get
            {
                return _objApplicationInformationViewModel;
            }
            set { _objApplicationInformationViewModel = value; }
        }

        private CustomerInformationViewModel _objCustomerInformationViewModel = new CustomerInformationViewModel();
        public CustomerInformationViewModel _CustomerInformationViewModel
        {
            get
            {
                return _objCustomerInformationViewModel;
            }
            set { _objCustomerInformationViewModel = value; }
        }

        private CustomerIncomeViewModel _objCustomerIncomeViewModel = new CustomerIncomeViewModel();
        public CustomerIncomeViewModel _CustomerIncomeViewModel
        {
            get
            {
                return _objCustomerIncomeViewModel;
            }
            set { _objCustomerIncomeViewModel = value; }
        }

        private CustomerCreditBureauViewModel _objCustomerCreditBureauViewModel = new CustomerCreditBureauViewModel();
        public CustomerCreditBureauViewModel _CustomerCreditBureauViewModel
        {
            get
            {
                return _objCustomerCreditBureauViewModel;
            }
            set { _objCustomerCreditBureauViewModel = value; }
        }

        private CollateralInformationViewModel _objCollateralInformationViewModel = new CollateralInformationViewModel();
        public CollateralInformationViewModel _CollateralInformationViewModel
        {
            get
            {
                return _objCollateralInformationViewModel;
            }
            set { _objCollateralInformationViewModel = value; }
        }

        private AppliedLoanInformationViewModel _objAppliedLoanInformationViewModel = new AppliedLoanInformationViewModel();
        public AppliedLoanInformationViewModel _AppliedLoanInformationViewModel
        {
            get
            {
                return _objAppliedLoanInformationViewModel;
            }
            set { _objAppliedLoanInformationViewModel = value; }
        }

        private CarDealerInformationViewModel _objCarDealerInformationViewModel = new CarDealerInformationViewModel();
        public CarDealerInformationViewModel _CarDealerInformationViewModel
        {
            get
            {
                return _objCarDealerInformationViewModel;
            }
            set { _objCarDealerInformationViewModel = value; }
        }

        private CustomerDemostrationViewModel _objCustomerDemostrationViewModel = new CustomerDemostrationViewModel();
        public CustomerDemostrationViewModel _CustomerDemostrationViewModel
        {
            get
            {
                return _objCustomerDemostrationViewModel;
            }
            set { _objCustomerDemostrationViewModel = value; }
        }

        private ARTAViewModel _objARTAViewModel = new ARTAViewModel();
        public ARTAViewModel _ARTAViewModel
        {
            get
            {
                return _objARTAViewModel;
            }
            set { _objARTAViewModel = value; }
        }
        #endregion
    }
}
