﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.Views.AutoLoan
{
    public class LendingOperationAuditViewModel
    {
        public LendingOperationAuditViewModel()
        { }
            
        #region LendingOperation
        private DisbursementInformationViewModel _objDisbursementInformationViewModel = new DisbursementInformationViewModel();
        public DisbursementInformationViewModel _DisbursementInformationViewModel
        {
            get
            {
                return _objDisbursementInformationViewModel;
            }
            set { _objDisbursementInformationViewModel = value; }
        }

        private DisbursementViewModel _objDisbursementViewModel = new DisbursementViewModel();
        public DisbursementViewModel _DisbursementViewModel
        {
            get
            {
                return _objDisbursementViewModel;
            }
            set { _objDisbursementViewModel = value; }
        }

        private InsuranceViewModel _objInsuranceViewModel = new InsuranceViewModel();
        public InsuranceViewModel _InsuranceViewModel
        {
            get
            {
                return _objInsuranceViewModel;
            }
            set { _objInsuranceViewModel = value; }
        }

        private PersonalDetailViewModel _objPersonalDetailViewModel = new PersonalDetailViewModel();
        public PersonalDetailViewModel _PersonalDetailViewModel
        {
            get
            {
                return _objPersonalDetailViewModel;
            }
            set { _objPersonalDetailViewModel = value; }
        }

        private PropertyInformationViewModel _objPropertyInformationViewModel = new PropertyInformationViewModel();
        public PropertyInformationViewModel _PropertyInformationViewModel
        {
            get
            {
                return _objPropertyInformationViewModel;
            }
            set { _objPropertyInformationViewModel = value; }
        }

        private PostDisbursementConditionViewModel _objPostDisbursementConditionViewModel = new PostDisbursementConditionViewModel();
        public PostDisbursementConditionViewModel _PostDisbursementConditionViewModel
        {
            get
            {
                return _objPostDisbursementConditionViewModel;
            }
            set { _objPostDisbursementConditionViewModel = value; }
        }
        #endregion
    }
}
