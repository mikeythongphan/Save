﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.Views.AutoLoan
{
    public class CreditInitiativeAuditViewModel
    {
        public CreditInitiativeAuditViewModel()
        { }

        #region CreditInitiative
        private ApplicationInformationViewModel _objApplicationInformationViewModel = new ApplicationInformationViewModel();
        public ApplicationInformationViewModel _ApplicationInformationViewModel
        {
            get
            {
                return _objApplicationInformationViewModel;
            }
            set { _objApplicationInformationViewModel = value; }
        }

        private AppliedLoanInformationViewModel _objAppliedLoanInformationViewModel = new AppliedLoanInformationViewModel();
        public AppliedLoanInformationViewModel _AppliedLoanInformationViewModel
        {
            get
            {
                return _objAppliedLoanInformationViewModel;
            }
            set { _objAppliedLoanInformationViewModel = value; }
        }

        private ApprovalInformationViewModel _objApprovalInformationViewModel = new ApprovalInformationViewModel();
        public ApprovalInformationViewModel _ApprovalInformationViewModel
        {
            get
            {
                return _objApprovalInformationViewModel;
            }
            set { _objApprovalInformationViewModel = value; }
        }

        private ARTAViewModel _objARTAViewModel = new ARTAViewModel();
        public ARTAViewModel _ARTAViewModel
        {
            get
            {
                return _objARTAViewModel;
            }
            set { _objARTAViewModel = value; }
        }

        private CollateralInformationViewModel _objCollateralInformationViewModel = new CollateralInformationViewModel();
        public CollateralInformationViewModel _CollateralInformationViewModel
        {
            get
            {
                return _objCollateralInformationViewModel;
            }
            set { _objCollateralInformationViewModel = value; }
        }

        private CustomerCreditBureauViewModel _objCustomerCreditBureauViewModel = new CustomerCreditBureauViewModel();
        public CustomerCreditBureauViewModel _CustomerCreditBureauViewModel
        {
            get
            {
                return _objCustomerCreditBureauViewModel;
            }
            set { _objCustomerCreditBureauViewModel = value; }
        }

        private CustomerDemostrationViewModel _objCustomerDemostrationViewModel = new CustomerDemostrationViewModel();
        public CustomerDemostrationViewModel _CustomerDemostrationViewModel
        {
            get
            {
                return _objCustomerDemostrationViewModel;
            }
            set { _objCustomerDemostrationViewModel = value; }
        }

        private CustomerIncomeViewModel _objCustomerIncomeViewModel = new CustomerIncomeViewModel();
        public CustomerIncomeViewModel _CustomerIncomeViewModel
        {
            get
            {
                return _objCustomerIncomeViewModel;
            }
            set { _objCustomerIncomeViewModel = value; }
        }

        private CustomerInformationViewModel _objCustomerInformationViewModel = new CustomerInformationViewModel();
        public CustomerInformationViewModel _CustomerInformationViewModel
        {
            get
            {
                return _objCustomerInformationViewModel;
            }
            set { _objCustomerInformationViewModel = value; }
        }
        #endregion
    }
}
