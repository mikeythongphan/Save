﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Views.Management
{
    public class BankHolidayViewModel
    {
        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsDisable_IsActive { get; set; }

        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public Nullable<DateTime> BankHoliday { get; set; }
        public bool IsVisibleBankHoliday { get; set; }
        public bool IsDisableBankHoliday { get; set; }

        public string DescriptionBankHoliday { get; set; }
        public bool IsVisibleDescriptionBankHoliday { get; set; }
        public bool IsDisableDescriptionBankHoliday { get; set; }

        public int? TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public int GroupID { get; set; }
        public string Group { get; set; }
        public bool IsVisibleGroup { get; set; }
        public bool IsDisableGroup { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsDisableCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsDisableCreateBy { get; set; }
    }
}
