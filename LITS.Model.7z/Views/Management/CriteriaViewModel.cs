﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Views.Management
{
    public class CriteriaViewModel
    {
        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsDisable_IsActive { get; set; }

        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsDisableName { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public int GroupID { get; set; }
        public string Group { get; set; }
        public bool IsVisibleGroup { get; set; }
        public bool IsDisableGroup { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsDisableCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsDisableCreateBy { get; set; }
    }
}
