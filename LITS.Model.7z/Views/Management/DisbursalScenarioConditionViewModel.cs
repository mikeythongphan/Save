﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Views.Management
{
    public class DisbursalScenarioConditionViewModel
    {        
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public string PreCondition { get; set; }
        public bool IsVisiblePreCondition { get; set; }
        public bool IsDisablePreCondition { get; set; }

        public string InCondition { get; set; }
        public bool IsVisibleInCondition { get; set; }
        public bool IsDisableInCondition { get; set; }

        public string PostCondition { get; set; }
        public bool IsVisiblePostCondition { get; set; }
        public bool IsDisablePostCondition { get; set; }

        public string PreConditionVN { get; set; }
        public bool IsVisiblePreConditionVN { get; set; }
        public bool IsDisablePreConditionVN { get; set; }

        public string InConditionVN { get; set; }
        public bool IsVisibleInConditionVN { get; set; }
        public bool IsDisableInConditionVN { get; set; }

        public string PostConditionVN { get; set; }
        public bool IsVisiblePostConditionVN { get; set; }
        public bool IsDisablePostConditionVN { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int? OtherInfoRequired { get; set; }        
        public bool IsVisibleOtherInfoRequired { get; set; }
        public bool IsDisableOtherInfoRequired { get; set; }

        public int? TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsDisableCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsDisableCreateBy { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsDisable_IsActive { get; set; }

        public int? GroupID { get; set; }
        public string Group { get; set; }
        public bool IsVisibleGroup { get; set; }
        public bool IsDisableGroup { get; set; }

        public int? DisbursalScenarioID { get; set; }
        public string DisbursalScenario { get; set; }
        public bool IsVisibleDisbursalScenario { get; set; }
        public bool IsDisableDisbursalScenario { get; set; }
    }
}
