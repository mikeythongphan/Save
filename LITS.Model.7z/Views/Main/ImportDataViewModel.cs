﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.ImportData;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class ImportDataViewModel
    {
        public ImportDataMasterViewModel _ImportDataMasterViewModel { get; set; }
        public List<ImportDataDetailViewModel> _ImportDataDetailViewModel { get; set; }
        public List<ImportDataTreeViewModel> _ImportDataTreeViewModel { get; set; }

        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
    }
}
