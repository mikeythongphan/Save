﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Management;
using LITS.Model.Models;

namespace LITS.Model.Views.Main
{
    public class CreateNewLoanViewModel
    {
        private CreateNewLoanStep1ViewModel _objCreateNewLoanStep1ViewModel = new CreateNewLoanStep1ViewModel();
        public CreateNewLoanStep1ViewModel _CreateNewLoanStep1ViewModel
        {
            get
            {                
                return _objCreateNewLoanStep1ViewModel;
            }
            set { _objCreateNewLoanStep1ViewModel = value; }
        }

        private CreateNewLoanStep2ViewModel _objCreateNewLoanStep2ViewModel = new CreateNewLoanStep2ViewModel();
        public CreateNewLoanStep2ViewModel _CreateNewLoanStep2ViewModel
        {
            get
            {
                return _objCreateNewLoanStep2ViewModel;
            }
            set { _objCreateNewLoanStep2ViewModel = value; }
        }

        private CreateNewLoanStep3ViewModel _objCreateNewLoanStep3ViewModel = new CreateNewLoanStep3ViewModel();
        public CreateNewLoanStep3ViewModel _CreateNewLoanStep3ViewModel
        {
            get
            {
                return _objCreateNewLoanStep3ViewModel;
            }
            set { _objCreateNewLoanStep3ViewModel = value; }
        }

        private ReturnMessageViewModel _objReturnMessageViewModel = new ReturnMessageViewModel();
        public ReturnMessageViewModel _ReturnMessageViewModel
        {
            get
            {
                return _objReturnMessageViewModel;
            }
            set { _objReturnMessageViewModel = value; }
        }
    }
}
