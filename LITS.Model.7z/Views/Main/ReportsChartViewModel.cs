﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.ReportsChart;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class ReportsChartViewModel
    {
        private ReportsChartMasterViewModel _objReportsChartMasterViewModel = new ReportsChartMasterViewModel();
        public ReportsChartMasterViewModel _ReportsChartMasterViewModel
         {
            get
            {
                return _objReportsChartMasterViewModel;
            }
            set { _objReportsChartMasterViewModel = value; }
        }
        private List<ReportsChartDetailViewModel> _objReportsChartDetailViewModel = new List<ReportsChartDetailViewModel>();
        public List<ReportsChartDetailViewModel> _ReportsChartDetailViewModel 
        {
            get
            {
                return _objReportsChartDetailViewModel;
            }
            set { _objReportsChartDetailViewModel = value; }
        }

        private List<ReportsChartTreeViewModel> _objReportsChartTreeViewModel = new List<ReportsChartTreeViewModel>();
        public List<ReportsChartTreeViewModel> _ReportsChartTreeViewModel 
        {
            get
            {
                return _objReportsChartTreeViewModel;
            }
            set { _objReportsChartTreeViewModel = value; }
        }

        private List<StatusViewModel> _objStatusViewModel = new List<StatusViewModel>();
        public List<StatusViewModel> lstStatusViewModel
        {
            get
            {
                return _objStatusViewModel;
            }
            set { _objStatusViewModel = value; }
        }
        private List<TypeViewModel> _objTypeViewModel = new List<TypeViewModel>();
        public List<TypeViewModel> lstTypeViewModel
        {
            get
            {
                return _objTypeViewModel;
            }
            set { _objTypeViewModel = value; }
        }

    }
}
