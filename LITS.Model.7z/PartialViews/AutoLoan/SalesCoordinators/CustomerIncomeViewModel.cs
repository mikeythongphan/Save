﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CustomerIncomeViewModel
    {
        #region Application ID
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        #endregion

        #region Main

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Main_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Main_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Main_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Main_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Main_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Main_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Main { get; set; }
        public bool IsVisibleTotalSalariedIncome_Main { get; set; }
        public bool IsDisableTotalSalariedIncome_Main { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Main_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Main_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Main_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Main_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Main { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Main { get; set; }
        public bool IsDisableTotalHouseRentalIncome_Main { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Main_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Main_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Main_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Main_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Main { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Main { get; set; }
        public bool IsDisableTotalCarRentalIncome_Main { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Main { get; set; }
        public bool IsVisibleTotalRentalIncome_Main { get; set; }
        public bool IsDisableTotalRentalIncome_Main { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Main_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Main_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Main_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Main_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Main_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Main_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Main { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Main { get; set; }
        public bool IsDisableTotalSelfEmployedIncome_Main { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_1;
            }
            set { _objOtherIncomeViewModel_Main_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_2;
            }
            set { _objOtherIncomeViewModel_Main_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_3;
            }
            set { _objOtherIncomeViewModel_Main_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Main_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Main_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Main_Income_4;
            }
            set { _objOtherIncomeViewModel_Main_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Main { get; set; }
        public bool IsVisibleTotalOtherIncome_Main { get; set; }
        public bool IsDisableTotalOtherIncome_Main { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Main { get; set; }
        public bool IsVisibleTotalIncome_Main { get; set; }
        public bool IsDisableTotalIncome_Main { get; set; }
        #endregion

        #endregion

        #region Co1

        #region SalariedClient
        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co1_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co1_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co1_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co1_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co1_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co1_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co1 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co1 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co1_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co1_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co1_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co1_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co1 { get; set; }
        public bool IsDisableTotalHouseRentalIncome_Co1 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co1_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co1_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co1_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co1_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co1 { get; set; }
        public bool IsDisableTotalCarRentalIncome_Co1 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome_Co1 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co1_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co1_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co1_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co1_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co1_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co1_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co1 { get; set; }
        public bool IsDisableTotalSelfEmployedIncome_Co1 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_1;
            }
            set { _objOtherIncomeViewModel_Co1_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_2;
            }
            set { _objOtherIncomeViewModel_Co1_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_3;
            }
            set { _objOtherIncomeViewModel_Co1_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co1_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co1_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co1_Income_4;
            }
            set { _objOtherIncomeViewModel_Co1_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co1 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co1 { get; set; }
        public bool IsDisableTotalOtherIncome_Co1 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co1 { get; set; }
        public bool IsVisibleTotalIncome_Co1 { get; set; }
        public bool IsDisableTotalIncome_Co1 { get; set; }
        #endregion

        #endregion

        #region Co2

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co2_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co2_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co2_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co2_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co2_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co2_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co2 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co2 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co2_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co2_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co2_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co2_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co2 { get; set; }
        public bool IsDisableTotalHouseRentalIncome_Co2 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co2_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co2_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co2_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co2_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co2 { get; set; }
        public bool IsDisableTotalCarRentalIncome_Co2 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome_Co2 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co2_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co2_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co2_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co2_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co2_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co2_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co2 { get; set; }
        public bool IsDisableTotalSelfEmployedIncome_Co2 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_1;
            }
            set { _objOtherIncomeViewModel_Co2_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_2;
            }
            set { _objOtherIncomeViewModel_Co2_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_3;
            }
            set { _objOtherIncomeViewModel_Co2_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co2_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co2_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co2_Income_4;
            }
            set { _objOtherIncomeViewModel_Co2_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co2 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co2 { get; set; }
        public bool IsDisableTotalOtherIncome_Co2 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co2 { get; set; }
        public bool IsVisibleTotalIncome_Co2 { get; set; }
        public bool IsDisableTotalIncome_Co2 { get; set; }
        #endregion

        #endregion

        #region Co3

        #region SalariedClient

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co3_Income_1 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co3_Income_1;
            }
            set { _objSalariedClientIncomeViewModel_Co3_Income_1 = value; }
        }

        private SalariedClientIncomeViewModel _objSalariedClientIncomeViewModel_Co3_Income_2 = new SalariedClientIncomeViewModel();
        public SalariedClientIncomeViewModel _SalariedClientIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objSalariedClientIncomeViewModel_Co3_Income_2;
            }
            set { _objSalariedClientIncomeViewModel_Co3_Income_2 = value; }
        }

        public decimal? TotalSalariedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co3 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co3 { get; set; }
        #endregion

        #region Rental

        #region House Rental
        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_1 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_1;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_1 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_2 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_2;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_2 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_3 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_3;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_3 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_4 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_4;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_4 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_5 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_5
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_5;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_5 = value; }
        }

        private HouseRentalIncomeViewModel _objHouseRentalIncomeViewModel_Co3_Income_6 = new HouseRentalIncomeViewModel();
        public HouseRentalIncomeViewModel _HouseRentalIncomeViewModel_Co3_Income_6
        {
            get
            {
                return _objHouseRentalIncomeViewModel_Co3_Income_6;
            }
            set { _objHouseRentalIncomeViewModel_Co3_Income_6 = value; }
        }

        public decimal? TotalHouseRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalHouseRentalIncome_Co3 { get; set; }
        public bool IsDisableTotalHouseRentalIncome_Co3 { get; set; }
        #endregion

        #region Car Rental
        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_1 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_1;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_1 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_2 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_2;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_2 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_3 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_3;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_3 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_4 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_4;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_4 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_5 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_5
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_5;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_5 = value; }
        }

        private CarRentalIncomeViewModel _objCarRentalIncomeViewModel_Co3_Income_6 = new CarRentalIncomeViewModel();
        public CarRentalIncomeViewModel _CarRentalIncomeViewModel_Co3_Income_6
        {
            get
            {
                return _objCarRentalIncomeViewModel_Co3_Income_6;
            }
            set { _objCarRentalIncomeViewModel_Co3_Income_6 = value; }
        }

        public decimal? TotalCarRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome_Co3 { get; set; }
        public bool IsDisableTotalCarRentalIncome_Co3 { get; set; }
        #endregion

        public decimal? TotalRentalIncome_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome_Co3 { get; set; }
        #endregion

        #region SelfEmployed
        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co3_Income_1 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co3_Income_1;
            }
            set { _objSelfEmployedIncomeViewModel_Co3_Income_1 = value; }
        }

        private SelfEmployedIncomeViewModel _objSelfEmployedIncomeViewModel_Co3_Income_2 = new SelfEmployedIncomeViewModel();
        public SelfEmployedIncomeViewModel _SelfEmployedIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objSelfEmployedIncomeViewModel_Co3_Income_2;
            }
            set { _objSelfEmployedIncomeViewModel_Co3_Income_2 = value; }
        }

        public decimal? TotalSelfEmployedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome_Co3 { get; set; }
        public bool IsDisableTotalSelfEmployedIncome_Co3 { get; set; }
        #endregion

        #region Other
        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_1 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_1
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_1;
            }
            set { _objOtherIncomeViewModel_Co3_Income_1 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_2 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_2
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_2;
            }
            set { _objOtherIncomeViewModel_Co3_Income_2 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_3 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_3
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_3;
            }
            set { _objOtherIncomeViewModel_Co3_Income_3 = value; }
        }

        private OtherIncomeViewModel _objOtherIncomeViewModel_Co3_Income_4 = new OtherIncomeViewModel();
        public OtherIncomeViewModel _OtherIncomeViewModel_Co3_Income_4
        {
            get
            {
                return _objOtherIncomeViewModel_Co3_Income_4;
            }
            set { _objOtherIncomeViewModel_Co3_Income_4 = value; }
        }

        public decimal? TotalOtherIncome_Co3 { get; set; }
        public bool IsVisibleTotalOtherIncome_Co3 { get; set; }
        public bool IsDisableTotalOtherIncome_Co3 { get; set; }
        #endregion

        #region Total
        public float TotalIncome_Co3 { get; set; }
        public bool IsVisibleTotalIncome_Co3 { get; set; }
        public bool IsDisableTotalIncome_Co3 { get; set; }
        #endregion

        #endregion

        #region Summary
        public decimal? TotalSalariedIncome { get; set; }
        public bool IsVisibleTotalSalariedIncome { get; set; }
        public bool IsDisableTotalSalariedIncome { get; set; }

        public decimal? TotalRentalIncome { get; set; }
        public bool IsVisibleTotalRentalIncome { get; set; }
        public bool IsDisableTotalRentalIncome { get; set; }

        public decimal? TotalCarRentalIncome { get; set; }
        public bool IsVisibleTotalCarRentalIncome { get; set; }
        public bool IsDisableTotalCarRentalIncome { get; set; }

        public decimal? TotalSelfEmployedIncome { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome { get; set; }
        public bool IsDisableTotalSelfEmployedIncome { get; set; }

        public decimal? TotalIncome { get; set; }
        public bool IsVisibleTotalIncome { get; set; }
        public bool IsDisableTotalIncome { get; set; }

        public bool IsActive { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        #endregion
    }

    public class SalariedClientIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int? BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsDisableBorrowerType { get; set; }

        public int? IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsDisableIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public int? CompanyCodeID { get; set; }
        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string OfficeTel { get; set; }
        public bool IsVisibleOfficeTel { get; set; }
        public bool IsDisableOfficeTel { get; set; }

        public int? CompanyNatureOfBusinessID { get; set; }
        public string CompanyNatureOfBusiness { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness { get; set; }
        public bool IsDisableCompanyNatureOfBusiness { get; set; }

        public int? CompanyIndustryID { get; set; }
        public string CompanyIndustry { get; set; }
        public bool IsVisibleCompanyIndustry { get; set; }
        public bool IsDisableCompanyIndustry { get; set; }

        public int? OccupationID { get; set; }
        public string Occupation { get; set; }
        public bool IsVisibleOccupation { get; set; }
        public bool IsDisableOccupation { get; set; }

        public int? CurrentPositionID { get; set; }
        public string CurrentPosition { get; set; }
        public bool IsVisibleCurrentPosition { get; set; }
        public bool IsDisableCurrentPosition { get; set; }

        public int? EmploymentTypeID { get; set; }
        public string EmploymentType { get; set; }
        public bool IsVisibleEmploymentType { get; set; }
        public bool IsDisableEmploymentType { get; set; }

        public string WorkingAddress { get; set; }
        public bool IsVisibleWorkingAddress { get; set; }
        public bool IsDisableWorkingAddress { get; set; }

        public string WorkingWard { get; set; }
        public bool IsVisibleWorkingWard { get; set; }
        public bool IsDisableWorkingWard { get; set; }

        public int? WorkingDistrictID { get; set; }
        public string WorkingDistrict { get; set; }
        public bool IsVisibleWorkingDistrict { get; set; }
        public bool IsDisableWorkingDistrict { get; set; }

        public int? WorkingCityID { get; set; }
        public string WorkingCity { get; set; }
        public bool IsVisibleWorkingCity { get; set; }
        public bool IsDisableWorkingCity { get; set; }

        public decimal? PercentSharesInCompany { get; set; }
        public bool IsVisiblePercentSharesInCompany { get; set; }
        public bool IsDisablePercentSharesInCompany { get; set; }

        public int? TypeOfLabourContractID { get; set; }
        public string TypeOfLabourContract { get; set; }
        public bool IsVisibleTypeOfLabourContract { get; set; }
        public bool IsDisableTypeOfLabourContract { get; set; }
        
        public int? ContractLength { get; set; }
        public bool IsVisibleContractLength { get; set; }
        public bool IsDisableContractLength { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany { get; set; }
        public bool IsDisableStartDateAtCurrentCompany { get; set; }

        public int? TotalMonthsInCurrentCompany { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany { get; set; }

        public int? TotalMonthsInWorkingExperience { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience { get; set; }        

        public decimal? MonthlyIncomeDeclared { get; set; }
        public bool IsVisibleMonthlyIncomeDeclared { get; set; }
        public bool IsDisableMonthlyIncomeDeclared { get; set; }

        public int? PeriodOfSubmittedBSID { get; set; }
        public string PeriodOfSubmittedBS { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS { get; set; }
        public bool IsDisablePeriodOfSubmittedBS { get; set; }

        public bool FreelanceIncome { get; set; }
        public bool IsVisibleFreelanceIncome { get; set; }
        public bool IsDisableFreelanceIncome { get; set; }

        public decimal? GrossBaseSalary { get; set; }
        public bool IsVisibleGrossBaseSalary { get; set; }
        public bool IsDisableGrossBaseSalary { get; set; }

        public decimal? BasicAllowance { get; set; }
        public bool IsVisibleBasicAllowance { get; set; }
        public bool IsDisableBasicAllowance { get; set; }

        public decimal? EligibleFixedIncomeOnLC { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC { get; set; }

        public decimal? FixedIncomeViaBS { get; set; }
        public bool IsVisibleFixedIncomeViaBS { get; set; }
        public bool IsDisableFixedIncomeViaBS { get; set; }

        public decimal? TotalMonthlyIncomeViaBS { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS { get; set; }

        public decimal? PerformanceBonus { get; set; }
        public bool IsVisiblePerformanceBonus { get; set; }
        public bool IsDisablePerformanceBonus { get; set; }

        public decimal? FinalIncome { get; set; }
        public bool IsVisibleFinalIncome { get; set; }
        public bool IsDisableFinalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }

        private List<CustomerBonusMonthlyViewModel> _objCustomerBonusMonthlyViewModel = new List<CustomerBonusMonthlyViewModel>();
        public List<CustomerBonusMonthlyViewModel> _CustomerBonusMonthlyViewModel
        {
            get
            {
                return _objCustomerBonusMonthlyViewModel;
            }
            set { _objCustomerBonusMonthlyViewModel = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class HouseRentalIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsDisableBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsDisableIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public string DetailsOfPropertyForRent { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent { get; set; }
        public bool IsDisableDetailsOfPropertyForRent { get; set; }

        public string RentalPropertyAddress { get; set; }
        public bool IsVisibleRentalPropertyAddress { get; set; }
        public bool IsDisableRentalPropertyAddress { get; set; }

        public string RentalPropertyOwnershipName { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName { get; set; }
        public bool IsDisableRentalPropertyOwnershipName { get; set; }

        public string LesseeNameAddressContact { get; set; }
        public bool IsVisibleLesseeNameAddressContact { get; set; }
        public bool IsDisableLesseeNameAddressContact { get; set; }

        public string RentalPropertyWard { get; set; }
        public bool IsVisibleRentalPropertyWard { get; set; }
        public bool IsDisableRentalPropertyWard { get; set; }

        public string RentalPropertyDistrict { get; set; }
        public bool IsVisibleRentalPropertyDistrict { get; set; }
        public bool IsDisableRentalPropertyDistrict { get; set; }
        public int? RentalPropertyDistrictID { get; set; }

        public string RentalPropertyCity { get; set; }
        public bool IsVisibleRentalPropertyCity { get; set; }
        public bool IsDisableRentalPropertyCity { get; set; }
        public int? RentalPropertyCityID { get; set; }

        public string RentalContaclTenure { get; set; }
        public bool IsVisibleRentalContaclTenure { get; set; }
        public bool IsDisableRentalContaclTenure { get; set; }

        public decimal? MonthlyRentalFee { get; set; }
        public bool IsVisibleMonthlyRentalFee { get; set; }
        public bool IsDisableMonthlyRentalFee { get; set; }

        public string RentalPurpose { get; set; }
        public bool IsVisibleRentalPurpose { get; set; }
        public bool IsDisableRentalPurpose { get; set; }
        public int? RentalPurposeID { get; set; }

        public string RepaymentCycle { get; set; }
        public bool IsVisibleRepaymentCycle { get; set; }
        public bool IsDisableRepaymentCycle { get; set; }
        public int? RepaymentCycleID { get; set; }
        
        public string IncomePaymentMethod { get; set; }
        public bool IsVisibleIncomePaymentMethod { get; set; }
        public bool IsDisableIncomePaymentMethod { get; set; }
        public int IncomePaymentMethodID { get; set; }

        public decimal? TotalRentalIncome { get; set; }
        public bool IsVisibleTotalRentalIncome { get; set; }
        public bool IsDisableTotalRentalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }
        public bool IsVisibleCustomerIncomeMonthly { get; set; }
        public bool IsDisableCustomerIncomeMonthly { get; set; }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class CarRentalIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsDisableBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsDisableIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public string DetailsOfCarforRent { get; set; }
        public bool IsVisibleDetailsOfCarforRent { get; set; }
        public bool IsDisableDetailsOfCarforRent { get; set; }

        public string TypeOfCar { get; set; }
        public bool IsVisibleTypeOfCar { get; set; }
        public bool IsDisableTypeOfCar { get; set; }

        public string CarPlateNumber { get; set; }
        public bool IsVisibleCarPlateNumber { get; set; }
        public bool IsDisableCarPlateNumber { get; set; }

        public string CarOwnershipName { get; set; }
        public bool IsVisibleCarOwnershipName { get; set; }
        public bool IsDisableCarOwnershipName { get; set; }

        public string CarLesseeNameAddressContact { get; set; }
        public bool IsVisibleCarLesseeNameAddressContact { get; set; }
        public bool IsDisableCarLesseeNameAddressContact { get; set; }

        public string RentalContractTenure { get; set; }
        public bool IsVisibleRentalContractTenure { get; set; }
        public bool IsDisableRentalContractTenure { get; set; }

        public decimal? CarMonthlyRentalFee { get; set; }
        public bool IsVisibleCarMonthlyRentalFee { get; set; }
        public bool IsDisableCarMonthlyRentalFee { get; set; }

        public string CarRepaymentCycle { get; set; }
        public bool IsVisibleCarRepaymentCycle { get; set; }
        public bool IsDisableCarRepaymentCycle { get; set; }
        public int CarRepaymentCycleID { get; set; }

        public string CarIncomePaymentMethod { get; set; }
        public bool IsVisibleCarIncomePaymentMethod { get; set; }
        public bool IsDisableCarIncomePaymentMethod { get; set; }
        public int? CarIncomePaymentMethodID { get; set; }

        public decimal? TotalCarRentalIncome { get; set; }
        public bool IsVisibleTotalCarRentalIncome { get; set; }
        public bool IsDisableTotalCarRentalIncome { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }
        public bool IsVisibleCustomerIncomeMonthly { get; set; }
        public bool IsDisableCustomerIncomeMonthly { get; set; }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class SelfEmployedIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsDisableBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsDisableIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string BusinessLicenceNumber { get; set; }
        public bool IsVisibleBusinessLicenceNumber { get; set; }
        public bool IsDisableBusinessLicenceNumber { get; set; }

        public string TaxCode { get; set; }
        public bool IsVisibleTaxCode { get; set; }
        public bool IsDisableTaxCode { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }
        public int? CompanyDistrictID { get; set; }

        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }
        public int? CompanyCityID { get; set; }

        public string OfficeTel { get; set; }
        public bool IsVisibleOfficeTel { get; set; }
        public bool IsDisableOfficeTel { get; set; }

        public string MainCompanyIndustry1 { get; set; }
        public bool IsVisibleMainCompanyIndustry1 { get; set; }
        public bool IsDisableMainCompanyIndustry1 { get; set; }
        public int? MainCompanyIndustry1ID { get; set; }

        public string MainCompanyIndustry2 { get; set; }
        public bool IsVisibleMainCompanyIndustry2 { get; set; }
        public bool IsDisableMainCompanyIndustry2 { get; set; }
        public int? MainCompanyIndustry2ID { get; set; }

        public string OtherCompanyIndustryBizNature { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature { get; set; }

        public int? SeasonalIndustryID { get; set; }
        public string SeasonalIndustry { get; set; }
        public bool IsVisibleSeasonalIndustry { get; set; }
        public bool IsDisableSeasonalIndustry { get; set; }

        public Nullable<DateTime> EstablishedYear { get; set; }
        public bool IsVisibleEstablishedYear { get; set; }
        public bool IsDisableEstablishedYear { get; set; }

        public int? TotalYearsInOperation { get; set; }
        public bool IsVisibleTotalYearsInOperation { get; set; }
        public bool IsDisableTotalYearsInOperation { get; set; }

        public decimal? ShareholdingInCompany { get; set; }
        public bool IsVisibleShareholdingInCompany { get; set; }
        public bool IsDisableShareholdingInCompany { get; set; }

        public decimal? ProfLossinLatestYear { get; set; }
        public bool IsVisibleProfLossinLatestYear { get; set; }
        public bool IsDisableProfLossinLatestYear { get; set; }
        public int ProfLossinLatestYearID { get; set; }

        public string TypeOfSelfEmploymentIncome { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome { get; set; }
        public int? TypeOfSelfEmploymentIncomeID { get; set; }

        public decimal? TotalTurnoverInFS_IGMVAT { get; set; }
        public bool IsVisibleTotalTurnoverInFS_IGMVAT { get; set; }
        public bool IsDisableTotalTurnoverInFS_IGMVAT { get; set; }

        public decimal? MonthlyTurnoverInYear_IGMVAT { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear_IGMVAT { get; set; }
        public bool IsDisableMonthlyTurnoverinYear_IGMVAT { get; set; }

        public decimal? TotalUpdatedTurnover_IGMVAT { get; set; }
        public bool IsVisibleTotalUpdatedTurnover_IGMVAT { get; set; }
        public bool IsDisableTotalUpdatedTurnover_IGMVAT { get; set; }

        public decimal? AverageMonthlyUpdatedTurnover_IGMVAT { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover_IGMVAT { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover_IGMVAT { get; set; }

        public decimal? ComparedWithTurnOver_IGMVAT { get; set; }
        public bool IsVisibleComparedWithTurnOver_IGMVAT { get; set; }
        public bool IsDisableComparedWithTurnOver_IGMVAT { get; set; }

        public decimal? RevisedAverageMonthlyTurnover_IGMVAT { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover_IGMVAT { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover_IGMVAT { get; set; }

        public decimal? SplitupIndustry1_IGMVAT { get; set; }
        public bool IsVisibleSplitupIndustr1_IGMVAT { get; set; }
        public bool IsDisableSplitupIndustry1_IGMVAT { get; set; }

        public decimal? SplitupIndustry2_IGMVAT { get; set; }
        public bool IsVisibleSplitupIndustry2_IGMVAT { get; set; }
        public bool IsDisableSplitupIndustry2_IGMVAT { get; set; }

        public decimal? SplitupIndustry3_IGMVAT { get; set; }
        public bool IsVisibleSplitupIndustry3_IGMVAT { get; set; }
        public bool IsDisableSplitupIndustry3_IGMVAT { get; set; }

        public decimal? IndustrialMargin1_IGMVAT { get; set; }
        public bool IsVisibleIndustrialMargin1_IGMVAT { get; set; }
        public bool IsDisableIndustrialMargin1_IGMVAT { get; set; }

        public decimal? IndustrialMargin2_IGMVAT { get; set; }
        public bool IsVisibleIndustrialMargin2_IGMVAT { get; set; }
        public bool IsDisableIndustrialMargin2_IGMVAT { get; set; }

        public decimal? IndustrialMargin3_IGMVAT { get; set; }
        public bool IsVisibleIndustrialMargin3_IGMVAT { get; set; }
        public bool IsDisableIndustrialMargin3_IGMVAT { get; set; }

        public string Remark_IGMVAT { get; set; }
        public bool IsVisibleRemark_IGMVAT { get; set; }
        public bool IsDisableRemark_IGMVAT { get; set; }

        public decimal? MonthlySeflEmployedIncome_IGMVAT { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome_IGMVAT { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome_IGMVAT { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncome_IGMVAT { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome_IGMVAT { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome_IGMVAT { get; set; }

        public decimal? TotalTurnoverInFSBank { get; set; }
        public bool IsVisibleTotalTurnoverInFSBank { get; set; }
        public bool IsDisableTotalTurnoverInFSBank { get; set; }

        public decimal? MonthlyTurnoverInyearBank { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank { get; set; }

        public decimal? OtherMonthlyTurnover { get; set; }
        public bool IsVisibleOtherMonthlyTurnover { get; set; }
        public bool IsDisableOtherMonthlyTurnover { get; set; }

        public decimal? AverageEligibleCreditBalance { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance { get; set; }
        public bool IsDisableAverageEligibleCreditBalance { get; set; }

        public decimal? TotalEligibleMonthlyIncome { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome { get; set; }

        public decimal? ComparedWithTurnOverBank { get; set; }
        public bool IsVisibleComparedWithTurnOverBank { get; set; }
        public bool IsDisableComparedWithTurnOverBank { get; set; }

        public decimal? RevisedAverageMonthlyTurnoverBank { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank { get; set; }

        public decimal? SplitupIndustryBank1 { get; set; }
        public bool IsVisibleSplitupIndustryBank1 { get; set; }
        public bool IsDisableSplitupIndustryBank1 { get; set; }

        public decimal? SplitupIndustryBank2 { get; set; }
        public bool IsVisibleSplitupIndustryBank2 { get; set; }
        public bool IsDisableSplitupIndustryBank2 { get; set; }

        public decimal? SplitupIndustryBank3 { get; set; }
        public bool IsVisibleSplitupIndustryBank3 { get; set; }
        public bool IsDisableSplitupIndustryBank3 { get; set; }

        public decimal? IndustrialMarginBank1 { get; set; }
        public bool IsVisibleIndustrialMarginBank1 { get; set; }
        public bool IsDisableIndustrialMarginBank1 { get; set; }

        public decimal? IndustrialMarginBank2 { get; set; }
        public bool IsVisibleIndustrialMarginBank2 { get; set; }
        public bool IsDisableIndustrialMarginBank2 { get; set; }

        public decimal? IndustrialMarginBank3 { get; set; }
        public bool IsVisibleIndustrialMarginBank3 { get; set; }
        public bool IsDisableIndustrialMarginBank3 { get; set; }

        public string RemarkBank { get; set; }
        public bool IsVisibleRemarkBank { get; set; }
        public bool IsDisableRemarkBank { get; set; }

        public decimal? MonthlySelfEmployedIncomeBank { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeBank { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeBank { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncomeBank { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank { get; set; }

        public decimal? TotalTurnoverInFS_CPP { get; set; }
        public bool IsVisibleTotalTurnoverInFS_CPP { get; set; }
        public bool IsDisableTotalTurnoverInFS_CPP { get; set; }

        public decimal? ProftafertaxinLatestYear_CPP { get; set; }
        public bool IsVisibleProftafertaxinLatestYear_CPP { get; set; }
        public bool IsDisableProftafertaxinLatestYear_CPP { get; set; }

        public decimal? Depreciation_CPP { get; set; }
        public bool IsVisibleDepreciation_CPP { get; set; }
        public bool IsDisableDepreciation_CPP { get; set; }

        public decimal? MonthlyTurnoverInYear_CPP { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear_CPP { get; set; }
        public bool IsDisableMonthlyTurnoverInYear_CPP { get; set; }

        public decimal? MonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP { get; set; }

        public decimal? CustomerMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMVAT = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMVAT
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMVAT;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMVAT = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan = value; }
        }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            }
            set { _objCustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit = value; }
        }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }

    public class OtherIncomeViewModel
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }
        public int CustomerIncomeID { get; set; }

        public int BorrowerTypeID { get; set; }
        public string BorrowerType { get; set; }
        public bool IsVisibleBorrowerType { get; set; }
        public bool IsDisableBorrowerType { get; set; }

        public int IncomeTypeID { get; set; }
        public string IncomeType { get; set; }
        public bool IsVisibleIncomeType { get; set; }
        public bool IsDisableIncomeType { get; set; }

        public int ALCustomerID { get; set; }
        public int ALCustomerIncomeID { get; set; }
        public int ALCustomerSalariedClientIncomeID { get; set; }

        public decimal? DiscountRate { get; set; }
        public bool IsVisibleDiscountRate { get; set; }
        public bool IsDisableDiscountRate { get; set; }

        public decimal? TotalUpdatedTurnover { get; set; }
        public bool IsVisibleTotalUpdatedTurnover { get; set; }
        public bool IsDisableTotalUpdatedTurnover { get; set; }

        private List<CustomerIncomeMonthlyViewModel> _objCustomerIncomeMonthlyViewModel = new List<CustomerIncomeMonthlyViewModel>();
        public List<CustomerIncomeMonthlyViewModel> _CustomerIncomeMonthlyViewModel
        {
            get
            {
                return _objCustomerIncomeMonthlyViewModel;
            }
            set { _objCustomerIncomeMonthlyViewModel = value; }
        }
        public bool IsVisibleCustomerIncomeMonthly { get; set; }
        public bool IsDisableCustomerIncomeMonthly { get; set; }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }
    }
}
