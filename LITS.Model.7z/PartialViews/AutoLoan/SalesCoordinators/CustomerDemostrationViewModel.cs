﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CustomerDemostrationViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public decimal? TotalFDvalue { get; set; }
        public bool IsVisibleTotalFDvalue { get; set; }
        public bool IsDisableTotalFDvalue { get; set; }

        public decimal? TotalPropertyOwned { get; set; }
        public bool IsVisibleTotalPropertyOwned { get; set; }
        public bool IsDisableTotalPropertyOwned { get; set; }

        public decimal? TotalCarOwned { get; set; }
        public bool IsVisibleTotalCarOwned { get; set; }
        public bool IsDisableTotalCarOwned { get; set; }

        public decimal? OtherAsset { get; set; }
        public bool IsVisibleOtherAsset { get; set; }
        public bool IsDisableOtherAsset { get; set; }

        public decimal? MonthlyExpenditure { get; set; }
        public bool IsVisibleMonthlyExpenditure { get; set; }
        public bool IsDisableMonthlyExpenditure { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
