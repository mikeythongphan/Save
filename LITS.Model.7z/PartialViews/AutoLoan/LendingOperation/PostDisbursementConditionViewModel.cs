﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class PostDisbursementConditionViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        public Nullable<System.DateTime> PostDisbursementConditionExpiryDate { get; set; }
        public bool IsVisiblePostDisbursementConditionExpiryDate { get; set; }
        public bool IsDisablePostDisbursementConditionExpiryDate { get; set; }
    }
}
