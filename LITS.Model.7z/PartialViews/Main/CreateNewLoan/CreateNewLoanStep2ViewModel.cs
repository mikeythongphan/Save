﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Model.Domain.Main;

namespace LITS.Model.PartialViews.Main.CreateNewLoan
{
    public class CreateNewLoanStep2ViewModel
    {
        #region Application
        public int? ProductTypeID { get; set; }
        public string ProductType { get; set; }
        public bool IsVisibleProductTypeID { get; set; }
        public bool IsDisableProductTypeID { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationTypeID { get; set; }
        public bool IsDisableApplicationTypeID { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplication { get; set; }
        public bool IsDisableApplication { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsCompanyBlacklist { get; set; }
        public bool IsCustomerBlacklist { get; set; }
        public bool IsDuplicate { get; set; }
        #endregion

        #region Main-Borrower
        public int? CustomerNameMainID { get; set; }
        public string CustomerNameMain { get; set; }
        public bool IsVisibleCustomerNameMain { get; set; }
        public bool IsDisableCustomerNameMain { get; set; }

        public Nullable<DateTime> DateOfBirthMain { get; set; }
        public bool IsVisibleDateOfBirthMain { get; set; }
        public bool IsDisableDateOfBirthMain { get; set; }

        public bool IsActiveMain { get; set; }

        private List<CustomerIdentificationViewModel> _objCreateNewLoanStep2IdentificationMain = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> lstCreateNewLoanStep2IdentificationMain
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationMain;
            }
            set { _objCreateNewLoanStep2IdentificationMain = value; }
        }
        public bool IsVisibleCreateNewLoanStep2IdentificationMain { get; set; }
        public bool IsDisableCreateNewLoanStep2IdentificationMain { get; set; }

        private List<CompanyInformationViewModel> _objCreateNewLoanStep2CompanyViewModel = new List<CompanyInformationViewModel>();
        public List<CompanyInformationViewModel> lstCreateNewLoanStep2CompanyMain
        {
            get
            {
                return _objCreateNewLoanStep2CompanyViewModel;
            }
            set { _objCreateNewLoanStep2CompanyViewModel = value; }
        }
        public bool IsVisibleCreateNewLoanStep2CompanyMain { get; set; }
        public bool IsDisableCreateNewLoanStep2CompanyMain { get; set; }
        #endregion

        #region Co-Borrower 1 
        public int? CustomerNameCo1ID { get; set; }
        public string CustomerNameCo1 { get; set; }
        public bool IsVisibleCustomerNameCo1 { get; set; }
        public bool IsDisableCustomerNameCo1 { get; set; }

        public Nullable<DateTime> DateOfBirthCo1 { get; set; }
        public bool IsVisibleDateOfBirthCo1 { get; set; }
        public bool IsDisableDateOfBirthCo1 { get; set; }

        public bool IsActiveCo1 { get; set; }

        private List<CustomerIdentificationViewModel> _objCreateNewLoanStep2IdentificationCo1 = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> lstCreateNewLoanStep2IdentificationCo1
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo1;
            }
            set { _objCreateNewLoanStep2IdentificationCo1 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2IdentificationCo1 { get; set; }
        public bool IsDisableCreateNewLoanStep2IdentificationCo1 { get; set; }

        private List<CompanyInformationViewModel> _objCreateNewLoanStep2CompanyCo1 = new List<CompanyInformationViewModel>();
        public List<CompanyInformationViewModel> lstCreateNewLoanStep2CompanyCo1
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo1;
            }
            set { _objCreateNewLoanStep2CompanyCo1 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2CompanyCo1 { get; set; }
        public bool IsDisableCreateNewLoanStep2CompanyCo1 { get; set; }
        #endregion

        #region Co-Borrower 2 
        public int? CustomerNameCo2ID { get; set; }
        public string CustomerNameCo2 { get; set; }
        public bool IsVisibleCustomerNameCo2 { get; set; }
        public bool IsDisableCustomerNameCo2 { get; set; }

        public Nullable<DateTime> DateOfBirthCo2 { get; set; }
        public bool IsVisibleDateOfBirthCo2 { get; set; }
        public bool IsDisableDateOfBirthCo2 { get; set; }

        public bool IsActiveCo2 { get; set; }

        private List<CustomerIdentificationViewModel> _objCreateNewLoanStep2IdentificationCo2 = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> lstCreateNewLoanStep2IdentificationCo2
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo2;
            }
            set { _objCreateNewLoanStep2IdentificationCo2 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2IdentificationCo2 { get; set; }
        public bool IsDisableCreateNewLoanStep2IdentificationCo2 { get; set; }

        private List<CompanyInformationViewModel> _objCreateNewLoanStep2CompanyCo2 = new List<CompanyInformationViewModel>();
        public List<CompanyInformationViewModel> lstCreateNewLoanStep2CompanyCo2
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo2;
            }
            set { _objCreateNewLoanStep2CompanyCo2 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2CompanyCo2 { get; set; }
        public bool IsDisableCreateNewLoanStep2CompanyCo2 { get; set; }
        #endregion

        #region Co-Borrower 3 
        public int? CustomerNameCo3ID { get; set; }
        public string CustomerNameCo3 { get; set; }
        public bool IsVisibleCustomerNameCo3 { get; set; }
        public bool IsDisableCustomerNameCo3 { get; set; }

        public Nullable<DateTime> DateOfBirthCo3 { get; set; }
        public bool IsVisibleDateOfBirthCo3 { get; set; }
        public bool IsDisableDateOfBirthCo3 { get; set; }

        public bool IsActiveCo3 { get; set; }

        private List<CustomerIdentificationViewModel> _objCreateNewLoanStep2IdentificationCo3 = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> lstCreateNewLoanStep2IdentificationCo3
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo3;
            }
            set { _objCreateNewLoanStep2IdentificationCo3 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2IdentificationCo3 { get; set; }
        public bool IsDisableCreateNewLoanStep2IdentificationCo3 { get; set; }

        private List<CompanyInformationViewModel> _objCreateNewLoanStep2CompanyCo3 = new List<CompanyInformationViewModel>();
        public List<CompanyInformationViewModel> lstCreateNewLoanStep2CompanyCo3
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo3;
            }
            set { _objCreateNewLoanStep2CompanyCo3 = value; }
        }
        public bool IsVisibleCreateNewLoanStep2CompanyCo3 { get; set; }
        public bool IsDisableCreateNewLoanStep2CompanyCo3 { get; set; }
        #endregion

        #region Company
        public int? CompanyNameID { get; set; }
        public string CompanyName  { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCodeRLS { get; set; }
        public bool IsVisibleCompanyCodeRLS { get; set; }
        public bool IsDisableCompanyCodeRLS { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string CompanyPhone { get; set; }
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public string CompanyEmail { get; set; }
        public bool IsVisibleCompanyEmail { get; set; }
        public bool IsDisableCompanyEmail { get; set; }

        public int? CompanyTypeID { get; set; }
        public string CompanyType { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public int? CustomerSCRelationshipID { get; set; }
        public string CustomerSCRelationship { get; set; }
        public bool IsVisibleCustomerSCRelationship { get; set; }
        public bool IsDisableCustomerSCRelationship { get; set; }

        public string TaxNumber { get; set; }
        public bool IsVisibleTaxNumber { get; set; }
        public bool IsDisableTaxNumber { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public string CompanyRemark { get; set; }
        public bool IsVisibleCompanyRemark { get; set; }
        public bool IsDisableCompanyRemark { get; set; }

        public bool IsActiveCompany { get; set; }
        #endregion

        #region LegalRepresentative
        public int? IntitialID { get; set; }
        public string Intitial { get; set; }
        public bool IsVisibleIntitial { get; set; }
        public bool IsDisableIntitial { get; set; }

        public int? LegalRepresentativeID { get; set; }
        public string LegalRepresentativeName { get; set; }
        public bool IsVisibleLegalRepresentative { get; set; }
        public bool IsDisableLegalRepresentative { get; set; }

        public int? LegalRepresentativeNationalityID { get; set; }
        public string LegalRepresentativeNationalityName { get; set; }
        public bool IsVisibleLegalLegalRepresentativeNationality { get; set; }
        public bool IsDisableLegalLegalRepresentativeNationality { get; set; }

        public Nullable<DateTime> LegalRepresentativeDateOfBirth { get; set; }
        public bool IsVisibleLegalRepresentativeDateOfBirth { get; set; }
        public bool IsDisableLegalRepresentativeDateOfBirth { get; set; }

        public bool IsActiveLegalRepresentative { get; set; }

        private List<CustomerIdentificationViewModel> _objCreateNewLoanStep2IdentificationLegalRepresentative = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> lstCreateNewLoanStep2IdentificationLegalRepresentative
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationLegalRepresentative;
            }
            set { _objCreateNewLoanStep2IdentificationLegalRepresentative = value; }
        }
        public bool IsVisibleCreateNewLoanStep2IdentificationLegalRepresentative { get; set; }
        public bool IsDisableCreateNewLoanStep2IdentificationLegalRepresentative { get; set; }
        #endregion

        #region MetaData
        private List<IdentificationTypeViewModel> _objIdentificationTypeViewModel = new List<IdentificationTypeViewModel>();
        public List<IdentificationTypeViewModel> _M_IdentificationTypeViewModel
        {
            get
            {
                return _objIdentificationTypeViewModel;
            }
            set { _objIdentificationTypeViewModel = value; }
        }

        private List<CompanyTypeViewModel> _objCompanyTypeViewModel = new List<CompanyTypeViewModel>();
        public List<CompanyTypeViewModel> _M_CompanyTypeViewModel
        {
            get
            {
                return _objCompanyTypeViewModel;
            }
            set { _objCompanyTypeViewModel = value; }
        }

        private List<DistrictViewModel> _M_objDistrictViewModel = new List<DistrictViewModel>();
        public List<DistrictViewModel> _M_DistrictViewModel
        {
            get
            {
                return _M_objDistrictViewModel;
            }
            set { _M_objDistrictViewModel = value; }
        }

        private List<CityViewModel> _M_objCityViewModel = new List<CityViewModel>();
        public List<CityViewModel> _M_CityViewModel
        {
            get
            {
                return _M_objCityViewModel;
            }
            set { _M_objCityViewModel = value; }
        }

        private List<NationalityViewModel> _M_objNationalityViewModel = new List<NationalityViewModel>();
        public List<NationalityViewModel> _M_NationalityViewModel
        {
            get
            {
                return _M_objNationalityViewModel;
            }
            set { _M_objNationalityViewModel = value; }
        }

        private List<DefinitionTypeViewModel> _M_objInitialViewModel = new List<DefinitionTypeViewModel>();
        public List<DefinitionTypeViewModel> _M_InitialViewModel
        {
            get
            {
                return _M_objInitialViewModel;
            }
            set { _M_objInitialViewModel = value; }
        }

        private List<CustomerRelationshipViewModel> _M_objCustomerRelationshipViewModel = new List<CustomerRelationshipViewModel>();
        public List<CustomerRelationshipViewModel> _M_CustomerRelationshipViewModel
        {
            get
            {
                return _M_objCustomerRelationshipViewModel;
            }
            set { _M_objCustomerRelationshipViewModel = value; }
        }
        #endregion
    }        
}
