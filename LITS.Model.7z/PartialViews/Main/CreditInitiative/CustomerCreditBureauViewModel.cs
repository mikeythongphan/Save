﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.AutoLoan;

namespace LITS.Model.PartialViews.Main.CreditInitiative
{
    public class CustomerCreditBureauViewModel
    {
        private CustomerCreditBureauDetailViewModel _objCustomerCreditBureauDetailViewModel_Main = new CustomerCreditBureauDetailViewModel();
        public CustomerCreditBureauDetailViewModel _CustomerCreditBureauDetailViewModel_Main
        {
            get
            {
                return _objCustomerCreditBureauDetailViewModel_Main;
            }
            set { _objCustomerCreditBureauDetailViewModel_Main = value; }
        }

        private CustomerCreditBureauDetailViewModel _objCustomerCreditBureauDetailViewModel_Co1 = new CustomerCreditBureauDetailViewModel();
        public CustomerCreditBureauDetailViewModel _CustomerCreditBureauDetailViewModel_Co1
        {
            get
            {
                return _objCustomerCreditBureauDetailViewModel_Co1;
            }
            set { _objCustomerCreditBureauDetailViewModel_Co1 = value; }
        }

        private CustomerCreditBureauDetailViewModel _objCustomerCreditBureauDetailViewModel_Co2 = new CustomerCreditBureauDetailViewModel();
        public CustomerCreditBureauDetailViewModel _CustomerCreditBureauDetailViewModel_Co2
        {
            get
            {
                return _objCustomerCreditBureauDetailViewModel_Co2;
            }
            set { _objCustomerCreditBureauDetailViewModel_Co2 = value; }
        }

        private CustomerCreditBureauDetailViewModel _objCustomerCreditBureauDetailViewModel_Co3 = new CustomerCreditBureauDetailViewModel();
        public CustomerCreditBureauDetailViewModel _CustomerCreditBureauDetailViewModel_Co3
        {
            get
            {
                return _objCustomerCreditBureauDetailViewModel_Co3;
            }
            set { _objCustomerCreditBureauDetailViewModel_Co3 = value; }
        }

        public decimal TotalCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsVisibleTotalCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsDisableTotalCurrentMonthlyIndividualObligationRepayment { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }

    public class CustomerCreditBureauDetailViewModel
    {
        #region PK-FK
        public int ID { get; set; }

        public int ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        public int CustomerInformationID { get; set; }
        public int ALCustomerInformationID { get; set; }
        #endregion

        public int BureauDataLoanCurrent { get; set; }
        public bool IsVisibleBureauDataLoanCurrent { get; set; }
        public bool IsDisableBureauDataLoanCurrent { get; set; }

        public int BureauDataLoanHistory { get; set; }
        public bool IsVisibleBureauDataLoanHistory { get; set; }
        public bool IsDisableBureauDataLoanHistory { get; set; }

        public int BureauDataCardCurrent { get; set; }
        public bool IsVisibleBureauDataCardCurrent { get; set; }
        public bool IsDisableBureauDataCardCurrent { get; set; }

        public int BureauDataCardHistory { get; set; }
        public bool IsVisibleBureauDataCardHistory { get; set; }
        public bool IsDisableBureauDataCardHistory { get; set; }

        public string CreditBureauType { get; set; }
        public bool IsVisibleCreditBureauType { get; set; }
        public bool IsDisableCreditBureauType { get; set; }
        public int CreditBureauTypeID { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs { get; set; }

        public decimal CurrentTotalEMIOnUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs { get; set; }

        public decimal CurrentTotalEMIOfUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs { get; set; }

        public decimal CurrentUnsecureLimitOnUs { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs { get; set; }

        public decimal TotalOutStandingBalanceCreditCard { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard { get; set; }

        public decimal TotalLimitCreditCard { get; set; }
        public bool IsVisibleTotalLimitCreditCard { get; set; }
        public bool IsDisableTotalLimitCreditCard { get; set; }

        public decimal CurrentCardUtilization { get; set; }
        public bool IsVisibleCurrentCardUtilization { get; set; }
        public bool IsDisableCurrentCardUtilization { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        private List<LoanBureauViewModel> _objLoanBureauViewModel = new List<LoanBureauViewModel>();
        public List<LoanBureauViewModel> _LoanBureauViewModel
        {
            get
            {
                return _objLoanBureauViewModel;
            }
            set { _objLoanBureauViewModel = value; }
        }

        private List<LoanBureauViewModel> _objCardBureauViewModel = new List<LoanBureauViewModel>();
        public List<LoanBureauViewModel> _CardBureauViewModel
        {
            get
            {
                return _objCardBureauViewModel;
            }
            set { _objCardBureauViewModel = value; }
        }
    }
}
