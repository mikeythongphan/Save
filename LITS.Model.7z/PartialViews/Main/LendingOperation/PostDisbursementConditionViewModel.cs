﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.LendingOperation
{
    public class PostDisbursementConditionViewModel
    {
        public bool IsActive { get; set; }
        public Nullable<System.DateTime> PostDisbursementConditionExpiryDate { get; set; }
        public bool IsVisiblePostDisbursementConditionExpiryDate { get; set; }
        public bool IsDisablePostDisbursementConditionExpiryDate { get; set; }
    }
}
