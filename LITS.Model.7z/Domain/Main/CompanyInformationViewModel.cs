﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.Main
{
    public class CompanyInformationViewModel
    {
        public int? GUIID { get; set; }

        public int? CompanyID { get; set; }

        [Required(ErrorMessage = "Required field")]
        [StringLength(1000, ErrorMessage = "Max {1} character")]
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyShortName { get; set; }
        public bool IsVisibleCompanyShortName { get; set; }
        public bool IsDisableCompanyShortName { get; set; }

        [Required(ErrorMessage = "Required field")]
        [StringLength(1000, ErrorMessage = "Max {1} character")]
        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        [Required(ErrorMessage = "Required field")]
        [StringLength(1000, ErrorMessage = "Max {1} character")]
        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyType { get; set; }

        [Required(ErrorMessage = "Required field")]
        public int? CompanyTypeID { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public string CompanyStatus { get; set; }
        public int? CompanyStatusID { get; set; }
        public bool IsVisibleCompanyStatus { get; set; }
        public bool IsDisableCompanyStatus { get; set; }

        public string CompanyAddress { get; set; }        
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public string CompanyDistrict { get; set; }
        public int? CompanyDistrictID { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public string CompanyCity { get; set; }
        public int? CompanyCityD { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string ReasonCompany { get; set; }
        public int? ReasonCompanyID { get; set; }
        public bool IsVisibleReasonCompany { get; set; }
        public bool IsDisableReasonCompany { get; set; }        

        public string CompanyPhone { get; set; }        
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public string CompanyFax { get; set; }
        public bool IsVisibleCompanyFax { get; set; }
        public bool IsDisableCompanyFax { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public string CompanyNameVN { get; set; }
        public bool IsVisibleCompanyNameVN { get; set; }
        public bool IsDisableCompanyNameVN { get; set; }

        public string TaxCode { get; set; }
        public bool IsVisibleTaxCode { get; set; }
        public bool IsDisableTaxCode { get; set; }

        public string BusinessLicense { get; set; }
        public bool IsVisibleBusinessLicense { get; set; }
        public bool IsDisableBusinessLicense { get; set; }

        public string Note { get; set; }
        public bool IsVisibleNote { get; set; }
        public bool IsDisableNote { get; set; }

        public string Remarks { get; set; }
        public bool IsVisibleRemarks { get; set; }
        public bool IsDisableRemarks { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public Nullable<System.DateTime> DateOfIncorporate { get; set; }
        public bool IsVisibleDateOfIncorporate { get; set; }
        public bool IsDisableDateOfIncorporate { get; set; }

        public int? NumberOfChange { get; set; }
        public bool IsVisibleNumberOfChange { get; set; }
        public bool IsDisableNumberOfChange { get; set; }

        public int? BusinessNatureID { get; set; }
        public string BusinessNature { get; set; }
        public bool IsVisibleBusinessNature { get; set; }
        public bool IsDisableBusinessNature { get; set; }

        public int? CustomerRelationshipID { get; set; }
        public string CustomerRelationship { get; set; }
        public bool IsVisibleCustomerRelationship { get; set; }
        public bool IsDisableCustomerRelationship { get; set; }

        public int? IndustryID { get; set; }
        public string Industry { get; set; }
        public bool IsVisibleIndustry { get; set; }
        public bool IsDisableIndustry { get; set; }

        public int? TotalMonthsInOperation { get; set; }
        public bool IsVisibleTotalMonthsInOperation { get; set; }
        public bool IsDisableTotalMonthsInOperation { get; set; }

        public decimal? RegisteredCapital { get; set; }
        public bool IsVisibleTotalRegisteredCapital { get; set; }
        public bool IsDisableTotalRegisteredCapital { get; set; }

        public int? NumberOfBanksUsage { get; set; }
        public bool IsVisibleNumberOfBanksUsage { get; set; }
        public bool IsDisableNumberOfBanksUsage { get; set; }

        public string BillingAddress { get; set; }
        public bool IsVisibleBillingAddress { get; set; }
        public bool IsDisableBillingAddress { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string Customer { get; set; }
        public int? CustomerID { get; set; }
        public bool IsVisibleCustomer { get; set; }
        public bool IsDisableCustomer { get; set; }

        public string CustomerIncome { get; set; }
        public int? CustomerIncomeID { get; set; }
        public bool IsVisibleCustomerIncome { get; set; }
        public bool IsDisableCustomerIncome { get; set; }

        public Nullable<System.DateTime> EffectiveFromDate { get; set; }
        public bool IsVisibleEffectiveFromDate { get; set; }
        public bool IsDisableEffectiveFromDate { get; set; }

        public Nullable<System.DateTime> EffectiveToDate { get; set; }
        public bool IsVisibleEffectiveToDate { get; set; }
        public bool IsDisableEffectiveToDate { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool? IsActive { get; set; }

        public bool? IsPromotion { get; set; }
        public bool IsVisibleIsPromotion { get; set; }
        public bool IsDisableIsPromotion { get; set; }

        public Nullable<System.DateTime> LatestDateUpdateBusinessLicense { get; set; }
        public bool IsVisibleLatestDateUpdateBusinessLicense { get; set; }
        public bool IsDisableLatestDateUpdateBusinessLicense { get; set; }

        public string ProcessedBy { get; set; }
        public bool IsVisibleProcessedBy { get; set; }
        public bool IsDisableProcessedBy { get; set; }

        public Nullable<System.DateTime> ProcessedDate { get; set; }
        public bool IsVisibleProcessedDate { get; set; }
        public bool IsDisableProcessedDate { get; set; }

        public decimal? RateOffer { get; set; }
        public bool IsVisibleRateOffer { get; set; }
        public bool IsDisableRateOffer { get; set; }
    }
}
