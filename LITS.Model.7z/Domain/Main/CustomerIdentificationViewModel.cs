﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.Main
{
    public class CustomerIdentificationViewModel
    {        
        public int? ID { get; set; }

        public int? GUIID { get; set; }

        public int ApplicationInformationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplication { get; set; }
        public bool IsDisableApplication { get; set; }

        public int CustomerInformationID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }               

        public int? ApplicationStatusID { get; set; }
        public string ApplicationStatus { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string IdentificationNo { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int? IdentificationTypeID { get; set; }
        public string IdentificationType { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public Nullable<System.DateTime> IssuedDate { get; set; }
        public bool IsVisibleIssuedDate { get; set; }
        public bool IsDisableIssuedDate { get; set; }

        public Nullable<System.DateTime> ExpriedDate { get; set; }
        public bool IsVisibleExpriedDate { get; set; }
        public bool IsDisableExpriedDate { get; set; }

        public Nullable<System.DateTime> WorkPermit { get; set; }
        public bool IsVisibleWorkPermit { get; set; }
        public bool IsDisableWorkPermit { get; set; }

        public Nullable<System.DateTime> DOB { get; set; }
        public bool IsVisibleDOB { get; set; }
        public bool IsDisableDOB { get; set; }

        public string PlaceOfIssuance { get; set; }
        public bool IsVisiblePlaceOfIssuance { get; set; }
        public bool IsDisablePlaceOfIssuance { get; set; }

        public int? NationalityID { get; set; }
        public string Nationality { get; set; }
        public bool IsVisibleNationality { get; set; }
        public bool IsDisableNationality { get; set; }

        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
