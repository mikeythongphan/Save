﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.Main
{
    public class CustomerBlacklistViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public string IdentificationType { get; set; }
        public int? IdentificationTypeID { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public string IdentificationNo { get; set; }
        public int? IdentificationNoID { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public Nullable<DateTime> DateOfBirth { get; set; }
        public bool IsVisibleDateOfBirth { get; set; }
        public bool IsDisableDateOfBirth { get; set; }

        public DateTime? ReceivedDate { get; set; }
        public bool IsVisibleReceivedDate { get; set; }
        public bool IsDisableReceivedDate { get; set; }

        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
