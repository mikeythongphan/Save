﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.Main
{
    public class CompanyBlacklistViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCodeRLS { get; set; }
        public bool IsVisibleCompanyCodeRLS { get; set; }
        public bool IsDisableCompanyCodeRLS { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string CompanyPhone { get; set; }
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public int? CompanyTypeID { get; set; }
        public string CompanyType { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public string TaxNumber { get; set; }
        public bool IsVisibleTaxNumber { get; set; }
        public bool IsDisableTaxNumber { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public string CompanyRemark { get; set; }
        public bool IsVisibleCompanyRemark { get; set; }
        public bool IsDisableCompanyRemark { get; set; }

        public DateTime? ReceivedDate { get; set; }
        public bool IsVisibleReceivedDate { get; set; }
        public bool IsDisableReceivedDate { get; set; }

        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
