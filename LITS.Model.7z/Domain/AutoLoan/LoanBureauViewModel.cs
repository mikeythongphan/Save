﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.AutoLoan
{
    public class LoanBureauViewModel
    {
        #region PK-FK
        public int ID { get; set; }

        public int ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        public int CustomerInformationID { get; set; }
        public int ALCustomerInformationID { get; set; }
        public int ALCustomerCreditBureauID { get; set; }
        #endregion

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
