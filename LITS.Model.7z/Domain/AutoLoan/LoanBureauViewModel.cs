﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.AutoLoan
{
    public class LoanBureauViewModel
    {
        #region PK-FK
        public int? GUIID { get; set; }
        public int? ID { get; set; }
        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }
        public int? ApplicationInformationID { get; set; }
        public int? ALApplicationInformationID { get; set; }
        public int? CustomerInformationID { get; set; }
        public int? ALCustomerInformationID { get; set; }
        public int? ALCustomerCreditBureauID { get; set; }
        #endregion
        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
        public string secured_type { get; set; }
        public string group_loan_name { get; set; }
        public int? no_of_delinquency { get; set; }
        public decimal? initial_loan { get; set; }
        public decimal? interest_rate { get; set; }
        public decimal? outstanding { get; set; }
        public decimal? emi { get; set; }
        public string source { get; set; }
        public int? fk_m_tenor_id { get; set; }
        public int? fk_al_customer_credit_bureau_id { get; set; }
        public string bank { get; set; }
        public bool? is_auto_cal_emi { get; set; }
        public bool? is_scb_loan { get; set; }
        public int? fk_type_id { get; set; }
        public int? fk_status_id { get; set; }
        public int? fk_customer_information_id { get; set; }
        public DateTime? date_of_cic_results { get; set; }
    }
}
