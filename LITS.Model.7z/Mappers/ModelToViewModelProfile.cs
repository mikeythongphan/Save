﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using LITS.Infrastructure.Context;

namespace LITS.Model.Mappers
{
    public class ModelToViewModelProfile : Profile
    {
        public ModelToViewModelProfile()
        {
            #region Main

            #region WorkInProgress
            //CreateMap<PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel,Tuple<customer_information, customer_identification>>()
            //.ForMember(dest => dest.Item1.pk_id, opts => opts.MapFrom(src => src.CustomerID))
            //.ForMember(dest => dest.Item1.full_name, opts => opts.MapFrom(src => src.CustomerName))
            //.ForMember(dest => dest.Item2.fk_customer_information_id, opts => opts.MapFrom(src => src.CustomerID))
            //.ForMember(dest => dest.Item2.identification_no, opts => opts.MapFrom(src => src.CustomerIdentification))
            //;
            
            //var aMap = CreateMap<PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel, customer_information>()
            //.ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.CustomerID))
            //.ForMember(dest => dest.full_name, opts => opts.MapFrom(src => src.CustomerName))            
            //;

            //aMap.ForAllOtherMembers(dest => dest.Ignore());

            //CreateMap<PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel, customer_identification>()
            //.ForMember(dest => dest.fk_customer_information_id, opts => opts.MapFrom(src => src.CustomerID))
            //.ForMember(dest => dest.identification_no, opts => opts.MapFrom(src => src.CustomerIdentification))
            //;

            //CreateMap<PartialViews.Main.WorkInProgress.WorkInProgressMasterCompanyViewModel, m_company_code>()
            //.ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.CompanyID))
            //.ForMember(dest => dest.company_code, opts => opts.MapFrom(src => src.CompanyCode))
            //.ForMember(dest => dest.name, opts => opts.MapFrom(src => src.CompanyName))
            //;

            CreateMap<PartialViews.Main.WorkInProgress.WorkInProgressTreeViewModel, m_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive));
            #endregion

            #region CreateNewLoan
            CreateMap<PartialViews.Main.CreateNewLoan.CreateNewLoanStep1TreeViewModel, m_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive));
            #endregion
            #region ReportsChart

            CreateMap<PartialViews.Main.ReportsChart.ReportsChartTreeViewModel, m_type>()
           .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
           .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
           .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
           .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive));

            #endregion

            #region ReportsExport

            CreateMap<PartialViews.Main.ReportsExport.ReportsExportTreeViewModel, m_type>()
           .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
           .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
           .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
           .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive));

            #endregion

            #endregion

            #region Management
            CreateMap<Model.Views.Management.BankHolidayViewModel, m_bank_holiday>()
             .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
             .ForMember(dest => dest.bank_holiday, opts => opts.MapFrom(src => src.BankHoliday))
             .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.DescriptionBankHoliday))
             .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
             .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
             .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
             .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
             .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BankTypeViewModel, m_bank_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BranchCodeViewModel, m_branch_code>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BranchLocationViewModel, m_branch_location>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BusinessNatureViewModel, m_business_nature>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BusinessTypeViewModel, m_business_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CampaignCodeViewModel, m_campaign_code>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BankTypeViewModel, m_bank_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CDDViewModel, m_cdd>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CicViewModel, m_cic>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CityViewModel, m_city>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CommisionTypeViewModel, m_commision_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CompanyCodeViewModel, m_company_code>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CompanyTypeViewModel, m_company_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CreditBureauTypeViewModel, m_credit_bureau_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CreditDeviationViewModel, m_credit_deviation>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CriteriaViewModel, m_criteria>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CurrentResidentTypeViewModel, m_current_resident_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CustodyTypeViewModel, m_custody_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CustomerRelationshipViewModel, m_customer_relationship>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CustomerSegmentViewModel, m_customer_segment>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.CustomerTypeViewModel, m_customer_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.DeviationCodeViewModel, m_deviation_code>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.DistrictViewModel, m_district>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.DuplicationTypeViewModel, m_duplication_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.EducationViewModel, m_education>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.EmploymentTypeViewModel, m_employment_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.FloatingInterestRateViewModel, m_floating_interest_rate>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.IncomeTypeViewModel, m_income_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.IndustryViewModel, m_industry>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.InterestClassificationViewModel, m_interest_classification>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.InvestigaveTypeViewModel, m_investigave_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.LabourContractTypeViewModel, m_labour_contract_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.LoanPurposeViewModel, m_loan_purpose>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.LoanTenorViewModel, m_loan_tenor>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.value, opts => opts.MapFrom(src => src.Value))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.LoanTrendViewModel, m_loan_trend>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.LoanTypeViewModel, m_loan_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.MaritalStatusViewModel, m_marital_status>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.NationalityViewModel, m_nationality>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BankTypeViewModel, m_bank_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.OccupationViewModel, m_occupation>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.OwnershipTypeViewModel, m_ownership_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BankTypeViewModel, m_bank_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));


            CreateMap<Model.Views.Management.PaymentTypeViewModel, m_payment_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.PositionViewModel, m_position>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.ProductViewModel, m_product>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.ProgramCodeViewModel, m_program_code>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.ProgramTypeViewModel, m_program_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.PropertySaleViewModel, m_property_sale>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.PropertyStatusViewModel, m_property_status>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.BankTypeViewModel, m_bank_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.PropertyTypeViewModel, m_property_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.ReasonViewModel, m_reason>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.ResidenceOwnershipViewModel, m_residence_ownership>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.SalesChannelViewModel, m_sales_channel>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.StatusViewModel, m_status>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_product_id, opts => opts.MapFrom(src => src.ProductID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.TradingAreaViewModel, m_trading_area>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy));

            CreateMap<Model.Views.Management.TypeViewModel, m_type>()
           .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
           .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
           .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
           .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
           .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
           .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
           .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy))           
           ;

            CreateMap<Model.Views.Management.DefinitionTypeViewModel, m_definition_type>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ID))
            .ForMember(dest => dest.name, opts => opts.MapFrom(src => src.Name))
            .ForMember(dest => dest.description, opts => opts.MapFrom(src => src.Description))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.TypeID))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.StatusID))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy))
            .ForMember(dest => dest.parent_id, opts => opts.MapFrom(src => src.ParentID))
            .ForMember(dest => dest.code, opts => opts.MapFrom(src => src.Code))
            .ForMember(dest => dest.updated_date, opts => opts.MapFrom(src => src.UpdatedDate))
            .ForMember(dest => dest.updated_by, opts => opts.MapFrom(src => src.UpdatedBy))
            .ForMember(dest => dest.fk_group_id, opts => opts.MapFrom(src => src.GroupID))
            .ForMember(dest => dest.valid_from_date, opts => opts.MapFrom(src => src.ValidFromDate))
            .ForMember(dest => dest.valid_to_date, opts => opts.MapFrom(src => src.ValidToDate))
            ;
            #endregion

            #region Auto Loan
            #region SalesCoordinators
            CreateMap<application_information, PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel>()
            .ForMember(dest => dest.ApplicationInformationID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ApplicationNo, opts => opts.MapFrom(src => src.application_no))
            .ForMember(dest => dest.ReceivingDate, opts => opts.MapFrom(src => src.received_date))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.ARMCode, opts => opts.MapFrom(src => src.arm_code))            
            .ForMember(dest => dest.SalesCode, opts => opts.MapFrom(src => src.sales_code))
            .ForMember(dest => dest.ICT, opts => opts.MapFrom(src => src.ict))
            .ForMember(dest => dest.PeoplewiseIDofSaleStaf, opts => opts.MapFrom(src => src.sale_staff_bank_id))
            .ForMember(dest => dest.ApplicationTypeID, opts => opts.MapFrom(src => src.fk_m_type_id))
            .ForMember(dest => dest.ApplicationStatusID, opts => opts.MapFrom(src => src.fk_m_status_id))
            .ForMember(dest => dest.BranchCodeID, opts => opts.MapFrom(src => src.fk_m_branch_code_id))
            .ForMember(dest => dest.BranchLocationID, opts => opts.MapFrom(src => src.fk_m_branch_location_id))
            .ForMember(dest => dest.CustomerTypeID, opts => opts.MapFrom(src => src.fk_m_customer_type_id))
            .ForMember(dest => dest.ProductTypeID, opts => opts.MapFrom(src => src.fk_m_product_id))
            .ForMember(dest => dest.ProgramTypeID, opts => opts.MapFrom(src => src.fk_m_program_type_id))
            .ForMember(dest => dest.CustomerSegmentID, opts => opts.MapFrom(src => src.fk_m_customer_type_id))
            .ForMember(dest => dest.TradingAreaID, opts => opts.MapFrom(src => src.fk_m_trading_area_id))
            .ForMember(dest => dest.ReasonForReworkID, opts => opts.MapFrom(src => src.fk_m_reason_rework_id))
            .ForMember(dest => dest.CustomerSegmentID, opts => opts.MapFrom(src => src.fk_m_customer_segment_id))
            .ForMember(dest => dest.CDDID, opts => opts.MapFrom(src => src.fk_m_cdd_id))
            .ForMember(dest => dest.ChannelID, opts => opts.MapFrom(src => src.fk_m_sales_channel_id))
            .ForMember(dest => dest.EOpsTxnReference, opts => opts.MapFrom(src => src.eops_txn_ref_no_1))
            .ForMember(dest => dest.ExpectingDisbursedDate, opts => opts.MapFrom(src => src.expecting_disbursed_date))
            .ForMember(dest => dest.HardCopyApplicationDate, opts => opts.MapFrom(src => src.hard_copy_app_date))
            .ForMember(dest => dest.IsStafNonStaf, opts => opts.MapFrom(src => src.is_staff))
            .ForMember(dest => dest.IsRework, opts => opts.MapFrom(src => src.is_rework))
            .ForMember(dest => dest.IsBlackList, opts => opts.MapFrom(src => src.is_black_list))
            .ForMember(dest => dest.IsExisting, opts => opts.MapFrom(src => src.is_existing))
            ;
            #endregion

            #region OperationSupport
            CreateMap<application_information, PartialViews.AutoLoan.OperationSupport.ApplicationInformationViewModel>()
            .ForMember(dest => dest.ApplicationNo, opts => opts.MapFrom(src => src.application_no))
            .ForMember(dest => dest.ReceivingDate, opts => opts.MapFrom(src => src.received_date))
            //.ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            //.ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.ARMCode, opts => opts.MapFrom(src => src.arm_code))
            .ForMember(dest => dest.BranchCodeID, opts => opts.MapFrom(src => src.fk_m_branch_code_id))
            .ForMember(dest => dest.BranchLocationID, opts => opts.MapFrom(src => src.fk_m_branch_location_id))
            .ForMember(dest => dest.CustomerTypeID, opts => opts.MapFrom(src => src.fk_m_customer_type_id))
            .ForMember(dest => dest.ProductTypeID, opts => opts.MapFrom(src => src.fk_m_product_id))
            .ForMember(dest => dest.ProgramTypeID, opts => opts.MapFrom(src => src.fk_m_program_type_id))
            .ForMember(dest => dest.CustomerSegmentID, opts => opts.MapFrom(src => src.fk_m_customer_type_id))
            .ForMember(dest => dest.TradingAreaID, opts => opts.MapFrom(src => src.fk_m_trading_area_id))
            .ForMember(dest => dest.EOpsTxnReference, opts => opts.MapFrom(src => src.eops_txn_ref_no_1))
            .ForMember(dest => dest.ExpectingDisbursedDate, opts => opts.MapFrom(src => src.expecting_disbursed_date))
            .ForMember(dest => dest.HardCopyApplicationDate, opts => opts.MapFrom(src => src.hard_copy_app_date))
            ;
            #endregion
            #endregion
        }
    }
}
