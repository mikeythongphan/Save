﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using LITS.Infrastructure.Context;

namespace LITS.Model.Mappers
{
    public class ViewModelToModelProfile : Profile
    {
        public ViewModelToModelProfile()
        {
            #region Main

            #region SalesCoordinators
            CreateMap<PartialViews.Main.SalesCoordinators.ApplicationInformationViewModel, application_information>()
            .ForMember(dest => dest.arm_code, opts => opts.MapFrom(src => src.ArmCode))
            .ForMember(dest => dest.received_date, opts => opts.MapFrom(src => src.ReceivedDate))
            .ForMember(dest => dest.sale_staff_bank_id, opts => opts.MapFrom(src => src.SaleStaffBankID))
            .ForMember(dest => dest.sale_staff_name, opts => opts.MapFrom(src => src.SaleStaffName))
            ;

            CreateMap<PartialViews.Main.SalesCoordinators.CustomerInformationViewModel, customer_information>();
            #endregion

            #region WorkInProgress
            CreateMap<m_type, PartialViews.Main.WorkInProgress.WorkInProgressTreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;

            CreateMap<customer_information, PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CustomerName, opts => opts.MapFrom(src => src.full_name))
            .ForMember(dest => dest.CustomerIdentification, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<customer_identification, PartialViews.Main.WorkInProgress.WorkInProgressMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.fk_customer_information_id))
            .ForMember(dest => dest.CustomerIdentification, opts => opts.MapFrom(src => src.identification_no))
            .ForMember(dest => dest.CustomerName, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<m_company_code, PartialViews.Main.WorkInProgress.WorkInProgressMasterCompanyViewModel>()
            .ForMember(dest => dest.CompanyID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CompanyCode, opts => opts.MapFrom(src => src.company_code))
            .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.name))
            ;
            #endregion

            #region ReportsChart
            CreateMap<m_type, PartialViews.Main.ReportsChart.ReportsChartTreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;

            CreateMap<customer_information, PartialViews.Main.ReportsChart.ReportsChartMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CustomerName, opts => opts.MapFrom(src => src.full_name))
            .ForMember(dest => dest.CustomerIdentification, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<customer_identification, PartialViews.Main.ReportsChart.ReportsChartMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.fk_customer_information_id))
            .ForMember(dest => dest.CustomerIdentification, opts => opts.MapFrom(src => src.identification_no))
            .ForMember(dest => dest.CustomerName, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<m_company_code, PartialViews.Main.ReportsChart.ReportsChartMasterCompanyViewModel>()
            .ForMember(dest => dest.CompanyID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CompanyCode, opts => opts.MapFrom(src => src.company_code))
            .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.name))
            ;
            #endregion

            #region ReportsExport
            CreateMap<m_type, PartialViews.Main.ReportsExport.ReportsExportTreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;

            CreateMap<customer_information, PartialViews.Main.ReportsExport.ReportsExportMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CustomerName, opts => opts.MapFrom(src => src.full_name))
            .ForMember(dest => dest.CustomerIdentification, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<customer_identification, PartialViews.Main.ReportsExport.ReportsExportMasterCustomerViewModel>()
            .ForMember(dest => dest.CustomerID, opts => opts.MapFrom(src => src.fk_customer_information_id))
            .ForMember(dest => dest.CustomerIdentification, opts => opts.MapFrom(src => src.identification_no))
            .ForMember(dest => dest.CustomerName, opt =>
            {
                opt.UseDestinationValue();
                opt.Ignore();
            })
            ;

            CreateMap<m_company_code, PartialViews.Main.ReportsExport.ReportsExportMasterCompanyViewModel>()
            .ForMember(dest => dest.CompanyID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.CompanyCode, opts => opts.MapFrom(src => src.company_code))
            .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.name))
            ;
            #endregion

            #region CreateNewLoan
            CreateMap<m_type, PartialViews.Main.CreateNewLoan.CreateNewLoanStep1TreeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            ;
            #endregion

            #region Domain
            CreateMap<company_information, Model.Domain.Main.CompanyInformationViewModel>()
             .ForMember(dest => dest.CompanyID, opts => opts.MapFrom(src => src.pk_id))
             .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.name))
             .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
             .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
             .ForMember(dest => dest.ApplicationTypeID, opts => opts.MapFrom(src => src.fk_type_id))
             .ForMember(dest => dest.CompanyStatusID, opts => opts.MapFrom(src => src.fk_status_id))
             .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
             .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
             .ForMember(dest => dest.CompanyTypeID, opts => opts.MapFrom(src => src.fk_m_company_type_id))
             .ForMember(dest => dest.CompanyCode, opts => opts.MapFrom(src => src.company_code))
             .ForMember(dest => dest.CompanyAddress, opts => opts.MapFrom(src => src.company_address))
             .ForMember(dest => dest.CompanyWard, opts => opts.MapFrom(src => src.company_ward))
             .ForMember(dest => dest.CompanyCAT, opts => opts.MapFrom(src => src.company_cat))
             .ForMember(dest => dest.CompanyCityD, opts => opts.MapFrom(src => src.fk_company_city_id))
             .ForMember(dest => dest.CompanyDistrictID, opts => opts.MapFrom(src => src.fk_company_district_id))             
            ;

            CreateMap<application_duplication, Model.Domain.Main.ApplicationDuplicationViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ApplicationInformationDuplicationID, opts => opts.MapFrom(src => src.fk_application_information_duplication_id))
            .ForMember(dest => dest.ApplicationInformationID, opts => opts.MapFrom(src => src.fk_application_information_id))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.ApplicationTypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.DuplicationTypeID, opts => opts.MapFrom(src => src.fk_m_duplication_type_id))
            .ForMember(dest => dest.CreatedDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreatedBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))            
           ;
            #endregion

            #endregion

            #region Management
            CreateMap<m_bank_holiday, Model.Views.Management.BankHolidayViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
             .ForMember(dest => dest.BankHoliday, opts => opts.MapFrom(src => src.bank_holiday))
             .ForMember(dest => dest.DescriptionBankHoliday, opts => opts.MapFrom(src => src.description))
             .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
             .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
             .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
             .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
             .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
             .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_branch_code, Model.Views.Management.BranchCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_branch_location, Model.Views.Management.BranchLocationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_business_nature, Model.Views.Management.BusinessNatureViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_business_type, Model.Views.Management.BusinessTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_campaign_code, Model.Views.Management.CampaignCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_cdd, Model.Views.Management.CDDViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_cic, Model.Views.Management.CicViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_city, Model.Views.Management.CityViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_commision_type, Model.Views.Management.CommisionTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_company_code, Model.Views.Management.CompanyCodeViewModel>()
           .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_company_type, Model.Views.Management.CompanyTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_credit_bureau_type, Model.Views.Management.CreditBureauTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_credit_deviation, Model.Views.Management.CreditDeviationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_criteria, Model.Views.Management.CriteriaViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_current_resident_type, Model.Views.Management.CurrentResidentTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_custody_type, Model.Views.Management.CustodyTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_customer_relationship, Model.Views.Management.CustomerRelationshipViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_customer_segment, Model.Views.Management.CustomerSegmentViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_customer_type, Model.Views.Management.CustomerTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_deviation_code, Model.Views.Management.DeviationCodeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_disbursal_scenario, Model.Views.Management.DisbursalScenarioViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ScenarioVN, opts => opts.MapFrom(src => src.scenario_vn))
            .ForMember(dest => dest.ScenarioEn, opts => opts.MapFrom(src => src.scenario_en))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            .ForMember(dest => dest.LoanTypeID, opts => opts.MapFrom(src => src.fk_loan_type_id))
            ;

            CreateMap<m_disbursal_scenario_condition, Model.Views.Management.DisbursalScenarioConditionViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.PostCondition, opts => opts.MapFrom(src => src.post_condition))
            .ForMember(dest => dest.PreCondition, opts => opts.MapFrom(src => src.pre_condition))
            .ForMember(dest => dest.InCondition, opts => opts.MapFrom(src => src.in_condition))
            .ForMember(dest => dest.PostConditionVN, opts => opts.MapFrom(src => src.post_condition_vn))
            .ForMember(dest => dest.PreConditionVN, opts => opts.MapFrom(src => src.pre_condition_vn))
            .ForMember(dest => dest.InConditionVN, opts => opts.MapFrom(src => src.in_condition_vn))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            .ForMember(dest => dest.OtherInfoRequired, opts => opts.MapFrom(src => src.other_info_required))
            .ForMember(dest => dest.DisbursalScenarioID, opts => opts.MapFrom(src => src.fk_m_disbursal_scenario_id))
            ;

            CreateMap<m_district, Model.Views.Management.DistrictViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_duplication_type, Model.Views.Management.DuplicationTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_education, Model.Views.Management.EducationViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_employment_type, Model.Views.Management.EmploymentTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_floating_interest_rate, Model.Views.Management.FloatingInterestRateViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_income_type, Model.Views.Management.IncomeTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_industry, Model.Views.Management.IndustryViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_interest_classification, Model.Views.Management.InterestClassificationViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_investigave_type, Model.Views.Management.InvestigaveTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_labour_contract_type, Model.Views.Management.LabourContractTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_loan_purpose, Model.Views.Management.LoanPurposeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_loan_tenor, Model.Views.Management.LoanTenorViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Value, opts => opts.MapFrom(src => src.value))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_loan_trend, Model.Views.Management.LoanTrendViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_loan_type, Model.Views.Management.LoanTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_marital_status, Model.Views.Management.MaritalStatusViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_nationality, Model.Views.Management.NationalityViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_occupation, Model.Views.Management.OccupationViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_ownership_type, Model.Views.Management.OwnershipTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;


            CreateMap<m_payment_type, Model.Views.Management.PaymentTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_position, Model.Views.Management.PositionViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_product, Model.Views.Management.ProductViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_program_code, Model.Views.Management.ProgramCodeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_program_type, Model.Views.Management.ProgramTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_property_sale, Model.Views.Management.PropertySaleViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_property_status, Model.Views.Management.PropertyStatusViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bank_type, Model.Views.Management.BankTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_property_type, Model.Views.Management.PropertyTypeViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_reason, Model.Views.Management.ReasonViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_residence_ownership, Model.Views.Management.ResidenceOwnershipViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_sales_channel, Model.Views.Management.SalesChannelViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_status, Model.Views.Management.StatusViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_product_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_trading_area, Model.Views.Management.TradingAreaViewModel>()
             .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_m_group_id))
            ;

            CreateMap<m_type, Model.Views.Management.TypeViewModel>()
           .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))           
            ;

            CreateMap<m_definition_type, Model.Views.Management.DefinitionTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.Code, opts => opts.MapFrom(src => src.code))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.ParentID, opts => opts.MapFrom(src => src.parent_id))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.UpdatedDate, opts => opts.MapFrom(src => src.updated_date))
            .ForMember(dest => dest.UpdatedBy, opts => opts.MapFrom(src => src.updated_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            .ForMember(dest => dest.ValidFromDate, opts => opts.MapFrom(src => src.valid_from_date))
            .ForMember(dest => dest.ValidToDate, opts => opts.MapFrom(src => src.valid_to_date))
            ;

            CreateMap<m_message, Model.Views.Management.MessageViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))            
            .ForMember(dest => dest.Code, opts => opts.MapFrom(src => src.code))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.Subject, opts => opts.MapFrom(src => src.subject))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))            
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            .ForMember(dest => dest.Solution, opts => opts.MapFrom(src => src.solution))
            .ForMember(dest => dest.MessageTypeID, opts => opts.MapFrom(src => src.fk_message_type_id))
            ;

            CreateMap<m_message_type, Model.Views.Management.MessageTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))            
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))            
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))            
            ;

            CreateMap<m_bonus_type, Model.Views.Management.BonusTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_bonus_type, Model.Views.Management.BonusTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_borrower_type, Model.Views.Management.BorrowerTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;

            CreateMap<m_identification_type, Model.Views.Management.IdentificationTypeViewModel>()
            .ForMember(dest => dest.ID, opts => opts.MapFrom(src => src.pk_id))
            .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.name))
            .ForMember(dest => dest.Description, opts => opts.MapFrom(src => src.description))
            .ForMember(dest => dest.IsActive, opts => opts.MapFrom(src => src.is_active))
            .ForMember(dest => dest.CreateDate, opts => opts.MapFrom(src => src.created_date))
            .ForMember(dest => dest.CreateBy, opts => opts.MapFrom(src => src.created_by))
            .ForMember(dest => dest.TypeID, opts => opts.MapFrom(src => src.fk_type_id))
            .ForMember(dest => dest.StatusID, opts => opts.MapFrom(src => src.fk_status_id))
            .ForMember(dest => dest.GroupID, opts => opts.MapFrom(src => src.fk_group_id))
            ;
            #endregion

            #region Auto Loan

            #region SalesCoordinators
            CreateMap<PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel, application_information>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ApplicationInformationID))
            .ForMember(dest => dest.application_no, opts => opts.MapFrom(src => src.ApplicationNo))
            .ForMember(dest => dest.received_date, opts => opts.MapFrom(src => src.ReceivingDate))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy))
            .ForMember(dest => dest.arm_code, opts => opts.MapFrom(src => src.ARMCode))
            .ForMember(dest => dest.sales_code, opts => opts.MapFrom(src => src.SalesCode))
            .ForMember(dest => dest.eops_txn_ref_no_1, opts => opts.MapFrom(src => src.EOpsTxnReference))
            .ForMember(dest => dest.expecting_disbursed_date, opts => opts.MapFrom(src => src.ExpectingDisbursedDate))
            .ForMember(dest => dest.hard_copy_app_date, opts => opts.MapFrom(src => src.HardCopyApplicationDate))
            .ForMember(dest => dest.ict, opts => opts.MapFrom(src => src.ICT))
            .ForMember(dest => dest.sale_staff_bank_id, opts => opts.MapFrom(src => src.PeoplewiseIDofSaleStaf))
            .ForMember(dest => dest.fk_m_type_id, opts => opts.MapFrom(src => src.ApplicationTypeID))
            .ForMember(dest => dest.fk_m_status_id, opts => opts.MapFrom(src => src.ApplicationStatusID))
            .ForMember(dest => dest.fk_m_branch_code_id, opts => opts.MapFrom(src => src.BranchCodeID))
            .ForMember(dest => dest.fk_m_branch_location_id, opts => opts.MapFrom(src => src.BranchLocationID))
            .ForMember(dest => dest.fk_m_customer_type_id, opts => opts.MapFrom(src => src.CustomerTypeID))
            .ForMember(dest => dest.fk_m_product_id, opts => opts.MapFrom(src => src.ProductTypeID))
            .ForMember(dest => dest.fk_m_program_type_id, opts => opts.MapFrom(src => src.ProgramTypeID))
            .ForMember(dest => dest.fk_m_customer_type_id, opts => opts.MapFrom(src => src.CustomerSegmentID))
            .ForMember(dest => dest.fk_m_trading_area_id, opts => opts.MapFrom(src => src.TradingAreaID))
            .ForMember(dest => dest.fk_m_reason_rework_id, opts => opts.MapFrom(src => src.ReasonForReworkID))
            .ForMember(dest => dest.fk_m_customer_segment_id, opts => opts.MapFrom(src => src.CustomerSegmentID))
            .ForMember(dest => dest.fk_m_cdd_id, opts => opts.MapFrom(src => src.CDDID))
            .ForMember(dest => dest.fk_m_sales_channel_id, opts => opts.MapFrom(src => src.ChannelID))
            .ForMember(dest => dest.is_staff, opts => opts.MapFrom(src => src.IsStafNonStaf))
            .ForMember(dest => dest.is_rework, opts => opts.MapFrom(src => src.IsRework))
            .ForMember(dest => dest.is_black_list, opts => opts.MapFrom(src => src.IsBlackList))
            .ForMember(dest => dest.is_existing, opts => opts.MapFrom(src => src.IsExisting))
            ;

            CreateMap<PartialViews.AutoLoan.SalesCoordinators.AppliedLoanInformationViewModel, al_personal_application>()
            .ForMember(dest => dest.pk_id, opts => opts.MapFrom(src => src.ALApplicationInformationID))
            .ForMember(dest => dest.fk_application_information_id, opts => opts.MapFrom(src => src.ApplicationInformationID))
            .ForMember(dest => dest.amount_requested_vnd, opts => opts.MapFrom(src => src.AmountRequested))
            .ForMember(dest => dest.fk_status_id, opts => opts.MapFrom(src => src.ApplicationStatusID))
            .ForMember(dest => dest.fk_type_id, opts => opts.MapFrom(src => src.ApplicationTypeID))
            .ForMember(dest => dest.fk_m_campaign_code_id, opts => opts.MapFrom(src => src.CampaignCodeID))
            .ForMember(dest => dest.created_by, opts => opts.MapFrom(src => src.CreateBy))
            .ForMember(dest => dest.created_date, opts => opts.MapFrom(src => src.CreateDate))
            .ForMember(dest => dest.fk_m_credit_deviation_id, opts => opts.MapFrom(src => src.CreditDeviationID))
            .ForMember(dest => dest.fk_m_floating_interest_rate_id, opts => opts.MapFrom(src => src.FloatingInterestRateID))
            .ForMember(dest => dest.is_active, opts => opts.MapFrom(src => src.IsActive))
            .ForMember(dest => dest.fk_m_loan_purpose_id, opts => opts.MapFrom(src => src.LoanPurposeID))
            .ForMember(dest => dest.ltv, opts => opts.MapFrom(src => src.LTV))
            .ForMember(dest => dest.fk_m_payment_type_id, opts => opts.MapFrom(src => src.PaymentTypeID))
            .ForMember(dest => dest.fk_m_program_type_id, opts => opts.MapFrom(src => src.ProgramTypeID))
            .ForMember(dest => dest.fk_m_reason_for_deviation_id, opts => opts.MapFrom(src => src.ReasonForDeviationID))
            .ForMember(dest => dest.fk_m_loan_tenor_id, opts => opts.MapFrom(src => src.TenorsID))            
            ;
            #endregion

            #endregion
        }
    }
}
