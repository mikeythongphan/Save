﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Core.Resources
{
    public class EnumList
    {
                
        public enum Process
        {
            LITS = 4,
        }

        #region Role_Permision_Task List

        public enum PermisionList
        {
            VW_SaleML = 14,
            VW_SalePL = 15,
            VW_Checker = 16,
            VW_Approver = 17,
            VW_Finalize = 18,
            VW_Admin = 19,
            ImportBlackList = 20,
            Unlock_SC = 21,
            Unlock_OS = 22,
            Unlock_CI = 23,
            Unlock_LO = 24,
            Admin = 25,
            HR_Team = 67,
            Ad_Policy_Maker = 68,
            Ad_Policy_Checker = 69,
            ML_Sale_Team_Manager = 70,
            PL_Sale_Team_Manager = 71,
            Sale_Team_Manager = 72,
            VW_Direct_Sale = 76,
            Tele_Verifier = 77,
            ImportCompanyList = 84
        }

        public enum UserRoleList
        {
            Processing_ML = 13,
            Processing_PL = 15,
            Checking = 17,
            Approving = 18,
            Disbursing = 19
        }

        public enum TaskList
        {
            Maker_ML = 12,
            Processing_ML = 13,
            Maker_PL = 14,
            Processing_PL = 15,
            Checker = 16,
            Approver = 17,
            Finalize = 18
        }

        #endregion

        #region Group List

        public enum GroupList
        {
            Role_Sale_ML = 14,
            Role_Sale_PL = 15,
            Role_Checker = 16,
            Role_Approver = 17,
            Role_Disbursal = 18,
            View_Sale_ML = 19,
            View_Sale_PL = 20,
            View_Checking = 21,
            View_Approving = 22,
            View_Disbursal = 23,
            Admin_View = 24,
            Master_SC = 25,
            Master_OS = 26,
            Master_CI = 27,
            Master_LO = 28,
            HR_Team = 74,
            Admin_PolicyMaker = 78,
            Admin_PolicyChecker = 79,
            ML_Sale_Team_Manager = 80,
            PL_Sale_Team_Manager = 81,
            LIT_Viewer_Direct_Sales = 104,
            LIT_TeleVerifier = 105,
            LIT_FraudRisk = 114,
            LIT_Credit_PMF = 115 // PRD env
            //LIT_Viewer_Direct_Sales = 130,
            //LIT_TeleVerifier = 131,
            //LIT_FraudRisk = 132,
            //LIT_Credit_PMF = 133// UAT env
        }

        #endregion

        #region Users

        public enum UserType
        {
            MortgageLoan = 1,
            PersonalLoan = 2
        }

        public enum UserRole
        {
            SC_ML = 1,
            SC_PL = 2,
            OS = 3,
            CI = 4,
            LO = 5,
            AD = 6,
            MAS_SC = 7,
            MAS_OS = 8,
            MAS_CI = 9,
            MAS_LO = 10,
            CI_Tele = 11
        }

        public enum UserTypeLoan
        {
            Underwriter,
            TeleVerifier
        }

        #endregion

        #region Status

        public enum ActiveStatus
        {
            InActive = 0,
            Active = 1
        }

        public enum CustomerStatus
        {
            Active = 43,
            BlackList = 44,
            Remodify = 45
        }

        public enum DisbursalStatus
        {
            Partly_Disbursed = 0,
            Fully_Disbursed = 1,
            Cancelled_By_Customer = 2
        }

        public enum ImportFileStatus
        {
            Successful,
            Warning,
            Failed
        }

        public enum ManagementStatus
        {
            Pending = 1,
            Active = 2,
            Delete_Pending = 3,
            InActive = 4
        }

        public enum CallCheckListStatus
        {
            NEW = 1,
            EXTRACTED = 2
        }

        public enum PendingMarkStatus
        {
            PENDING,
            CALL
        }

        public enum FraudBLStatus
        {
            Pending = 0,
            Approved = 1,
            Rejected = 2,
            Ready = 3
        }

        public enum DAStatus
        {
            Pending,
            Active,
            Pending_Active,
            Pending_InActive,
            InActive
        }

        public enum FraudInvestigationStatus
        {
            Open,
            InProgress,
            Completed,
            SentBack_ByFRM,
            Cancelled_ByApplicant
        }

        public enum FraudInvestigationResult
        {
            Pending,
            Fraud,
            NoFraud,
            PotentialFraud,
            NA
        }

        public enum ActionLogAction
        {
            FraudPending,
            FraudReleased
        }

        #endregion

        #region Type

        public enum Type
        {
            LITS = 1,
            AL = 2,
            ML = 3,
            PL = 4,
            CC = 5
        }

        public enum LoanType
        {
            ALPERSONAL = 6,
            ALCORPORATE = 7,
        }

        public enum Group
        {
            Product = 1,
            Initial = 2
        }

        public enum IdType
        {
            IdentityCard = 1,
            Passport = 2
        }

        public enum BlackListType
        {
            BlackListSC = 0,
            BlackListOS = 1
        }

        public enum CompanyType
        {
            NonApproved = 0,
            Approved = 1
        }

        public enum BureauType
        {
            Current,
            History
        }

        public enum ExpressType
        {
            Online,
            Secured
        }

        public enum RequeueLogType
        {
            REQUEUE,
            SENTBACK
        }

        public enum IncomeType
        {
            Salaried,
            HouseRental,
            CarRental,
            PrivateBusiness
        }

        public enum ElegibilityType
        {
            Age,
            Tenor
        }

        public enum VerifierContactType
        {
            HOME,
            OFFICE,
            REFEREE,
            MOBILE
        }

        public enum ReworkReasonType
        {
            LV,
            R,
            C_SC,
            C_CI,
            SB,
            RW,
            CC_SB,
            CC_TeleSB
        }

        public enum InvestigaveFileType
        {
            EscalationReport,
            InvestigationReport
        }

        public enum IdentificationType
        {
            ID,
            Passport,
            Previous_ID,
            Previous_PP
        }

        public enum BorrowerType
        {
            MainBorrower,
            CoBorrower1,
            CoBorrower2,
            CoBorrower3
        }
        #endregion

        #region Report_Status

        public enum ReportStatus
        {
            ML_Sales_Master_Report = 1,
            ML_MIS_Master_Report = 2,
            //ML_Loan_Processed_Tracking = 3,
            ML_Loan_Approved_Tracking = 4,
            ML_Loan_Rejected_Tracking = 5,
            ML_Loan_Cancelled_Tracking = 6,
            ML_TAT_Report = 7,
            ML_RETSO_Report = 8,
            //ML_Credit = 9,
            ML_Pending_Report = 10,
            ML_Customers = 11,
            ML_LORemodifiedSC = 12,
            PL_Sales_Master_Report = 13,
            PL_MIS_Master_Report = 14,
            //PL_Loan_Processed_Tracking = 15,
            PL_Loan_Approved_Tracking = 16,
            PL_Loan_Rejected_Tracking = 17,
            PL_Loan_Cancelled_Tracking = 18,
            PL_TAT_Report = 19,
            //PL_Credit = 20,
            PL_Pending_Report = 21,
            PL_Customers = 22,
            PL_LORemodifiedSC = 23,
            PL_Disbursement_Pending = 24,
            PL_Disbursed_Report = 25,
            PL_Calling_Report = 26,
            AUDIT_TRAIL_REPORT = 27,
            PL_Office_Phone_Database = 28,
            PL_Audit_Trail_OS = 29,
            PL_Audit_Trail_CI = 30,
            ML_Audit_Trail_OS = 31,
            ML_Audit_Trail_CI = 32,
            PL_Fraud_Dump_Report = 33,
            PL_Fraud_SAS_Report = 34,
            ML_CI_Master_Report = 35,
            PL_CI_Master_Report = 36,
            PL_SMS_NSG = 37,
            PL_SMS_Approved_Rejected = 38,
            ML_SMS_NSG = 39,
            ML_SMS_Approved_Rejected = 40,
            AL_Collateral_Detail_Rerort = 41,
            AL_Post_Disbursement_Condition_Rerort = 42,
            AL_MIS_Master_Report = 43,
            AL_Pending_Report = 44,
            AL_TAT_Report = 45
        }

        public enum ReportAuditTrail
        {
            PLMUE,
            PLRate,
            PLPercentageDBR
        }

        #endregion

        #region User_Report

        public enum UserReport
        {
            SaleCoordinator = 1,
            OperationSupport = 2,
            Credit = 3,
            LendingOperation = 4,
            Credit_AIP = 5,
            SaleCoordinator_AIP = 6,
            OperationSupport_AIP = 7,
            TeleVerifier = 8
        }

        #endregion

        #region TableTypeList

        public enum TableTypeList
        {
            BankType,
            BranchCode,
            BusinessNature,
            BusinessType,
            BureauCardList,
            BureauLoanList,
            CDD,
            CIC,
            CurrentResidentType,
            CustomerInfo,
            CustomerSegment,
            CustomerType,
            DeviationCodeList,
            EducationList,
            EmploymentType,
            FloatingInterestRate,
            HousePurpose,
            IndustryList,
            LabourContractTerms,
            LevelList,
            LoanTenor,
            LoanType,
            LoanTrendList,
            OccupationList,
            OwnershipType,
            PositionList,
            PropertySale,
            PropertyStat,
            PropertyType,
            ReasonCompanyList,
            ResidenceOwnershipList,
            SalesChannel,
            TradingArea
        }

        public enum TableTypeListLoanType
        {
            LoanPurpose,
            ProductType,
            ProgramType
        }

        #endregion

        #region AppChangedLogType

        public enum AppChangedLogType
        {
            ReModified_SC,
            LoginFail,
            RemoveBlackList_AfterRework,
            // Eligible
            Eligible_ADD,
            Eligible_EDIT,
            Eligible_DEL,
            Eligible_APPROVE_ADD,
            Eligible_APPROVE_EDIT,
            Eligible_APPROVE_DEL,
            Eligible_REJECT_ADD,
            Eligible_REJECT_EDIT,
            Eligible_REJECT_DEL,
            Eligible_CANCEL_EDIT,
            Eligible_CANCEL_DEL,
            // Company Code
            CompanyCode_ADD,
            CompanyCode_EDIT,
            CompanyCode_DEL,
            CompanyCode_APPROVE_ADD,
            CompanyCode_APPROVE_EDIT,
            CompanyCode_APPROVE_DEL,
            CompanyCode_REJECT_ADD,
            CompanyCode_REJECT_EDIT,
            CompanyCode_REJECT_DEL,
            CompanyStatus_ADD,
            CompanyStatus_EDIT,
            CompanyStatus_DEL,
            CompanyStatus_APPROVE_ADD,
            CompanyStatus_APPROVE_EDIT,
            CompanyStatus_APPROVE_DEL,
            CompanyStatus_REJECT_ADD,
            CompanyStatus_REJECT_EDIT,
            CompanyStatus_REJECT_DEL,
            // Customer CallCheckList
            OpsLendingCallCheckList_CREATE,
            OpsLendingCallCheckList_EXTRACTED,
            OpsLendingCallCheckList_UPDATE,
            OpsLendingCallCheckListPendingReason_CREATE,
            OpsLendingCallCheckListPendingReason_UPDATE,
            OpsLendingAgreementLoan_EXTRACTED,
            OpsLendingPendingCase_REMOVE,
            OpsLendingRejectLetter_EXTRACTED,
            // ARM Mapping Table
            ARMMappingTable_ADD,
            ARMMappingTable_EDIT,
            // DA Tables
            DATables_ADD,
            DATables_EDIT,
            DATables_ACTIVE,
            DATables_INACTIVE,
            DATables_APPROVE_ADD,
            DATables_APPROVE_EDIT,
            DATables_APPROVE_ACTIVE,
            DATables_APPROVE_INACTIVE,
            DATables_REJECT_ADD,
            DATables_REJECT_EDIT,
            DATables_REJECT_ACTIVE,
            DATables_REJECT_INACTIVE,
            DATables_CANCEL_EDIT,
            DATables_CANCEL_ACTIVE,
            DATables_CANCEL_INACTIVE,
            // Disbursal Scenario
            DisbursalScenario_ADD,
            DisbursalScenario_EDIT,
            DisbursalCondition_ADD,
            DisbursalCondition_EDIT,
            DELETE_HOME,
            DELETE_OFFICE,
            DELETE_REFEREE,
            DELETE_MOBILE,
            // Site Visit
            SiteVisit_ADD,
            SiteVisit_EDIT,
            FraudCustomer_ADD,
            FraudCustomer_UPDATE,
            BlackCustomer_ADD,
            BlackCustomer_UPDATE,
            BlackCustomer_DELETE,
            PropertyTrxPrice_CI,
            PropertyTrxPrice_LO
        }

        public enum AppChangedLogTypeTable
        {
            BankType_ADD,
            BankType_EDIT,
            BranchCode_ADD,
            BranchCode_EDIT,
            BusinessNature_ADD,
            BusinessNature_EDIT,
            BusinessType_ADD,
            BusinessType_EDIT,
            BureauCardListCurrent_ADD,
            BureauCardListCurrent_EDIT,
            BureauCardListHistory_ADD,
            BureauCardListHistory_EDIT,
            BureauLoanListCurrent_ADD,
            BureauLoanListCurrent_EDIT,
            BureauLoanListHistory_ADD,
            BureauLoanListHistory_EDIT,
            CDD_ADD,
            CDD_EDIT,
            CIC_ADD,
            CIC_EDIT,
            CurrentResidentType_ADD,
            CurrentResidentType_EDIT,
            CustomerInfo_ADD,
            CustomerInfo_EDIT,
            CustomerSegment_ADD,
            CustomerSegment_EDIT,
            CustomerType_ADD,
            CustomerType_EDIT,
            DeviationCodeList_ADD,
            DeviationCodeList_EDIT,
            EducationList_ADD,
            EducationList_EDIT,
            EmploymentType_ADD,
            EmploymentType_EDIT,
            FloatingInterestRate_ADD,
            FloatingInterestRate_EDIT,
            HousePurpose_ADD,
            HousePurpose_EDIT,
            IndustryList_ADD,
            IndustryList_EDIT,
            LabourContractTerms_ADD,
            LabourContractTerms_EDIT,
            LevelList_ADD,
            LevelList_EDIT,
            LoanTenor_ADD,
            LoanTenor_EDIT,
            LoanType_ADD,
            LoanType_EDIT,
            LoanTrendList_ADD,
            LoanTrendList_EDIT,
            OccupationList_ADD,
            OccupationList_EDIT,
            OwnershipType_ADD,
            OwnershipType_EDIT,
            PositionList_ADD,
            PositionList_EDIT,
            PropertySale_ADD,
            PropertySale_EDIT,
            PropertyStat_ADD,
            PropertyStat_EDIT,
            PropertyType_ADD,
            PropertyType_EDIT,
            ReasonCompanyList_ADD,
            ReasonCompanyList_EDIT,
            ResidenceOwnershipList_ADD,
            ResidenceOwnershipList_EDIT,
            SalesChannel_ADD,
            SalesChannel_EDIT,
            TradingArea_ADD,
            TradingArea_EDIT,
            // With Loan Type
            LoanPurpose_ADD,
            LoanPurpose_EDIT,
            ProductType_ADD,
            ProductType_EDIT,
            ProgramType_ADD,
            ProgramType_EDIT,
            PaymentType_ADD,
            PaymentType_EDIT,
            // Reason
            ReasonReject_ADD,
            ReasonCancelSC_ADD,
            ReasonCancelCI_ADD,
            ReasonSendBack_ADD,
            ReasonLevel_ADD,
            ReasonRework_ADD,
            ReasonRework_UPDATE,
            // Holiday
            Holiday_ADD,
            Holiday_DEL
        }

        public enum AppChangedLogTypeSetUp
        {
            // PL DBR
            PLDBR_ADD,
            PLDBR_EDIT,
            PLDBR_DEL,
            PLDBR_APPROVE_ADD,
            PLDBR_APPROVE_EDIT,
            PLDBR_APPROVE_DEL,
            PLDBR_REJECT_ADD,
            PLDBR_REJECT_EDIT,
            PLDBR_REJECT_DEL,
            PLDBR_CANCEL_EDIT,
            PLDBR_CANCEL_DEL,
            // PL MUE
            PLMUE_ADD,
            PLMUE_EDIT,
            PLMUE_DEL,
            PLMUE_APPROVE_ADD,
            PLMUE_APPROVE_EDIT,
            PLMUE_APPROVE_DEL,
            PLMUE_REJECT_ADD,
            PLMUE_REJECT_EDIT,
            PLMUE_REJECT_DEL,
            PLMUE_CANCEL_EDIT,
            PLMUE_CANCEL_DEL,
            // PL Rate
            PLRate_ADD,
            PLRate_EDIT,
            PLRate_DEL,
            PLRate_APPROVE_ADD,
            PLRate_APPROVE_EDIT,
            PLRate_APPROVE_DEL,
            PLRate_REJECT_ADD,
            PLRate_REJECT_EDIT,
            PLRate_REJECT_DEL,
            PLRate_CANCEL_EDIT,
            PLRate_CANCEL_DEL
        }

        #endregion

        #region OTHERS

        public enum BlackListCase
        {
            R = 0,
            F = 1,
            RF = 2
        }

        public enum CRApproval
        {
            Approved = 1,
            Rejected = 2,
            Cancelled = 3,
            Pending = 4
        }

        public enum ApplicationLocked
        {
            NotLockedYet = 0,
            SCLocked = 1,
            OSLocked = 2,
            CILocked = 3,
            LOLocked = 4,
            SCUnLock = 5,
            OSUnLock = 6,
            CIUnLock = 7,
            LOUnLock = 8
        }

        public enum Borrower
        {
            MB = 0,
            CB1 = 1,
            CB2 = 2,
            CB3 = 3
        }

        public enum PermanentResidence
        {
            HCM,
            HANOI,
            OTHERS
        }

        #region Loan_AtOtherBank

        public enum LoanSource
        {
            CIC,
            By_Customer
        }

        public enum LoanProduct
        {
            PL,
            ML,
            CC,
            OD
        }

        public enum LoanGroupDept
        {
            G1,
            G2,
            G3
        }

        public enum LoanSecuredType
        {
            Unsecured,
            Secured,
            Run_Off
        }

        #endregion

        public enum ReasonBlackList
        {
            Blacklist,
            Suspended,
            Bankscrupcy,
            Lowprofile,
            Others
        }

        public enum SiteVisit
        {
            Site_BankStatement,
            Site_Home,
            Site_Office,
            Site_Rental
        }

        public enum DisbursementType
        {
            STANDARD,
            NON_STANDARD
        }

        public enum PayRollType
        {
            Payroll,
            NonPayroll
        }

        #endregion

        #region ApplicationStatus

        public enum ApplicationStatus
        {
            SCFirstEntry = 0,   // SC create customer in Create New Loan                
            SCCreated = 1,      // SC save
            SCSubmitted = 2,    // SC Submit      
            SCDeleted = 3,      // SC Delete Application
            SCRejected = 4,     // if customer in black list then SC Reject
            SCCancelled = 18,   // cancel stop calculate TAT
            OSModified = 5,    // OS modified
            OSSendBack = 6,    // OS send back to SC
            OSReject = 7,      // OS reject
            OSChecked = 8,     // OS submit 
            Approved = 9,      // OS (changed to CI) review to approved after CI recommend
            CIModified = 10,      // CI modified
            CISendBack = 11,      // CI send back to SC
            AIPCompleted = 12,    // waiting for AIP section
            Rejected = 13,        // CI Reject --> user reject
            CIRecommend = 14,     // CI Approved changed to CI Recommend (14 May 2013)
            Cancelled = 15,       // CI Cancelled --> customer reject (stop calculating TAT)
            ReturnFirstCI = 22,   // CI2 Returned CI1
            LODisbursed = 16,       // LO disburse --> Application CLOSED (DONE)      
            LORemodify = 17,        // LO remodify to LO Checker check if LO input wrong
            Resubmitted = 19,   // for rework (resubmit old application)
            AIPRecommend = 20,   // process of AIP (Maker recommend AIP for Checker Complete AIP)
            LORemodifySC = 21,       // LO re-modify data of SC page after disbursement
        }

        public enum TeleQueue
        {
            Tele_Modified,
            Tele_SentBack,
            Tele_SCModified,
            Tele_SCSubmitted,
            Tele_CIRequeue,
            Tele_Completed
        }

        public enum CCApplicationStatus
        {
            SCCreated,
            SCSubmitted,
            SCCancelled,
            SCDeleted,
            SCDone,//TAT SC - Cal as OS

            OSApproved,
            OSRejected,
            OSSendBack,
            OSModified,
            OSDone,//TAT OS - Cal as CI

            CIModified,
            CIRecommend,
            CIDone1,//TAT CI - Cal as CI1
            CIDone2,//TAT CI - Cal as CI2
            CIDone,

            CIApproved,
            CIApprovedBD,
            CIApprovedPL,
            CIApprovedCC,
            CIRejected,
            CIRejectedBD,
            CICancelled,
            CISendBackSC,
            CISendBackCI,
            CISendBackOS,

            CI_BYPASS,

            LOModified,
            LODisbursed,
            LOSendBackSC,
            LOModifySC,

            NSG,

            FRPending,
            FRSubmitted,
            FRFinal,
            FRRejected,

            //SC submitted
            Tele_SCSubmitted,
            //Tele Save
            Tele_Modified,
            //Tele Senback to SC to modify
            Tele_SentBackSC,
            //Tele finish
            Tele_Completed,
            //CI return case to Tele
            Tele_CIReturn,
            Cust_Modified
        }

        public enum ALApplicationStatus
        {
            SCCreated = 3,
            SCFirstEntry = 4,
            SCSubmitted = 5,
            SCDeleted = 6,
            SCRejected = 7,
            SCCancelled = 8,
            OSSendBackSC = 9,
            CISendBackSC = 10,
            LOSendBackSC = 11,
            TeleSentBackSC = 12,
            OSModified = 13,
            OSApproved = 14,
            OSRejected = 15,
            OSChecked = 16,
            CISendBackOS = 17,
            LOSendBackOS = 18,
            CIModified = 19,
            CIRecommend = 20,
            CIApproved = 21,
            CIRejected = 22,
            CICancelled = 23,
            CISendBackCIMaker = 24,
            CIByPass = 25,
            LOSendBackCI = 26,
            LOModified = 27,
            LODisbursed = 28,
            LORemodify = 29,
            LORemodifySC = 30,
            NSG = 31,
            FRMPending = 32,
            FRSubmitted = 33,
            FRFinal = 34,
            FRRejected = 35,
            FRMInvestigave = 36,
            TeleModified = 37,
            TeleSCModified = 38,
            TeleSCSubmitted = 39,
            TeleCIRequeue = 40,
            TeleCompleted = 41,
            TeleCIReturn = 42
        }
        #endregion

        #region CCTypeLog
        public enum CCTypeLog
        {
            Pending,
            Requeue,
            Tele
        }
        #endregion

        #region FRMInvestigaveType
        public enum FRMInvestigaveType
        {
            PreApprovalEscalation,
            PostApprovalEscalation
        }
        #endregion

        #region CC TAT Role
        public enum CCTATRoles
        {
            SC,
            OS,
            CI1,
            CI2,
            CI_CUST,
            CI_TELE,
            SC_TELE,
            FRM,
            LO

        }
        #endregion

        #region CC Users Role
        public enum CCUserRoleList
        {
            CC_SC_Viewer = 50,
            CC_SC_Action = 51,
            CC_SC_Master = 52,

            CC_OS_Viewer = 53,
            CC_OS_Action = 54,
            CC_OS_Master = 55,

            CC_CI_Viewer = 56,
            CC_CI_CI1 = 57,
            CC_CI_CI2 = 58,
            CC_CI_Master = 59,
            CC_CI_Tele = 60,

            CC_FR_Maker = 61,
            CC_FR_Checker = 62,

            CC_BL_Maker = 63,
            CC_BL_Checker = 64,

            CC_RP_Viewer = 65,

            CC_AD_Maker = 66,
            CC_AD_Checker = 67,

            CC_SC_TeamLead = 70,

            CC_Sale = 80,
            CC_SaleTM = 81,

            CC_LO_Action = 82,
            CC_LO_Viewer = 83,
            CC_LO_Master = 84
        }

        public enum CCUserPermissionList
        {
            //add new permission UAT
            CC_SR_Viewer = 122,

            CC_SC_Viewer = 100,
            CC_OS_Viewer = 101,
            CC_CI_Viewer = 102,
            CC_RP_Viewer = 103,
            CC_FR_Viewer = 104,
            CC_BL_Viewer = 105,
            //form4
            CC_LO_Viewer = 106,
            CC_AD_Viewer = 107,

            CC_TELE_Viewer = 108,
            CC_SC_TeamLead = 109,

            CC_Sale = 120,
            CC_SaleTM = 121
        }

        public enum CCUserTask
        {
            CC_SC_Viewer = 60,
            CC_SC_Action = 61,
            CC_SC_Master = 62,
            CC_SC_TeamLead = 79,

            CC_OS_Viewer = 63,
            CC_OS_Action = 64,
            CC_OS_Master = 65,

            CC_CI_Viewer = 66,
            CC_CI_CI1 = 67,
            CC_CI_CI2 = 67,
            CC_CI_Master = 68,
            CC_CI_Tele = 69,

            CC_FR_Maker = 70,
            CC_FR_Checker = 71,

            CC_BL_Maker = 72,
            CC_BL_Checker = 73,

            CC_RP_Viewer = 74,

            CC_AD_Maker = 75,
            CC_AD_Checker = 76,

            CC_TELE_Viewer = 77,
            CC_TELE_Maker = 78,

            //add new task UAT
            CC_Sale = 84,
            CC_SaleTM = 85,

            CC_LO_Action = 86,
            CC_LO_Viewer = 87,
            CC_LO_Master = 88
        }
        #endregion        

        #region CCCustomerType

        public enum CCCustomerType
        {
            Primary,
            Sub
        }
        #endregion

        #region CCOverwrite
        public enum CCOverwrite
        {
            None = 0,
            EligibleAge = 1,
            EligibleIncome = 2,
            EligibleEmployment = 3,
            EligibleLoanDeliquency = 4,
            EligibleCardDeliquency = 5,
            EligibleIncomeCard2 = 6
        }
        #endregion

        #region CCCriteriaType
        public enum CCCriteriaType
        {
            Nationality = 0,
            Age = 1,
            OfficePhone = 2,
            Income = 3,
            TradingArea = 4,
            CreditCardLimit = 5,
            DSR = 6,
            MUE = 8,
            LTV = 9,
            Mobile = 10,
            HomePhone = 11,
            EmploymentCheck = 12,
            BankStatementCheck = 13,
            HomeSiteVisit = 14,
            OfficeSiteVisit = 15,
            Documents = 16,
            CreditBureauCheck
        }
        #endregion

        #region CCCreditHistoryType
        public enum CCCreditHistory
        {
            GroupLoan,
            GroupCard
        }
        #endregion

        #region Import File
        public enum DGTImportFileType
        {
            Data,
            CIC
        }

        public enum DGTImportFileStatus
        {
            FailedFormat,
            Success,
            Duplication,
            FailedMandantory,
            FailedRules,
            FailedBL,
            FailedCHK,
            Failed
        }
        #endregion

        #region ControllerName
        public enum Controllers
        {
            Access,
            Account,
            Base,
            Home,
            Mailbox,
            Manage,
            Role,
            Widgets,
            SCChecker,
            SCMaker,
            SCMaster,
            SCViewer,
            OSChecker,
            OSMaker,
            OSMaster,
            OSViewer,
            CIChecker,
            CIMaker,
            CIMaster,
            CIViewer,
            LOChecker,
            LOMaker,
            LOMaster,
            LOViewer
        }
        #endregion
    }
}
