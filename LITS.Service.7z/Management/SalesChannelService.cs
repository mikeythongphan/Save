﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class SalesChannelService : ISalesChannelService
    {
        private readonly ISalesChannelRepository _SalesChannelRepository;

        private readonly IUnitOfWork _unitOfWork;

        public SalesChannelService(ISalesChannelRepository SalesChannelRepository,
            IUnitOfWork unitOfWork)
        {
            this._SalesChannelRepository = SalesChannelRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<SalesChannelViewModel> GetListAll()
        {
            return _SalesChannelRepository.GetListAll();
        }

        public List<SalesChannelViewModel> GetListById(int? Id)
        {
            return _SalesChannelRepository.GetListById(Id);
        }

        public List<SalesChannelViewModel> GetListByStatusId(int? StatusId)
        {
            return _SalesChannelRepository.GetListByStatusId(StatusId);
        }

        public List<SalesChannelViewModel> GetListByTypeId(int? TypeId)
        {
            return _SalesChannelRepository.GetListByTypeId(TypeId);
        }

        public List<SalesChannelViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _SalesChannelRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<SalesChannelViewModel> GetListActiveAll()
        {
            return _SalesChannelRepository.GetListActiveAll();
        }

        public List<SalesChannelViewModel> GetListActiveById(int? Id)
        {
            return _SalesChannelRepository.GetListActiveById(Id);
        }

        public List<SalesChannelViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _SalesChannelRepository.GetListActiveByStatusId(StatusId);
        }

        public List<SalesChannelViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _SalesChannelRepository.GetListActiveByTypeId(TypeId);
        }

        public List<SalesChannelViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _SalesChannelRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(SalesChannelViewModel objModel)
        {
            return _SalesChannelRepository.Create(objModel);
        }

        public bool Update(SalesChannelViewModel objModel)
        {
            return _SalesChannelRepository.Update(objModel);
        }

        public bool Delete(SalesChannelViewModel objModel)
        {
            return _SalesChannelRepository.Delete(objModel);
        }
    }
}
