﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CreditBureauTypeService : ICreditBureauTypeService
    {
        private readonly ICreditBureauTypeRepository _CreditBureauTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CreditBureauTypeService(ICreditBureauTypeRepository CreditBureauTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CreditBureauTypeRepository = CreditBureauTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CreditBureauTypeViewModel> GetListAll()
        {
            return _CreditBureauTypeRepository.GetListAll();
        }

        public List<CreditBureauTypeViewModel> GetListById(int? Id)
        {
            return _CreditBureauTypeRepository.GetListById(Id);
        }

        public List<CreditBureauTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CreditBureauTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CreditBureauTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CreditBureauTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CreditBureauTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CreditBureauTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CreditBureauTypeViewModel> GetListActiveAll()
        {
            return _CreditBureauTypeRepository.GetListActiveAll();
        }

        public List<CreditBureauTypeViewModel> GetListActiveById(int? Id)
        {
            return _CreditBureauTypeRepository.GetListActiveById(Id);
        }

        public List<CreditBureauTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CreditBureauTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CreditBureauTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CreditBureauTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CreditBureauTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CreditBureauTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CreditBureauTypeViewModel objModel)
        {
            return _CreditBureauTypeRepository.Create(objModel);
        }

        public bool Update(CreditBureauTypeViewModel objModel)
        {
            return _CreditBureauTypeRepository.Update(objModel);
        }

        public bool Delete(CreditBureauTypeViewModel objModel)
        {
            return _CreditBureauTypeRepository.Delete(objModel);
        }
    }
}
