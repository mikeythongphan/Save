﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DisbursalScenarioConditionService : IDisbursalScenarioConditionService
    {
        private readonly IDisbursalScenarioConditionRepository _DisbursalScenarioConditionRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DisbursalScenarioConditionService(IDisbursalScenarioConditionRepository DisbursalScenarioConditionRepository,
            IUnitOfWork unitOfWork)
        {
            this._DisbursalScenarioConditionRepository = DisbursalScenarioConditionRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DisbursalScenarioConditionViewModel> GetListAll()
        {
            return _DisbursalScenarioConditionRepository.GetListAll();
        }

        public List<DisbursalScenarioConditionViewModel> GetListById(int? Id)
        {
            return _DisbursalScenarioConditionRepository.GetListById(Id);
        }

        public List<DisbursalScenarioConditionViewModel> GetListByStatusId(int? StatusId)
        {
            return _DisbursalScenarioConditionRepository.GetListByStatusId(StatusId);
        }

        public List<DisbursalScenarioConditionViewModel> GetListByTypeId(int? TypeId)
        {
            return _DisbursalScenarioConditionRepository.GetListByTypeId(TypeId);
        }

        public List<DisbursalScenarioConditionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DisbursalScenarioConditionRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveAll()
        {
            return _DisbursalScenarioConditionRepository.GetListActiveAll();
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveById(int? Id)
        {
            return _DisbursalScenarioConditionRepository.GetListActiveById(Id);
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _DisbursalScenarioConditionRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _DisbursalScenarioConditionRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DisbursalScenarioConditionRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(DisbursalScenarioConditionViewModel objModel)
        {
            return _DisbursalScenarioConditionRepository.Create(objModel);
        }

        public bool Update(DisbursalScenarioConditionViewModel objModel)
        {
            return _DisbursalScenarioConditionRepository.Update(objModel);
        }

        public bool Delete(DisbursalScenarioConditionViewModel objModel)
        {
            return _DisbursalScenarioConditionRepository.Delete(objModel);
        }
    }
}
