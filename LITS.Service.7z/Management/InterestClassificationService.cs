﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class InterestClassificationService : IInterestClassificationService
    {
        private readonly IInterestClassificationRepository _InterestClassificationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public InterestClassificationService(IInterestClassificationRepository InterestClassificationRepository,
            IUnitOfWork unitOfWork)
        {
            this._InterestClassificationRepository = InterestClassificationRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<InterestClassificationViewModel> GetListAll()
        {
            return _InterestClassificationRepository.GetListAll();
        }

        public List<InterestClassificationViewModel> GetListById(int? Id)
        {
            return _InterestClassificationRepository.GetListById(Id);
        }

        public List<InterestClassificationViewModel> GetListByStatusId(int? StatusId)
        {
            return _InterestClassificationRepository.GetListByStatusId(StatusId);
        }

        public List<InterestClassificationViewModel> GetListByTypeId(int? TypeId)
        {
            return _InterestClassificationRepository.GetListByTypeId(TypeId);
        }

        public List<InterestClassificationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _InterestClassificationRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<InterestClassificationViewModel> GetListActiveAll()
        {
            return _InterestClassificationRepository.GetListActiveAll();
        }

        public List<InterestClassificationViewModel> GetListActiveById(int? Id)
        {
            return _InterestClassificationRepository.GetListActiveById(Id);
        }

        public List<InterestClassificationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _InterestClassificationRepository.GetListActiveByStatusId(StatusId);
        }

        public List<InterestClassificationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _InterestClassificationRepository.GetListActiveByTypeId(TypeId);
        }

        public List<InterestClassificationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _InterestClassificationRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(InterestClassificationViewModel objModel)
        {
            return _InterestClassificationRepository.Create(objModel);
        }

        public bool Update(InterestClassificationViewModel objModel)
        {
            return _InterestClassificationRepository.Update(objModel);
        }

        public bool Delete(InterestClassificationViewModel objModel)
        {
            return _InterestClassificationRepository.Delete(objModel);
        }
    }
}
