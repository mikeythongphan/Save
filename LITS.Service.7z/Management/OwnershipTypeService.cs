﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class OwnershipTypeService : IOwnershipTypeService
    {
        private readonly IOwnershipTypeRepository _OwnershipTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public OwnershipTypeService(IOwnershipTypeRepository OwnershipTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._OwnershipTypeRepository = OwnershipTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<OwnershipTypeViewModel> GetListAll()
        {
            return _OwnershipTypeRepository.GetListAll();
        }

        public List<OwnershipTypeViewModel> GetListById(int? Id)
        {
            return _OwnershipTypeRepository.GetListById(Id);
        }

        public List<OwnershipTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _OwnershipTypeRepository.GetListByStatusId(StatusId);
        }

        public List<OwnershipTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _OwnershipTypeRepository.GetListByTypeId(TypeId);
        }

        public List<OwnershipTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _OwnershipTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<OwnershipTypeViewModel> GetListActiveAll()
        {
            return _OwnershipTypeRepository.GetListActiveAll();
        }

        public List<OwnershipTypeViewModel> GetListActiveById(int? Id)
        {
            return _OwnershipTypeRepository.GetListActiveById(Id);
        }

        public List<OwnershipTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _OwnershipTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<OwnershipTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _OwnershipTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<OwnershipTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _OwnershipTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(OwnershipTypeViewModel objModel)
        {
            return _OwnershipTypeRepository.Create(objModel);
        }

        public bool Update(OwnershipTypeViewModel objModel)
        {
            return _OwnershipTypeRepository.Update(objModel);
        }

        public bool Delete(OwnershipTypeViewModel objModel)
        {
            return _OwnershipTypeRepository.Delete(objModel);
        }
    }
}
