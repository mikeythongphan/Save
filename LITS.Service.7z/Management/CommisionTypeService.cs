﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CommisionTypeService : ICommisionTypeService
    {
        private readonly ICommisionTypeRepository _CommisionTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CommisionTypeService(ICommisionTypeRepository CommisionTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CommisionTypeRepository = CommisionTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CommisionTypeViewModel> GetListAll()
        {
            return _CommisionTypeRepository.GetListAll();
        }

        public List<CommisionTypeViewModel> GetListById(int? Id)
        {
            return _CommisionTypeRepository.GetListById(Id);
        }

        public List<CommisionTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CommisionTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CommisionTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CommisionTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CommisionTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CommisionTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CommisionTypeViewModel> GetListActiveAll()
        {
            return _CommisionTypeRepository.GetListActiveAll();
        }

        public List<CommisionTypeViewModel> GetListActiveById(int? Id)
        {
            return _CommisionTypeRepository.GetListActiveById(Id);
        }

        public List<CommisionTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CommisionTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CommisionTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CommisionTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CommisionTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CommisionTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CommisionTypeViewModel objModel)
        {
            return _CommisionTypeRepository.Create(objModel);
        }

        public bool Update(CommisionTypeViewModel objModel)
        {
            return _CommisionTypeRepository.Update(objModel);
        }

        public bool Delete(CommisionTypeViewModel objModel)
        {
            return _CommisionTypeRepository.Delete(objModel);
        }
    }
}
