﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BorrowerTypeService : IBorrowerTypeService
    {
        private readonly IBorrowerTypeRepository _BorrowerTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BorrowerTypeService(IBorrowerTypeRepository BorrowerTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._BorrowerTypeRepository = BorrowerTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BorrowerTypeViewModel> GetListAll()
        {
            return _BorrowerTypeRepository.GetListAll();
        }

        public List<BorrowerTypeViewModel> GetListById(int? Id)
        {
            return _BorrowerTypeRepository.GetListById(Id);
        }

        public List<BorrowerTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _BorrowerTypeRepository.GetListByStatusId(StatusId);
        }

        public List<BorrowerTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _BorrowerTypeRepository.GetListByTypeId(TypeId);
        }

        public List<BorrowerTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BorrowerTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BorrowerTypeViewModel> GetListActiveAll()
        {
            return _BorrowerTypeRepository.GetListActiveAll();
        }

        public List<BorrowerTypeViewModel> GetListActiveById(int? Id)
        {
            return _BorrowerTypeRepository.GetListActiveById(Id);
        }

        public List<BorrowerTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BorrowerTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BorrowerTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BorrowerTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BorrowerTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BorrowerTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BorrowerTypeViewModel objModel)
        {
            return _BorrowerTypeRepository.Create(objModel);
        }

        public bool Update(BorrowerTypeViewModel objModel)
        {
            return _BorrowerTypeRepository.Update(objModel);
        }

        public bool Delete(BorrowerTypeViewModel objModel)
        {
            return _BorrowerTypeRepository.Delete(objModel);
        }
    }
}
