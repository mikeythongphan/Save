﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class OccupationService : IOccupationService
    {
        private readonly IOccupationRepository _OccupationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public OccupationService(IOccupationRepository OccupationRepository,
            IUnitOfWork unitOfWork)
        {
            this._OccupationRepository = OccupationRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<OccupationViewModel> GetListAll()
        {
            return _OccupationRepository.GetListAll();
        }

        public List<OccupationViewModel> GetListById(int? Id)
        {
            return _OccupationRepository.GetListById(Id);
        }

        public List<OccupationViewModel> GetListByStatusId(int? StatusId)
        {
            return _OccupationRepository.GetListByStatusId(StatusId);
        }

        public List<OccupationViewModel> GetListByTypeId(int? TypeId)
        {
            return _OccupationRepository.GetListByTypeId(TypeId);
        }

        public List<OccupationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _OccupationRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<OccupationViewModel> GetListActiveAll()
        {
            return _OccupationRepository.GetListActiveAll();
        }

        public List<OccupationViewModel> GetListActiveById(int? Id)
        {
            return _OccupationRepository.GetListActiveById(Id);
        }

        public List<OccupationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _OccupationRepository.GetListActiveByStatusId(StatusId);
        }

        public List<OccupationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _OccupationRepository.GetListActiveByTypeId(TypeId);
        }

        public List<OccupationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _OccupationRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(OccupationViewModel objModel)
        {
            return _OccupationRepository.Create(objModel);
        }

        public bool Update(OccupationViewModel objModel)
        {
            return _OccupationRepository.Update(objModel);
        }

        public bool Delete(OccupationViewModel objModel)
        {
            return _OccupationRepository.Delete(objModel);
        }
    }
}
