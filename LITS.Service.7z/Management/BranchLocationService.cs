﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BranchLocationService : IBranchLocationService
    {
        private readonly IBranchLocationRepository _BranchLocationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BranchLocationService(IBranchLocationRepository BranchLocationRepository,
            IUnitOfWork unitOfWork)
        {
            this._BranchLocationRepository = BranchLocationRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BranchLocationViewModel> GetListAll()
        {
            return _BranchLocationRepository.GetListAll();
        }

        public List<BranchLocationViewModel> GetListById(int? Id)
        {
            return _BranchLocationRepository.GetListById(Id);
        }

        public List<BranchLocationViewModel> GetListByStatusId(int? StatusId)
        {
            return _BranchLocationRepository.GetListByStatusId(StatusId);
        }

        public List<BranchLocationViewModel> GetListByTypeId(int? TypeId)
        {
            return _BranchLocationRepository.GetListByTypeId(TypeId);
        }

        public List<BranchLocationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BranchLocationRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BranchLocationViewModel> GetListActiveAll()
        {
            return _BranchLocationRepository.GetListActiveAll();
        }

        public List<BranchLocationViewModel> GetListActiveById(int? Id)
        {
            return _BranchLocationRepository.GetListActiveById(Id);
        }

        public List<BranchLocationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BranchLocationRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BranchLocationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BranchLocationRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BranchLocationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BranchLocationRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BranchLocationViewModel objModel)
        {
            return _BranchLocationRepository.Create(objModel);
        }

        public bool Update(BranchLocationViewModel objModel)
        {
            return _BranchLocationRepository.Update(objModel);
        }

        public bool Delete(BranchLocationViewModel objModel)
        {
            return _BranchLocationRepository.Delete(objModel);
        }
    }
}
