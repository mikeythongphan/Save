﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CICService : ICICService
    {
        private readonly ICICRepository _CICRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CICService(ICICRepository CICRepository,
            IUnitOfWork unitOfWork)
        {
            this._CICRepository = CICRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CicViewModel> GetListAll()
        {
            return _CICRepository.GetListAll();
        }

        public List<CicViewModel> GetListById(int? Id)
        {
            return _CICRepository.GetListById(Id);
        }

        public List<CicViewModel> GetListByStatusId(int? StatusId)
        {
            return _CICRepository.GetListByStatusId(StatusId);
        }

        public List<CicViewModel> GetListByTypeId(int? TypeId)
        {
            return _CICRepository.GetListByTypeId(TypeId);
        }

        public List<CicViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CICRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CicViewModel> GetListActiveAll()
        {
            return _CICRepository.GetListActiveAll();
        }

        public List<CicViewModel> GetListActiveById(int? Id)
        {
            return _CICRepository.GetListActiveById(Id);
        }

        public List<CicViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CICRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CicViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CICRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CicViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CICRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CicViewModel objModel)
        {
            return _CICRepository.Create(objModel);
        }

        public bool Update(CicViewModel objModel)
        {
            return _CICRepository.Update(objModel);
        }

        public bool Delete(CicViewModel objModel)
        {
            return _CICRepository.Delete(objModel);
        }
    }
}
