﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CustomerTypeService : ICustomerTypeService
    {
        private readonly ICustomerTypeRepository _CustomerTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CustomerTypeService(ICustomerTypeRepository CustomerTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CustomerTypeRepository = CustomerTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CustomerTypeViewModel> GetListAll()
        {
            return _CustomerTypeRepository.GetListAll();
        }

        public List<CustomerTypeViewModel> GetListById(int? Id)
        {
            return _CustomerTypeRepository.GetListById(Id);
        }

        public List<CustomerTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CustomerTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CustomerTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CustomerTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CustomerTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustomerTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CustomerTypeViewModel> GetListActiveAll()
        {
            return _CustomerTypeRepository.GetListActiveAll();
        }

        public List<CustomerTypeViewModel> GetListActiveById(int? Id)
        {
            return _CustomerTypeRepository.GetListActiveById(Id);
        }

        public List<CustomerTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CustomerTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CustomerTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CustomerTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CustomerTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustomerTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CustomerTypeViewModel objModel)
        {
            return _CustomerTypeRepository.Create(objModel);
        }

        public bool Update(CustomerTypeViewModel objModel)
        {
            return _CustomerTypeRepository.Update(objModel);
        }

        public bool Delete(CustomerTypeViewModel objModel)
        {
            return _CustomerTypeRepository.Delete(objModel);
        }
    }
}
