﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DefinitionTypeService : IDefinitionTypeService
    {
        private readonly IDefinitionTypeRepository _DefinitionTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DefinitionTypeService(IDefinitionTypeRepository DefinitionTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._DefinitionTypeRepository = DefinitionTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DefinitionTypeViewModel> GetListAll()
        {
            return _DefinitionTypeRepository.GetListAll();
        }

        public List<DefinitionTypeViewModel> GetListById(int? Id)
        {
            return _DefinitionTypeRepository.GetListById(Id);
        }

        public List<DefinitionTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _DefinitionTypeRepository.GetListByStatusId(StatusId);
        }

        public List<DefinitionTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _DefinitionTypeRepository.GetListByTypeId(TypeId);
        }

        public List<DefinitionTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DefinitionTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DefinitionTypeViewModel> GetListByParentId(int? ParentId)
        {
            return _DefinitionTypeRepository.GetListByParentId(ParentId);
        }

        public List<DefinitionTypeViewModel> GetListByGroupId(int? GroupId)
        {
            return _DefinitionTypeRepository.GetListByGroupId(GroupId);
        }

        public List<DefinitionTypeViewModel> GetListActiveAll()
        {
            return _DefinitionTypeRepository.GetListActiveAll();
        }

        public List<DefinitionTypeViewModel> GetListActiveById(int? Id)
        {
            return _DefinitionTypeRepository.GetListActiveById(Id);
        }

        public List<DefinitionTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _DefinitionTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DefinitionTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _DefinitionTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DefinitionTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _DefinitionTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DefinitionTypeViewModel> GetListActiveByParentId(int? ParentId)
        {
            return _DefinitionTypeRepository.GetListActiveByParentId(ParentId);
        }

        public List<DefinitionTypeViewModel> GetListActiveByGroupId(int? GroupId)
        {
            return _DefinitionTypeRepository.GetListActiveByGroupId(GroupId);
        }

        public bool Create(DefinitionTypeViewModel objModel)
        {
            return _DefinitionTypeRepository.Create(objModel);
        }

        public bool Update(DefinitionTypeViewModel objModel)
        {
            return _DefinitionTypeRepository.Update(objModel);
        }

        public bool Delete(DefinitionTypeViewModel objModel)
        {
            return _DefinitionTypeRepository.Delete(objModel);
        }
    }
}
