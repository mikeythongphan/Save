﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CityService : ICityService
    {
        private readonly ICityRepository _CityRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CityService(ICityRepository CityRepository,
            IUnitOfWork unitOfWork)
        {
            this._CityRepository = CityRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CityViewModel> GetListAll()
        {
            return _CityRepository.GetListAll();
        }

        public List<CityViewModel> GetListById(int? Id)
        {
            return _CityRepository.GetListById(Id);
        }

        public List<CityViewModel> GetListByStatusId(int? StatusId)
        {
            return _CityRepository.GetListByStatusId(StatusId);
        }

        public List<CityViewModel> GetListByTypeId(int? TypeId)
        {
            return _CityRepository.GetListByTypeId(TypeId);
        }

        public List<CityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CityRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CityViewModel> GetListActiveAll()
        {
            return _CityRepository.GetListActiveAll();
        }

        public List<CityViewModel> GetListActiveById(int? Id)
        {
            return _CityRepository.GetListActiveById(Id);
        }

        public List<CityViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CityRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CityViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CityRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CityRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CityViewModel objModel)
        {
            return _CityRepository.Create(objModel);
        }

        public bool Update(CityViewModel objModel)
        {
            return _CityRepository.Update(objModel);
        }

        public bool Delete(CityViewModel objModel)
        {
            return _CityRepository.Delete(objModel);
        }
    }
}
