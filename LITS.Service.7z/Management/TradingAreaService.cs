﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class TradingAreaService : ITradingAreaService
    {
        private readonly ITradingAreaRepository _TradingAreaRepository;

        private readonly IUnitOfWork _unitOfWork;

        public TradingAreaService(ITradingAreaRepository TradingAreaRepository,
            IUnitOfWork unitOfWork)
        {
            this._TradingAreaRepository = TradingAreaRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<TradingAreaViewModel> GetListAll()
        {
            return _TradingAreaRepository.GetListAll();
        }

        public List<TradingAreaViewModel> GetListById(int? Id)
        {
            return _TradingAreaRepository.GetListById(Id);
        }

        public List<TradingAreaViewModel> GetListByStatusId(int? StatusId)
        {
            return _TradingAreaRepository.GetListByStatusId(StatusId);
        }

        public List<TradingAreaViewModel> GetListByTypeId(int? TypeId)
        {
            return _TradingAreaRepository.GetListByTypeId(TypeId);
        }

        public List<TradingAreaViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _TradingAreaRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<TradingAreaViewModel> GetListActiveAll()
        {
            return _TradingAreaRepository.GetListActiveAll();
        }

        public List<TradingAreaViewModel> GetListActiveById(int? Id)
        {
            return _TradingAreaRepository.GetListActiveById(Id);
        }

        public List<TradingAreaViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _TradingAreaRepository.GetListActiveByStatusId(StatusId);
        }

        public List<TradingAreaViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _TradingAreaRepository.GetListActiveByTypeId(TypeId);
        }

        public List<TradingAreaViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _TradingAreaRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(TradingAreaViewModel objModel)
        {
            return _TradingAreaRepository.Create(objModel);
        }

        public bool Update(TradingAreaViewModel objModel)
        {
            return _TradingAreaRepository.Update(objModel);
        }

        public bool Delete(TradingAreaViewModel objModel)
        {
            return _TradingAreaRepository.Delete(objModel);
        }
    }
}
