﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CompanyTypeService : ICompanyTypeService
    {
        private readonly ICompanyTypeRepository _CompanyTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CompanyTypeService(ICompanyTypeRepository CompanyTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CompanyTypeRepository = CompanyTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CompanyTypeViewModel> GetListAll()
        {
            return _CompanyTypeRepository.GetListAll();
        }

        public List<CompanyTypeViewModel> GetListById(int? Id)
        {
            return _CompanyTypeRepository.GetListById(Id);
        }

        public List<CompanyTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CompanyTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CompanyTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CompanyTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CompanyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CompanyTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CompanyTypeViewModel> GetListActiveAll()
        {
            return _CompanyTypeRepository.GetListActiveAll();
        }

        public List<CompanyTypeViewModel> GetListActiveById(int? Id)
        {
            return _CompanyTypeRepository.GetListActiveById(Id);
        }

        public List<CompanyTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CompanyTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CompanyTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CompanyTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CompanyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CompanyTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CompanyTypeViewModel objModel)
        {
            return _CompanyTypeRepository.Create(objModel);
        }

        public bool Update(CompanyTypeViewModel objModel)
        {
            return _CompanyTypeRepository.Update(objModel);
        }

        public bool Delete(CompanyTypeViewModel objModel)
        {
            return _CompanyTypeRepository.Delete(objModel);
        }
    }
}
