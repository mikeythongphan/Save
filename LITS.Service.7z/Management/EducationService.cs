﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class EducationService : IEducationService
    {
        private readonly IEducationRepository _EducationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public EducationService(IEducationRepository EducationRepository,
            IUnitOfWork unitOfWork)
        {
            this._EducationRepository = EducationRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<EducationViewModel> GetListAll()
        {
            return _EducationRepository.GetListAll();
        }

        public List<EducationViewModel> GetListById(int? Id)
        {
            return _EducationRepository.GetListById(Id);
        }

        public List<EducationViewModel> GetListByStatusId(int? StatusId)
        {
            return _EducationRepository.GetListByStatusId(StatusId);
        }

        public List<EducationViewModel> GetListByTypeId(int? TypeId)
        {
            return _EducationRepository.GetListByTypeId(TypeId);
        }

        public List<EducationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _EducationRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<EducationViewModel> GetListActiveAll()
        {
            return _EducationRepository.GetListActiveAll();
        }

        public List<EducationViewModel> GetListActiveById(int? Id)
        {
            return _EducationRepository.GetListActiveById(Id);
        }

        public List<EducationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _EducationRepository.GetListActiveByStatusId(StatusId);
        }

        public List<EducationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _EducationRepository.GetListActiveByTypeId(TypeId);
        }

        public List<EducationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _EducationRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(EducationViewModel objModel)
        {
            return _EducationRepository.Create(objModel);
        }

        public bool Update(EducationViewModel objModel)
        {
            return _EducationRepository.Update(objModel);
        }

        public bool Delete(EducationViewModel objModel)
        {
            return _EducationRepository.Delete(objModel);
        }
    }
}
