﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BusinessNatureService : IBusinessNatureService
    {
        private readonly IBusinessNatureRepository _BusinessNatureRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BusinessNatureService(IBusinessNatureRepository BusinessNatureRepository,
            IUnitOfWork unitOfWork)
        {
            this._BusinessNatureRepository = BusinessNatureRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BusinessNatureViewModel> GetListAll()
        {
            return _BusinessNatureRepository.GetListAll();
        }

        public List<BusinessNatureViewModel> GetListById(int? Id)
        {
            return _BusinessNatureRepository.GetListById(Id);
        }

        public List<BusinessNatureViewModel> GetListByStatusId(int? StatusId)
        {
            return _BusinessNatureRepository.GetListByStatusId(StatusId);
        }

        public List<BusinessNatureViewModel> GetListByTypeId(int? TypeId)
        {
            return _BusinessNatureRepository.GetListByTypeId(TypeId);
        }

        public List<BusinessNatureViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BusinessNatureRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BusinessNatureViewModel> GetListActiveAll()
        {
            return _BusinessNatureRepository.GetListActiveAll();
        }

        public List<BusinessNatureViewModel> GetListActiveById(int? Id)
        {
            return _BusinessNatureRepository.GetListActiveById(Id);
        }

        public List<BusinessNatureViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BusinessNatureRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BusinessNatureViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BusinessNatureRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BusinessNatureViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BusinessNatureRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BusinessNatureViewModel objModel)
        {
            return _BusinessNatureRepository.Create(objModel);
        }

        public bool Update(BusinessNatureViewModel objModel)
        {
            return _BusinessNatureRepository.Update(objModel);
        }

        public bool Delete(BusinessNatureViewModel objModel)
        {
            return _BusinessNatureRepository.Delete(objModel);
        }
    }
}
