﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class FloatingInterestRateService : IFloatingInterestRateService
    {
        private readonly IFloatingInterestRateRepository _FloatingInterestRateRepository;

        private readonly IUnitOfWork _unitOfWork;

        public FloatingInterestRateService(IFloatingInterestRateRepository FloatingInterestRateRepository,
            IUnitOfWork unitOfWork)
        {
            this._FloatingInterestRateRepository = FloatingInterestRateRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<FloatingInterestRateViewModel> GetListAll()
        {
            return _FloatingInterestRateRepository.GetListAll();
        }

        public List<FloatingInterestRateViewModel> GetListById(int? Id)
        {
            return _FloatingInterestRateRepository.GetListById(Id);
        }

        public List<FloatingInterestRateViewModel> GetListByStatusId(int? StatusId)
        {
            return _FloatingInterestRateRepository.GetListByStatusId(StatusId);
        }

        public List<FloatingInterestRateViewModel> GetListByTypeId(int? TypeId)
        {
            return _FloatingInterestRateRepository.GetListByTypeId(TypeId);
        }

        public List<FloatingInterestRateViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _FloatingInterestRateRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<FloatingInterestRateViewModel> GetListActiveAll()
        {
            return _FloatingInterestRateRepository.GetListActiveAll();
        }

        public List<FloatingInterestRateViewModel> GetListActiveById(int? Id)
        {
            return _FloatingInterestRateRepository.GetListActiveById(Id);
        }

        public List<FloatingInterestRateViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _FloatingInterestRateRepository.GetListActiveByStatusId(StatusId);
        }

        public List<FloatingInterestRateViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _FloatingInterestRateRepository.GetListActiveByTypeId(TypeId);
        }

        public List<FloatingInterestRateViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _FloatingInterestRateRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(FloatingInterestRateViewModel objModel)
        {
            return _FloatingInterestRateRepository.Create(objModel);
        }

        public bool Update(FloatingInterestRateViewModel objModel)
        {
            return _FloatingInterestRateRepository.Update(objModel);
        }

        public bool Delete(FloatingInterestRateViewModel objModel)
        {
            return _FloatingInterestRateRepository.Delete(objModel);
        }
    }
}
