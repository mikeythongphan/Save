﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class CustomerIncomeService : ICustomerIncomeService
    {
        public CustomerIncomeService()
        {
        }

        public void Create(CustomerIncomeViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        approval_information data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, approval_information>(sc);
                        context.approval_information.Add(data);
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(CustomerIncomeViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, approval_information>(obj);
                            context.approval_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public CustomerIncomeViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public CustomerIncomeViewModel GetById(int? Id)
        {
            CustomerIncomeViewModel obj = new CustomerIncomeViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.approval_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<approval_information, CustomerIncomeViewModel>(data);
            return obj;
        }

        public void Update(CustomerIncomeViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, approval_information>(obj);
                        context.approval_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
