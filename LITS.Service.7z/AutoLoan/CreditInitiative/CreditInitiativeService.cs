﻿#region System
using System;
using System.Linq;
using System.Data.Entity;
#endregion

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
#endregion

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class CreditInitiativeService : ICreditInitiativeService
    {
        #region CreditInitiative
        private readonly ICreditInitiativeRepository _CreditInitiativeRepository;
        private readonly IApplicationInformationRepository _ApplicationInformationRepository;
        private readonly IAppliedLoanInformationRepository _AppliedLoanInformationRepository;
        private readonly IARTARepository _ARTARepository;
        private readonly ICollateralInformationRepository _CollateralInformationRepository;
        private readonly ICustomerInformationRepository _CustomerInformationRepository;
        private readonly ICustomerCreditBureauRepository _CustomerCreditBureauRepository;
        private readonly ICustomerDemostrationRepository _CustomerDemostrationRepository;
        private readonly ICustomerIncomeRepository _CustomerIncomeRepository;
        private readonly IApprovalInformationRepository _ApprovalInformationRepository;
        #endregion

        #region MetaData
        private readonly IBranchCodeRepository _BranchCodeRepository;
        private readonly IBranchLocationRepository _BranchLocationRepository;
        private readonly ICustomerTypeRepository _CustomerTypeRepository;
        private readonly IFloatingInterestRateRepository _FloatingInterestRateRepository;
        private readonly ILoanPurposeRepository _LoanPurposeRepository;
        private readonly ILoanTenorRepository _LoanTenorRepository;
        private readonly IPaymentTypeRepository _PaymentTypeRepository;
        private readonly IProductTypeRepository _ProductTypeRepository;
        private readonly IProductRepository _ProductRepository;
        private readonly IProgramTypeRepository _ProgramTypeRepository;
        private readonly IPropertySaleRepository _PropertySaleRepository;
        private readonly IPropertyStatusRepository _PropertyStatusRepository;
        private readonly IPropertyTypeRepository _PropertyTypeRepository;
        private readonly ITradingAreaRepository _TradingAreaRepository;
        private readonly IIncomeTypeRepository _IncomeTypeRepository;
        private readonly ISalesChannelRepository _SalesChannelRepository;
        private readonly ICustomerSegmentRepository _CustomerSegmentRepository;
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;
        private readonly ICDDRepository _CDDRepository;
        private readonly ICICRepository _CICRepository;
        private readonly IReasonRepository _ReasonRepository;
        private readonly IStatusRepository _StatusRepository;
        private readonly ITypeRepository _TypeRepository;
        private readonly IBorrowerTypeRepository _BorrowerTypeRepository;
        private readonly IBankTypeRepository _BankTypeRepository;
        private readonly IBonusTypeRepository _BonusTypeRepository;
        private readonly IBusinessNatureRepository _BusinessNatureRepository;
        private readonly IBusinessTypeRepository _BusinessTypeRepository;
        private readonly ICityRepository _CityRepository;
        private readonly ICommisionTypeRepository _CommisionTypeRepository;
        private readonly ICompanyTypeRepository _CompanyTypeRepository;
        private readonly ICreditBureauTypeRepository _CreditBureauTypeRepository;
        private readonly ICreditDeviationRepository _CreditDeviationRepository;
        private readonly ICriteriaRepository _CriteriaRepository;
        private readonly ICurrentResidentTypeRepository _CurrentResidentTypeRepository;
        private readonly ICustodyTypeRepository _CustodyTypeRepository;
        private readonly IDeviationCodeRepository _DeviationCodeRepository;
        private readonly IDisbursalScenarioConditionRepository _DisbursalScenarioConditionRepository;
        private readonly IDisbursalScenarioRepository _DisbursalScenarioRepository;
        private readonly IDistrictRepository _DistrictRepository;
        private readonly IDuplicationTypeRepository _DuplicationTypeRepository;
        private readonly IEducationRepository _EducationRepository;
        private readonly IEmploymentTypeRepository _EmploymentTypeRepository;
        private readonly IIdentificationTypeRepository _IdentificationTypeRepository;
        private readonly IIndustryRepository _IndustryRepository;
        private readonly IInterestClassificationRepository _InterestClassificationRepository;
        private readonly IInvestigaveTypeRepository _InvestigaveTypeRepository;
        private readonly ILabourContractTypeRepository _LabourContractTypeRepository;
        private readonly ILoanTrendRepository _LoanTrendRepository;
        private readonly ILoanTypeRepository _LoanTypeRepository;
        private readonly IMaritalStatusRepository _MaritalStatusRepository;
        private readonly INationalityRepository _NationalityRepository;
        private readonly IOwnershipTypeRepository _OwnershipTypeRepository;
        private readonly IPaymentMethodRepository _PaymentMethodRepository;
        private readonly IPaymentOptionRepository _PaymentOptionRepository;
        private readonly IPositionRepository _PositionRepository;
        private readonly IProgramCodeRepository _ProgramCodeRepository;
        private readonly IResidenceOwnershipRepository _ResidenceOwnershipRepository;
        private readonly ICompanyCodeRepository _CompanyCodeRepository;
        private readonly IOccupationRepository _OccupationRepository;
        private readonly IDefinitionTypeRepository _DefinitionTypeRepository;
        #endregion

        private readonly IUnitOfWork _unitOfWork;

        #region Contructor
        public CreditInitiativeService(ICreditInitiativeRepository CreditInitiativeRepository,
            IApplicationInformationRepository ApplicationInformationRepository,
            IAppliedLoanInformationRepository AppliedLoanInformationRepository,
            IARTARepository ARTARepository,
            IApprovalInformationRepository ApprovalInformationRepository,
            ICollateralInformationRepository CollateralInformationRepository,
            ICustomerInformationRepository CustomerInformationRepository,
            ICustomerCreditBureauRepository CustomerCreditBureauRepository,
            ICustomerDemostrationRepository CustomerDemostrationRepository,
            ICustomerIncomeRepository CustomerIncomeRepository,
            IBranchCodeRepository BranchCodeRepository,
            IBranchLocationRepository BranchLocationRepository,
            ICustomerTypeRepository CustomerTypeRepository,
            IFloatingInterestRateRepository FloatingInterestRateRepository,
            ILoanPurposeRepository LoanPurposeRepository,
            ILoanTenorRepository LoanTenorRepository,
            IPaymentTypeRepository PaymentTypeRepository,
            IProductTypeRepository ProductTypeRepository,
            IProductRepository ProductRepository,
            IProgramTypeRepository ProgramTypeRepository,
            IPropertySaleRepository PropertySaleRepository,
            IPropertyStatusRepository PropertyStatusRepository,
            IPropertyTypeRepository PropertyTypeRepository,
            ITradingAreaRepository TradingAreaRepository,
            IIncomeTypeRepository IncomeTypeRepository,
            ISalesChannelRepository SalesChannelRepository,
            ICustomerSegmentRepository CustomerSegmentRepository,
            ICustomerRelationshipRepository CustomerRelationshipRepository,
            ICDDRepository CDDRepository,
            ICICRepository CICRepository,
            IReasonRepository ReasonRepository,
            IStatusRepository StatusRepository,
            ITypeRepository TypeRepository,
            IBorrowerTypeRepository BorrowerTypeRepository,
            IBankTypeRepository BankTypeRepository,
            IBonusTypeRepository BonusTypeRepository,
            IBusinessNatureRepository BusinessNatureRepository,
            IBusinessTypeRepository BusinessTypeRepository,
            ICityRepository CityRepository,
            ICommisionTypeRepository CommisionTypeRepository,
            ICompanyTypeRepository CompanyTypeRepository,
            ICreditBureauTypeRepository CreditBureauTypeRepository,
            ICreditDeviationRepository CreditDeviationRepository,
            ICriteriaRepository CriteriaRepository,
            ICurrentResidentTypeRepository CurrentResidentTypeRepository,
            ICustodyTypeRepository CustodyTypeRepository,
            IDeviationCodeRepository DeviationCodeRepository,
            IDisbursalScenarioConditionRepository DisbursalScenarioConditionRepository,
            IDisbursalScenarioRepository DisbursalScenarioRepository,
            IDistrictRepository DistrictRepository,
            IDuplicationTypeRepository DuplicationTypeRepository,
            IEducationRepository EducationRepository,
            IEmploymentTypeRepository EmploymentTypeRepository,
            IIdentificationTypeRepository IdentificationTypeRepository,
            IIndustryRepository IndustryRepository,
            IInterestClassificationRepository InterestClassificationRepository,
            IInvestigaveTypeRepository InvestigaveTypeRepository,
            ILabourContractTypeRepository LabourContractTypeRepository,
            ILoanTrendRepository LoanTrendRepository,
            ILoanTypeRepository LoanTypeRepository,
            IMaritalStatusRepository MaritalStatusRepository,
            INationalityRepository NationalityRepository,
            IOwnershipTypeRepository OwnershipTypeRepository,
            IPaymentMethodRepository PaymentMethodRepository,
            IPaymentOptionRepository PaymentOptionRepository,
            IPositionRepository PositionRepository,
            IProgramCodeRepository ProgramCodeRepository,
            IResidenceOwnershipRepository ResidenceOwnershipRepository,
            ICompanyCodeRepository CompanyCodeRepository,
            IOccupationRepository OccupationRepository,
            IDefinitionTypeRepository DefinitionTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CreditInitiativeRepository = CreditInitiativeRepository;
            this._ApplicationInformationRepository = ApplicationInformationRepository;
            this._AppliedLoanInformationRepository = AppliedLoanInformationRepository;
            this._ARTARepository = ARTARepository;
            this._ApprovalInformationRepository = ApprovalInformationRepository;
            this._CollateralInformationRepository = CollateralInformationRepository;
            this._CustomerInformationRepository = CustomerInformationRepository;
            this._CustomerCreditBureauRepository = CustomerCreditBureauRepository;
            this._CustomerDemostrationRepository = CustomerDemostrationRepository;
            this._CustomerIncomeRepository = CustomerIncomeRepository;
            this._BranchCodeRepository = BranchCodeRepository;
            this._BranchLocationRepository = BranchLocationRepository;
            this._CustomerTypeRepository = CustomerTypeRepository;
            this._FloatingInterestRateRepository = FloatingInterestRateRepository;
            this._LoanPurposeRepository = LoanPurposeRepository;
            this._LoanTenorRepository = LoanTenorRepository;
            this._PaymentTypeRepository = PaymentTypeRepository;
            this._ProductTypeRepository = ProductTypeRepository;
            this._ProductRepository = ProductRepository;
            this._ProgramTypeRepository = ProgramTypeRepository;
            this._PropertySaleRepository = PropertySaleRepository;
            this._PropertyStatusRepository = PropertyStatusRepository;
            this._PropertyTypeRepository = PropertyTypeRepository;
            this._TradingAreaRepository = TradingAreaRepository;
            this._IncomeTypeRepository = IncomeTypeRepository;
            this._SalesChannelRepository = SalesChannelRepository;
            this._CustomerSegmentRepository = CustomerSegmentRepository;
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._CDDRepository = CDDRepository;
            this._CICRepository = CICRepository;
            this._ReasonRepository = ReasonRepository;
            this._StatusRepository = StatusRepository;
            this._TypeRepository = TypeRepository;
            this._BorrowerTypeRepository = BorrowerTypeRepository;
            this._BankTypeRepository = BankTypeRepository;
            this._BonusTypeRepository = BonusTypeRepository;
            this._BusinessNatureRepository = BusinessNatureRepository;
            this._BusinessTypeRepository = BusinessTypeRepository;
            this._CityRepository = CityRepository;
            this._CommisionTypeRepository = CommisionTypeRepository;
            this._CompanyTypeRepository = CompanyTypeRepository;
            this._CreditBureauTypeRepository = CreditBureauTypeRepository;
            this._CreditDeviationRepository = CreditDeviationRepository;
            this._CriteriaRepository = CriteriaRepository;
            this._CurrentResidentTypeRepository = CurrentResidentTypeRepository;
            this._CustodyTypeRepository = CustodyTypeRepository;
            this._DeviationCodeRepository = DeviationCodeRepository;
            this._DisbursalScenarioConditionRepository = DisbursalScenarioConditionRepository;
            this._DisbursalScenarioRepository = DisbursalScenarioRepository;
            this._DistrictRepository = DistrictRepository;
            this._DuplicationTypeRepository = DuplicationTypeRepository;
            this._EducationRepository = EducationRepository;
            this._EmploymentTypeRepository = EmploymentTypeRepository;
            this._IdentificationTypeRepository = IdentificationTypeRepository;
            this._IndustryRepository = IndustryRepository;
            this._InterestClassificationRepository = InterestClassificationRepository;
            this._InvestigaveTypeRepository = InvestigaveTypeRepository;
            this._LabourContractTypeRepository = LabourContractTypeRepository;
            this._LoanTrendRepository = LoanTrendRepository;
            this._LoanTypeRepository = LoanTypeRepository;
            this._MaritalStatusRepository = MaritalStatusRepository;
            this._NationalityRepository = NationalityRepository;
            this._OwnershipTypeRepository = OwnershipTypeRepository;
            this._PaymentMethodRepository = PaymentMethodRepository;
            this._PaymentOptionRepository = PaymentOptionRepository;
            this._PositionRepository = PositionRepository;
            this._ProgramCodeRepository = ProgramCodeRepository;
            this._ResidenceOwnershipRepository = ResidenceOwnershipRepository;
            this._CompanyCodeRepository = CompanyCodeRepository;
            this._OccupationRepository = OccupationRepository;
            this._DefinitionTypeRepository = DefinitionTypeRepository;
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region Implement

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel LoadIndex(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            #region ConfigControl
            objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            #endregion

            #region MetaData
            objParam = LoadMetaData(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            #endregion

            return _CreditInitiativeRepository.LoadIndex(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Save(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._ApplicationInformationViewModel = _ApplicationInformationRepository
                .Save(objParam._ApplicationInformationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._AppliedLoanInformationViewModel = _AppliedLoanInformationRepository
                .Save(objParam._AppliedLoanInformationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._ApprovalInformationViewModel = _ApprovalInformationRepository
                .Save(objParam._ApprovalInformationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._ARTAViewModel = _ARTARepository
                .Save(objParam._ARTAViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._CollateralInformationViewModel = _CollateralInformationRepository
                .Save(objParam._CollateralInformationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._CustomerCreditBureauViewModel = _CustomerCreditBureauRepository
                .Save(objParam._CustomerCreditBureauViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._CustomerDemostrationViewModel = _CustomerDemostrationRepository
                .Save(objParam._CustomerDemostrationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._CustomerIncomeViewModel = _CustomerIncomeRepository
                .Save(objParam._CustomerIncomeViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam._CustomerInformationViewModel = _CustomerInformationRepository
                .Save(objParam._CustomerInformationViewModel, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam = _CreditInitiativeRepository.Save(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            _unitOfWork.Commit();

            return objParam;
        }

        /// <summary>
        /// ByPass
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel ByPass(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.ByPass(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// SendBackSC
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel SendBackSC(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.SendBackSC(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// SendBackOS
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel SendBackOS(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.SendBackOS(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Recommend
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Recommend(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.Recommend(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Reject
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Reject(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.Reject(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Cancel
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Cancel(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.Cancel(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Approved
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Approved(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.Approved(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// ReturnCI
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel ReturnCI(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.ReturnCI(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel Print(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.Print(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// NSG
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel NSG(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.NSG(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// RequeueTeleVerifier
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel RequeueTeleVerifier(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.RequeueTeleVerifier(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// DownloadIncomeSheet
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel DownloadIncomeSheet(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.DownloadIncomeSheet(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// FRMQueue
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel FRMQueue(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _CreditInitiativeRepository.FRMQueue(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Visible Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel VisibleControl(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "CIMaker":
                    {
                        #region CIMaker

                        #region ApplicationInformation
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationDuplication = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationNo = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleARMCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBlackList = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBranchCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBranchLocation = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCDD = true;
                        objParam._ApplicationInformationViewModel.IsVisibleChannel = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCustomerSegment = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCustomerType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleeOpsTxnReference = true;
                        objParam._ApplicationInformationViewModel.IsVisibleExisting = true;
                        objParam._ApplicationInformationViewModel.IsVisibleHardCopyApplicationDate = true;
                        objParam._ApplicationInformationViewModel.IsVisibleICT = true;
                        objParam._ApplicationInformationViewModel.IsVisiblePeoplewiseIDOfSaleStaf = true;
                        objParam._ApplicationInformationViewModel.IsVisibleProductType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleProgramType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleReasonForRework = true;
                        objParam._ApplicationInformationViewModel.IsVisibleReceivingDate = true;
                        objParam._ApplicationInformationViewModel.IsVisibleRework = true;
                        objParam._ApplicationInformationViewModel.IsVisibleSalesCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleSaleTMPWID = true;
                        objParam._ApplicationInformationViewModel.IsVisibleStafNonStaf = true;
                        #endregion

                        #region CustomerInformation                        
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEducationLever = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEducationLever = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEducationLever = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleTypeOfResidenceOwnership = true;
                        #endregion

                        #region CustomerIncome

                        #region CoBorrower1

                        #region CarRental

                        #region Income_1
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1.IsVisibleTypeOfCar = true;
                        #endregion

                        #region Income_2
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2.IsVisibleTypeOfCar = true;
                        #endregion

                        #region Income_3
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3.IsVisibleTypeOfCar = true;
                        #endregion

                        #region Income_4
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4.IsVisibleTypeOfCar = true;
                        #endregion

                        #region Income_5
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_5.IsVisibleTypeOfCar = true;
                        #endregion

                        #region Income_6
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleBorrowerType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleCarOwnershipName = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleCarPlateNumber = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleDetailsOfCarforRent = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleIncomeType = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleRentalContractTenure = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleTotalCarRentalIncome = true;
                        objParam._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_6.IsVisibleTypeOfCar = true;
                        #endregion

                        #endregion

                        #endregion

                        #endregion

                        #region AppliedLoanInformation
                        objParam._AppliedLoanInformationViewModel.IsVisibleAmountRequested = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleApplicationType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleCampaignCode = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleCreditDeviation = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleFloatingInterestRate = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleLoanPurpose = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleLTV = true;
                        objParam._AppliedLoanInformationViewModel.IsVisiblePaymentType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleProgramType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleReasonForDeviation = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleTenors = true;
                        #endregion

                        #region ARTA
                        objParam._ARTAViewModel.IsVisibleApplicationNumber = true;
                        objParam._ARTAViewModel.IsVisibleApplicationStatus = true;
                        objParam._ARTAViewModel.IsVisibleApplicationType = true;
                        objParam._ARTAViewModel.IsVisibleAppliedPremium = true;
                        objParam._ARTAViewModel.IsVisibleAppliedSumAssured = true;
                        objParam._ARTAViewModel.IsVisibleARTA = true;
                        objParam._ARTAViewModel.IsVisibleLifeAssured = true;
                        objParam._ARTAViewModel.IsVisiblePaymentOption = true;
                        #endregion

                        #region CollateralInformation
                        objParam._CollateralInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._CollateralInformationViewModel.IsVisibleApplicationType = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarMarkerBrand = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarSource = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarType = true;
                        objParam._CollateralInformationViewModel.IsVisibleChassisNumber = true;
                        objParam._CollateralInformationViewModel.IsVisibleCollateralValue = true;
                        objParam._CollateralInformationViewModel.IsVisibleColor = true;
                        objParam._CollateralInformationViewModel.IsVisibleModel = true;
                        objParam._CollateralInformationViewModel.IsVisibleNumberOfSeats = true;
                        objParam._CollateralInformationViewModel.IsVisiblePropertyStatus = true;
                        objParam._CollateralInformationViewModel.IsVisiblePurchasingPriceOrFairMarketValue = true;
                        objParam._CollateralInformationViewModel.IsVisiblePurchasingSPContractNumber = true;
                        objParam._CollateralInformationViewModel.IsVisibleYearOfManufacture = true; ;
                        #endregion

                        #region CustomerCreditBureau
                        objParam._CustomerCreditBureauViewModel.IsVisibleTotalCurrentMonthlyIndividualObligationRepayment = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalOutStandingBalanceCreditCard = true;
                        #endregion

                        #region CustomerDemostration
                        objParam._CustomerDemostrationViewModel.IsVisibleApplicationStatus = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleApplicationType = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleMonthlyExpenditure = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleOtherAsset = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalCarOwned = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalFDvalue = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalPropertyOwned = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "CIChecker":
                    {

                        break;
                    }
                case "CIMaster":
                    {

                        break;
                    }
                case "CIViewer":
                    {

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// Readonly Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel ReadonlyControl(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "SCMaker":
                    {
                        #region CreateNewLoanStep1

                        #endregion

                        #region CreateNewLoanStep2

                        #endregion

                        #region CreateNewLoanStep3

                        #endregion

                        break;
                    }
                case "SCChecker":
                    {

                        break;
                    }
                case "SCMaster":
                    {

                        break;
                    }
                case "SCViewer":
                    {

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// LoadMetaData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreditInitiativeViewModel LoadMetaData(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._M_BranchCodeViewModel = _BranchCodeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BranchLocationViewModel = _BranchLocationRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentTypeViewModel = _PaymentTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProductViewModel = _ProductRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProgramTypeViewModel = _ProgramTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertySaleViewModel = _PropertySaleRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyStatusViewModel = _PropertyStatusRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyTypeViewModel = _PropertyTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TradingAreaViewModel = _TradingAreaRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_StatusViewModel = _StatusRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TypeViewModel = _TypeRepository.GetListActiveById(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_SalesChannelViewModel = _SalesChannelRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ReasonViewModel = _ReasonRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CDDViewModel = _CDDRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BorrowerTypeViewModel = _BorrowerTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BusinessNatureViewModel = _BusinessNatureRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BusinessTypeViewModel = _BusinessTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CompanyCodeViewModel = _CompanyCodeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CompanyTypeViewModel = _CompanyTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CreditBureauTypeViewModel = _CreditBureauTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CreditDeviationViewModel = _CreditDeviationRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerRelationshipViewModel = _CustomerRelationshipRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_EmploymentTypeViewModel = _EmploymentTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_IncomeTypeViewModel = _IncomeTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_IndustryViewModel = _IndustryRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LabourContractTypeViewModel = _LabourContractTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_OccupationViewModel = _OccupationRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentMethodViewModel = _PaymentMethodRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CarRepaymentCycle = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_HouseRepaymentCycle = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PeriodOfSubmittedBSViewModel = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PositionViewModel = _PositionRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_DistrictViewModel = _DistrictRepository.GetListActiveByTypeId(objParam._ApplicationInformationViewModel.ApplicationTypeID);

            return objParam;
        }

        #endregion
    }
}
