﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class CustomerInformationService : ICustomerInformationService
    {
        public CustomerInformationService()
        {
        }

        public void Create(CustomerInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        customer_information data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(sc);
                        context.customer_information.Add(data);
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(CustomerInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            //obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(obj);
                            context.customer_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public CustomerInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public CustomerInformationViewModel GetById(int? Id)
        {
            CustomerInformationViewModel obj = new CustomerInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.customer_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<customer_information, CustomerInformationViewModel>(data);
            return obj;
        }

        public void Update(CustomerInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerInformationViewModel, customer_information>(obj);
                        context.customer_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
