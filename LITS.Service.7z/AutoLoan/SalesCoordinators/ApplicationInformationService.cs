﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.SalesCoordinators
{
    public class ApplicationInformationService : IApplicationInformationService
    {
        private readonly IApplicationInformationRepository _applicationInformationRepository;

        private readonly IUnitOfWork _unitOfWork;

        /// <summary>
        /// Application Information Service
        /// </summary>
        /// <param name="applicationInformationRepository">ICustomerInformationRepository</param>
        /// <param name="unitOfWork">IUnitOfWork</param>
        public ApplicationInformationService(IApplicationInformationRepository applicationInformationRepository,
            IUnitOfWork unitOfWork)
        {
            this._applicationInformationRepository = applicationInformationRepository;
            this._unitOfWork = unitOfWork;
        }

        #region ApplicationInformationService Members
        /// <summary>
        /// Application Information ViewModel
        /// </summary>
        /// <param name="Id">int</param>
        public ApplicationInformationViewModel GetById(int? Id)
        {
            ApplicationInformationViewModel obj = new ApplicationInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.application_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<application_information, ApplicationInformationViewModel>(data);
            return obj;
        }

        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public ApplicationInformationViewModel GetAll()
        {
            ApplicationInformationViewModel obj = new ApplicationInformationViewModel();
            return obj;
        }

        /// <summary>
        /// GetApplicationInformation
        /// </summary>
        /// <param name="Id">int</param>
        /// <returns></returns>
        public application_information GetApplicationInformation(int? Id)
        {
            application_information obj = new application_information();
            return obj;
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <param name="sc">ApplicationInformationViewModel</param>
        public void Create(ApplicationInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        application_information data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(sc);

                        context.application_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj">ApplicationInformationViewModel</param>
        public void Update(ApplicationInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(obj);

                        context.application_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(ApplicationInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(obj);
                            context.application_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        { }

        #endregion
    }
}
