﻿using System;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class CustomerIncomeService : ICustomerIncomeService
    {
        public CustomerIncomeService()
        {
        }

        #region ApplicationInformationService Members
        /// <summary>
        /// Application Information ViewModel
        /// </summary>
        /// <param name="Id">int</param>
        public CustomerIncomeViewModel GetById(int? Id)
        {
            CustomerIncomeViewModel obj = new CustomerIncomeViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_wealth_demonstration.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_wealth_demonstration, CustomerIncomeViewModel>(data);
            return obj;
        }
        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public CustomerIncomeViewModel GetAll()
        {
            CustomerIncomeViewModel obj = new CustomerIncomeViewModel();
            return obj;
        }


        /// <summary>
        /// Create
        /// </summary>
        /// <param name="sc">ApplicationInformationViewModel</param>
        public void Create(CustomerIncomeViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_wealth_demonstration data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, al_wealth_demonstration>(sc);

                        context.al_wealth_demonstration.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj">ApplicationInformationViewModel</param>
        public void Update(CustomerIncomeViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, al_wealth_demonstration>(obj);

                        context.al_wealth_demonstration.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(CustomerIncomeViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerIncomeViewModel, al_wealth_demonstration>(obj);
                            context.al_wealth_demonstration.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        { }

        #endregion
    }
}
