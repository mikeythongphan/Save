﻿#region System
using System;
using System.Linq;
using System.Data.Entity;
#endregion

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
#endregion

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class LendingOperationService : ILendingOperationService
    {
        #region LendingOperationS
        private readonly ILendingOperationRepository _LendingOperationRepository;
        private readonly IDisbursementInformationRepository _DisbursementInformationRepository;
        private readonly IDisbursementRepository _DisbursementRepository;
        private readonly IInsuranceRepository _InsuranceRepository;
        private readonly IPersonalDetailRepository _PersonalDetailRepository;
        private readonly IPostDisbursementConditionRepository _PostDisbursementConditionRepository;
        #endregion

        #region MetaData
        private readonly IBranchCodeRepository _BranchCodeRepository;
        private readonly IBranchLocationRepository _BranchLocationRepository;
        private readonly ICustomerTypeRepository _CustomerTypeRepository;
        private readonly IFloatingInterestRateRepository _FloatingInterestRateRepository;
        private readonly ILoanPurposeRepository _LoanPurposeRepository;
        private readonly ILoanTenorRepository _LoanTenorRepository;
        private readonly IPaymentTypeRepository _PaymentTypeRepository;
        private readonly IProductTypeRepository _ProductTypeRepository;
        private readonly IProductRepository _ProductRepository;
        private readonly IProgramTypeRepository _ProgramTypeRepository;
        private readonly IPropertySaleRepository _PropertySaleRepository;
        private readonly IPropertyStatusRepository _PropertyStatusRepository;
        private readonly IPropertyTypeRepository _PropertyTypeRepository;
        private readonly ITradingAreaRepository _TradingAreaRepository;
        private readonly IIncomeTypeRepository _IncomeTypeRepository;
        private readonly ISalesChannelRepository _SalesChannelRepository;
        private readonly ICustomerSegmentRepository _CustomerSegmentRepository;
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;
        private readonly ICDDRepository _CDDRepository;
        private readonly ICICRepository _CICRepository;
        private readonly IReasonRepository _ReasonRepository;
        private readonly IStatusRepository _StatusRepository;
        private readonly ITypeRepository _TypeRepository;
        private readonly IBorrowerTypeRepository _BorrowerTypeRepository;
        private readonly IBankTypeRepository _BankTypeRepository;
        private readonly IBonusTypeRepository _BonusTypeRepository;
        private readonly IBusinessNatureRepository _BusinessNatureRepository;
        private readonly IBusinessTypeRepository _BusinessTypeRepository;
        private readonly ICityRepository _CityRepository;
        private readonly ICommisionTypeRepository _CommisionTypeRepository;
        private readonly ICompanyTypeRepository _CompanyTypeRepository;
        private readonly ICreditBureauTypeRepository _CreditBureauTypeRepository;
        private readonly ICreditDeviationRepository _CreditDeviationRepository;
        private readonly ICriteriaRepository _CriteriaRepository;
        private readonly ICurrentResidentTypeRepository _CurrentResidentTypeRepository;
        private readonly ICustodyTypeRepository _CustodyTypeRepository;
        private readonly IDeviationCodeRepository _DeviationCodeRepository;
        private readonly IDisbursalScenarioConditionRepository _DisbursalScenarioConditionRepository;
        private readonly IDisbursalScenarioRepository _DisbursalScenarioRepository;
        private readonly IDistrictRepository _DistrictRepository;
        private readonly IDuplicationTypeRepository _DuplicationTypeRepository;
        private readonly IEducationRepository _EducationRepository;
        private readonly IEmploymentTypeRepository _EmploymentTypeRepository;
        private readonly IIdentificationTypeRepository _IdentificationTypeRepository;
        private readonly IIndustryRepository _IndustryRepository;
        private readonly IInterestClassificationRepository _InterestClassificationRepository;
        private readonly IInvestigaveTypeRepository _InvestigaveTypeRepository;
        private readonly ILabourContractTypeRepository _LabourContractTypeRepository;
        private readonly ILoanTrendRepository _LoanTrendRepository;
        private readonly ILoanTypeRepository _LoanTypeRepository;
        private readonly IMaritalStatusRepository _MaritalStatusRepository;
        private readonly INationalityRepository _NationalityRepository;
        private readonly IOwnershipTypeRepository _OwnershipTypeRepository;
        private readonly IPaymentMethodRepository _PaymentMethodRepository;
        private readonly IPaymentOptionRepository _PaymentOptionRepository;
        private readonly IPositionRepository _PositionRepository;
        private readonly IProgramCodeRepository _ProgramCodeRepository;
        private readonly IResidenceOwnershipRepository _ResidenceOwnershipRepository;
        private readonly ICompanyCodeRepository _CompanyCodeRepository;
        private readonly IOccupationRepository _OccupationRepository;
        private readonly IDefinitionTypeRepository _DefinitionTypeRepository;
        #endregion

        private readonly IUnitOfWork _unitOfWork;

        #region Contructor
        public LendingOperationService(ILendingOperationRepository LendingOperationRepository,
            IDisbursementInformationRepository DisbursementInformationRepository,
            IDisbursementRepository DisbursementRepository,
            IInsuranceRepository InsuranceRepository,
            IPersonalDetailRepository PersonalDetailRepository,
            IPostDisbursementConditionRepository PostDisbursementConditionRepository,
            IBranchCodeRepository BranchCodeRepository,
            IBranchLocationRepository BranchLocationRepository,
            ICustomerTypeRepository CustomerTypeRepository,
            IFloatingInterestRateRepository FloatingInterestRateRepository,
            ILoanPurposeRepository LoanPurposeRepository,
            ILoanTenorRepository LoanTenorRepository,
            IPaymentTypeRepository PaymentTypeRepository,
            IProductTypeRepository ProductTypeRepository,
            IProductRepository ProductRepository,
            IProgramTypeRepository ProgramTypeRepository,
            IPropertySaleRepository PropertySaleRepository,
            IPropertyStatusRepository PropertyStatusRepository,
            IPropertyTypeRepository PropertyTypeRepository,
            ITradingAreaRepository TradingAreaRepository,
            IIncomeTypeRepository IncomeTypeRepository,
            ISalesChannelRepository SalesChannelRepository,
            ICustomerSegmentRepository CustomerSegmentRepository,
            ICustomerRelationshipRepository CustomerRelationshipRepository,
            ICDDRepository CDDRepository,
            ICICRepository CICRepository,
            IReasonRepository ReasonRepository,
            IStatusRepository StatusRepository,
            ITypeRepository TypeRepository,
            IBorrowerTypeRepository BorrowerTypeRepository,
            IBankTypeRepository BankTypeRepository,
            IBonusTypeRepository BonusTypeRepository,
            IBusinessNatureRepository BusinessNatureRepository,
            IBusinessTypeRepository BusinessTypeRepository,
            ICityRepository CityRepository,
            ICommisionTypeRepository CommisionTypeRepository,
            ICompanyTypeRepository CompanyTypeRepository,
            ICreditBureauTypeRepository CreditBureauTypeRepository,
            ICreditDeviationRepository CreditDeviationRepository,
            ICriteriaRepository CriteriaRepository,
            ICurrentResidentTypeRepository CurrentResidentTypeRepository,
            ICustodyTypeRepository CustodyTypeRepository,
            IDeviationCodeRepository DeviationCodeRepository,
            IDisbursalScenarioConditionRepository DisbursalScenarioConditionRepository,
            IDisbursalScenarioRepository DisbursalScenarioRepository,
            IDistrictRepository DistrictRepository,
            IDuplicationTypeRepository DuplicationTypeRepository,
            IEducationRepository EducationRepository,
            IEmploymentTypeRepository EmploymentTypeRepository,
            IIdentificationTypeRepository IdentificationTypeRepository,
            IIndustryRepository IndustryRepository,
            IInterestClassificationRepository InterestClassificationRepository,
            IInvestigaveTypeRepository InvestigaveTypeRepository,
            ILabourContractTypeRepository LabourContractTypeRepository,
            ILoanTrendRepository LoanTrendRepository,
            ILoanTypeRepository LoanTypeRepository,
            IMaritalStatusRepository MaritalStatusRepository,
            INationalityRepository NationalityRepository,
            IOwnershipTypeRepository OwnershipTypeRepository,
            IPaymentMethodRepository PaymentMethodRepository,
            IPaymentOptionRepository PaymentOptionRepository,
            IPositionRepository PositionRepository,
            IProgramCodeRepository ProgramCodeRepository,
            IResidenceOwnershipRepository ResidenceOwnershipRepository,
            ICompanyCodeRepository CompanyCodeRepository,
            IOccupationRepository OccupationRepository,
            IDefinitionTypeRepository DefinitionTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._LendingOperationRepository = LendingOperationRepository;
            this._DisbursementInformationRepository = DisbursementInformationRepository;
            this._DisbursementRepository = DisbursementRepository;
            this._InsuranceRepository = InsuranceRepository;
            this._PersonalDetailRepository = PersonalDetailRepository;
            this._PostDisbursementConditionRepository = PostDisbursementConditionRepository;
            this._BranchCodeRepository = BranchCodeRepository;
            this._BranchLocationRepository = BranchLocationRepository;
            this._CustomerTypeRepository = CustomerTypeRepository;
            this._FloatingInterestRateRepository = FloatingInterestRateRepository;
            this._LoanPurposeRepository = LoanPurposeRepository;
            this._LoanTenorRepository = LoanTenorRepository;
            this._PaymentTypeRepository = PaymentTypeRepository;
            this._ProductTypeRepository = ProductTypeRepository;
            this._ProductRepository = ProductRepository;
            this._ProgramTypeRepository = ProgramTypeRepository;
            this._PropertySaleRepository = PropertySaleRepository;
            this._PropertyStatusRepository = PropertyStatusRepository;
            this._PropertyTypeRepository = PropertyTypeRepository;
            this._TradingAreaRepository = TradingAreaRepository;
            this._IncomeTypeRepository = IncomeTypeRepository;
            this._SalesChannelRepository = SalesChannelRepository;
            this._CustomerSegmentRepository = CustomerSegmentRepository;
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._CDDRepository = CDDRepository;
            this._CICRepository = CICRepository;
            this._ReasonRepository = ReasonRepository;
            this._StatusRepository = StatusRepository;
            this._TypeRepository = TypeRepository;
            this._BorrowerTypeRepository = BorrowerTypeRepository;
            this._BankTypeRepository = BankTypeRepository;
            this._BonusTypeRepository = BonusTypeRepository;
            this._BusinessNatureRepository = BusinessNatureRepository;
            this._BusinessTypeRepository = BusinessTypeRepository;
            this._CityRepository = CityRepository;
            this._CommisionTypeRepository = CommisionTypeRepository;
            this._CompanyTypeRepository = CompanyTypeRepository;
            this._CreditBureauTypeRepository = CreditBureauTypeRepository;
            this._CreditDeviationRepository = CreditDeviationRepository;
            this._CriteriaRepository = CriteriaRepository;
            this._CurrentResidentTypeRepository = CurrentResidentTypeRepository;
            this._CustodyTypeRepository = CustodyTypeRepository;
            this._DeviationCodeRepository = DeviationCodeRepository;
            this._DisbursalScenarioConditionRepository = DisbursalScenarioConditionRepository;
            this._DisbursalScenarioRepository = DisbursalScenarioRepository;
            this._DistrictRepository = DistrictRepository;
            this._DuplicationTypeRepository = DuplicationTypeRepository;
            this._EducationRepository = EducationRepository;
            this._EmploymentTypeRepository = EmploymentTypeRepository;
            this._IdentificationTypeRepository = IdentificationTypeRepository;
            this._IndustryRepository = IndustryRepository;
            this._InterestClassificationRepository = InterestClassificationRepository;
            this._InvestigaveTypeRepository = InvestigaveTypeRepository;
            this._LabourContractTypeRepository = LabourContractTypeRepository;
            this._LoanTrendRepository = LoanTrendRepository;
            this._LoanTypeRepository = LoanTypeRepository;
            this._MaritalStatusRepository = MaritalStatusRepository;
            this._NationalityRepository = NationalityRepository;
            this._OwnershipTypeRepository = OwnershipTypeRepository;
            this._PaymentMethodRepository = PaymentMethodRepository;
            this._PaymentOptionRepository = PaymentOptionRepository;
            this._PositionRepository = PositionRepository;
            this._ProgramCodeRepository = ProgramCodeRepository;
            this._ResidenceOwnershipRepository = ResidenceOwnershipRepository;
            this._CompanyCodeRepository = CompanyCodeRepository;
            this._OccupationRepository = OccupationRepository;
            this._DefinitionTypeRepository = DefinitionTypeRepository;
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region Implement

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel LoadIndex(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            #region ConfigControl
            objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            #endregion

            #region MetaData
            objParam = LoadMetaData(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            #endregion

            return _LendingOperationRepository.LoadIndex(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel Save(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.Save(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel Submit(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.Submit(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// SendBackSC
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel SendBackSC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.SendBackSC(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// LOModifySC
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel LOModifySC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.LOModifySC(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// LOModify
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel LOModify(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.LOModify(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// PrintApprovalLetter
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel PrintApprovalLetter(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.PrintApprovalLetter(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// PrintApprovalWorksheet
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel PrintApprovalWorksheet(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return _LendingOperationRepository.PrintApprovalWorksheet(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Visible Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel VisibleControl(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "LOMaker":
                    {
                        #region LOMaker

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsVisibleCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsVisibleLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsVisibleApplicationNo = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementViewModel.IsVisibleARMCode = true;
                        objParam._DisbursementViewModel.IsVisibleChannel = true;
                        objParam._DisbursementViewModel.IsVisibleCustomerSegment = true;
                        objParam._DisbursementViewModel.IsVisibleExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsVisibleProgramCode = true;
                        objParam._DisbursementViewModel.IsVisibleReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsVisibleApplicationStatus = true;
                        objParam._InsuranceViewModel.IsVisibleApplicationType = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail
                       
                        objParam._PersonalDetailViewModel.IsVisibleApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsVisibleApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsVisiblePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOChecker":
                    {
                        #region LOChecker

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsVisibleCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsVisibleLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsVisibleApplicationNo = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementViewModel.IsVisibleARMCode = true;
                        objParam._DisbursementViewModel.IsVisibleChannel = true;
                        objParam._DisbursementViewModel.IsVisibleCustomerSegment = true;
                        objParam._DisbursementViewModel.IsVisibleExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsVisibleProgramCode = true;
                        objParam._DisbursementViewModel.IsVisibleReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsVisibleApplicationStatus = true;
                        objParam._InsuranceViewModel.IsVisibleApplicationType = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsVisibleApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsVisibleApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsVisiblePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOMaster":
                    {
                        #region LOMaster

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsVisibleCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsVisibleLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsVisibleApplicationNo = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementViewModel.IsVisibleARMCode = true;
                        objParam._DisbursementViewModel.IsVisibleChannel = true;
                        objParam._DisbursementViewModel.IsVisibleCustomerSegment = true;
                        objParam._DisbursementViewModel.IsVisibleExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsVisibleProgramCode = true;
                        objParam._DisbursementViewModel.IsVisibleReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsVisibleApplicationStatus = true;
                        objParam._InsuranceViewModel.IsVisibleApplicationType = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsVisibleApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsVisibleApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsVisiblePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOViewer":
                    {
                        #region LOViewer

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsVisibleCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsVisibleDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsVisibleLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsVisibleApplicationNo = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationStatus = true;
                        objParam._DisbursementViewModel.IsVisibleApplicationType = true;
                        objParam._DisbursementViewModel.IsVisibleARMCode = true;
                        objParam._DisbursementViewModel.IsVisibleChannel = true;
                        objParam._DisbursementViewModel.IsVisibleCustomerSegment = true;
                        objParam._DisbursementViewModel.IsVisibleExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsVisibleProgramCode = true;
                        objParam._DisbursementViewModel.IsVisibleReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsVisibleApplicationStatus = true;
                        objParam._InsuranceViewModel.IsVisibleApplicationType = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsVisibleInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsVisibleApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsVisibleApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsVisibleWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsVisibleWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsVisibleApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsVisiblePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// Readonly Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel ReadonlyControl(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "LOMaker":
                    {
                        #region LOMaker

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsDisableCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsDisableLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsDisableApplicationNo = true;
                        objParam._DisbursementViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementViewModel.IsDisableARMCode = true;
                        objParam._DisbursementViewModel.IsDisableChannel = true;
                        objParam._DisbursementViewModel.IsDisableCustomerSegment = true;
                        objParam._DisbursementViewModel.IsDisableExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsDisableProgramCode = true;
                        objParam._DisbursementViewModel.IsDisableReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsDisableApplicationStatus = true;
                        objParam._InsuranceViewModel.IsDisableApplicationType = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsDisableApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsDisableApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsDisablePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOChecker":
                    {
                        #region LOChecker

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsDisableCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsDisableLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsDisableApplicationNo = true;
                        objParam._DisbursementViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementViewModel.IsDisableARMCode = true;
                        objParam._DisbursementViewModel.IsDisableChannel = true;
                        objParam._DisbursementViewModel.IsDisableCustomerSegment = true;
                        objParam._DisbursementViewModel.IsDisableExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsDisableProgramCode = true;
                        objParam._DisbursementViewModel.IsDisableReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsDisableApplicationStatus = true;
                        objParam._InsuranceViewModel.IsDisableApplicationType = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsDisableApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsDisableApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsDisablePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOMaster":
                    {
                        #region LOMaster

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsDisableCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsDisableLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsDisableApplicationNo = true;
                        objParam._DisbursementViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementViewModel.IsDisableARMCode = true;
                        objParam._DisbursementViewModel.IsDisableChannel = true;
                        objParam._DisbursementViewModel.IsDisableCustomerSegment = true;
                        objParam._DisbursementViewModel.IsDisableExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsDisableProgramCode = true;
                        objParam._DisbursementViewModel.IsDisableReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsDisableApplicationStatus = true;
                        objParam._InsuranceViewModel.IsDisableApplicationType = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsDisableApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsDisableApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsDisablePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                case "LOViewer":
                    {
                        #region LOViewer

                        #region DisbursementInformation
                        objParam._DisbursementInformationViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementInformationViewModel.IsDisableCustomerRelationship = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursalStatus = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedAmount = true;
                        objParam._DisbursementInformationViewModel.IsDisableDisbursedDate = true;
                        objParam._DisbursementInformationViewModel.IsDisableLoanAccountNumber = true;
                        #endregion

                        #region Disbursement
                        objParam._DisbursementViewModel.IsDisableApplicationNo = true;
                        objParam._DisbursementViewModel.IsDisableApplicationStatus = true;
                        objParam._DisbursementViewModel.IsDisableApplicationType = true;
                        objParam._DisbursementViewModel.IsDisableARMCode = true;
                        objParam._DisbursementViewModel.IsDisableChannel = true;
                        objParam._DisbursementViewModel.IsDisableCustomerSegment = true;
                        objParam._DisbursementViewModel.IsDisableExpectingDisbursedDate = true;
                        objParam._DisbursementViewModel.IsDisableProgramCode = true;
                        objParam._DisbursementViewModel.IsDisableReceivingDate = true;
                        #endregion

                        #region Insurance
                        objParam._InsuranceViewModel.IsDisableApplicationStatus = true;
                        objParam._InsuranceViewModel.IsDisableApplicationType = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceAmount = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceCompanyName = true;
                        objParam._InsuranceViewModel.IsDisableInsuranceExpiryDate = true;
                        #endregion

                        #region PersonalDetail

                        objParam._PersonalDetailViewModel.IsDisableApplicationStatus = true;
                        objParam._PersonalDetailViewModel.IsDisableApplicationType = true;

                        #region MainBorrower
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Main.IsDisableWard = true;
                        #endregion

                        #region CoBorrower1
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co1.IsDisableWard = true;
                        #endregion

                        #region CoBorrower2
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co2.IsDisableWard = true;
                        #endregion

                        #region CoBorrower3
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableCurrentHomeAddress = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDistrict = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableDOB = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableFullName = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableGender = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableInitital = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableMobileNo = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableNationlity = true;
                        objParam._PersonalDetailViewModel._PersonalInformationViewModel_Co3.IsDisableWard = true;
                        #endregion

                        #endregion

                        #region 
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationStatus = true;
                        objParam._PostDisbursementConditionViewModel.IsDisableApplicationType = true;
                        objParam._PostDisbursementConditionViewModel.IsDisablePostDisbursementConditionExpiryDate = true;
                        #endregion

                        #endregion

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// LoadMetaData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public LendingOperationViewModel LoadMetaData(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._M_BranchCodeViewModel = _BranchCodeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_BranchLocationViewModel = _BranchLocationRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentTypeViewModel = _PaymentTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_ProductViewModel = _ProductRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_ProgramTypeViewModel = _ProgramTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PropertySaleViewModel = _PropertySaleRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyStatusViewModel = _PropertyStatusRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyTypeViewModel = _PropertyTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_TradingAreaViewModel = _TradingAreaRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_StatusViewModel = _StatusRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_TypeViewModel = _TypeRepository.GetListActiveById(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_SalesChannelViewModel = _SalesChannelRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_ReasonViewModel = _ReasonRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CDDViewModel = _CDDRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_BorrowerTypeViewModel = _BorrowerTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_BusinessNatureViewModel = _BusinessNatureRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_BusinessTypeViewModel = _BusinessTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CompanyCodeViewModel = _CompanyCodeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CompanyTypeViewModel = _CompanyTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CreditBureauTypeViewModel = _CreditBureauTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CreditDeviationViewModel = _CreditDeviationRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerRelationshipViewModel = _CustomerRelationshipRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_EmploymentTypeViewModel = _EmploymentTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_IncomeTypeViewModel = _IncomeTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_IndustryViewModel = _IndustryRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_LabourContractTypeViewModel = _LabourContractTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_OccupationViewModel = _OccupationRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentMethodViewModel = _PaymentMethodRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_CarRepaymentCycle = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_HouseRepaymentCycle = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PeriodOfSubmittedBSViewModel = _DefinitionTypeRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_PositionViewModel = _PositionRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);
            objParam._M_DistrictViewModel = _DistrictRepository.GetListActiveByTypeId(objParam._DisbursementInformationViewModel.ApplicationTypeID);

            return objParam;
        }

        #endregion
    }
}
