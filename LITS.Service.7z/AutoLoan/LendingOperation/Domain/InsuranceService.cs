﻿using System;
using System.Data.Entity;
using System.Linq;

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.Domain.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
#endregion

#region Core
using LITS.Core.Resources;
#endregion

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class InsuranceService : IInsuranceService
    {
        private readonly IInsuranceRepository _InsuranceRepository;
        private readonly IUnitOfWork _unitOfWork;

        #region Contructor
        public InsuranceService(IInsuranceRepository InsuranceRepository,            
            IUnitOfWork unitOfWork)
        {
            this._InsuranceRepository = InsuranceRepository;            
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region Implement
        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public InsuranceViewModel LoadIndex(InsuranceViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {            
            return _InsuranceRepository.LoadIndex(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public InsuranceViewModel Save(InsuranceViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = _InsuranceRepository.Save(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            _unitOfWork.Commit();

            return objParam;
        }

        #endregion
    }
}
