﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using AutoMapper;

#region Infrastructure
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
#endregion

#region Interface
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Interface.Service.Main.WorkInProgress;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
#endregion

#region Model
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;
#endregion

namespace LITS.Service.Main.WorkInProgress
{
    public class WorkInProgressService : IWorkInProgressService
    {
        #region WorkInProgress
        private readonly IWorkInProgressMasterRepository _WorkInProgressMasterRepository;
        private readonly IWorkInProgressDetailRepository _WorkInProgressDetailRepository;
        private readonly IWorkInProgressTreeRepository _WorkInProgressTreeRepository;
        private readonly IWorkInProgressRepository _WorkInProgressRepository;
        #endregion

        #region MetaData
        private readonly IStatusRepository _StatusRepository;
        private readonly ITypeRepository _TypeRepository;
        #endregion

        private readonly IUnitOfWork _unitOfWork;

        #region Contructor
        public WorkInProgressService(IWorkInProgressMasterRepository workInProgressMasterRepository,
            IWorkInProgressDetailRepository workInProgressDetailRepository,
            IWorkInProgressTreeRepository workInProgressTreeRepository,
            IWorkInProgressRepository workInProgressRepository,
            IStatusRepository StatusRepository,
            ITypeRepository TypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._WorkInProgressDetailRepository = workInProgressDetailRepository;
            this._WorkInProgressMasterRepository = workInProgressMasterRepository;
            this._WorkInProgressTreeRepository = workInProgressTreeRepository;
            this._WorkInProgressRepository = workInProgressRepository;
            this._StatusRepository = StatusRepository;
            this._TypeRepository = TypeRepository;
            this._unitOfWork = unitOfWork;            
        }
        #endregion

        #region Implement

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadIndex(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = await VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = await ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = await LoadMetaData(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            objParam = await _WorkInProgressTreeRepository.GetListTreeProductIsActive(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = await _WorkInProgressMasterRepository.GetListCustomerLargeDatabase(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = await _WorkInProgressMasterRepository.GetListCompanyLargeDatabase(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            return objParam;
        }

        /// <summary>
        /// SearchData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> SearchData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {            
           return await _WorkInProgressRepository.SearchData(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);            
        }

        /// <summary>
        /// LoadChildDetail
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {            
            return await _WorkInProgressDetailRepository.LoadChildDetail(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);            
        }

        /// <summary>
        /// Visible Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> VisibleControl(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "WorkInProgressMaker":
                    {
                        #region WorkInProgressMaker
                        objParam.IsVisibleWorkInProgressDetail = true;
                        objParam.IsVisibleWorkInProgressDetailChild = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleApplicationNo = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCompanyName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCustomerName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleFromDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleStatus = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleToDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCompany = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCustomer = true;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressChecker":
                    {
                        #region WorkInProgressChecker
                        objParam.IsVisibleWorkInProgressDetail = true;
                        objParam.IsVisibleWorkInProgressDetailChild = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleApplicationNo = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCompanyName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCustomerName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleFromDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleStatus = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleToDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCompany = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCustomer = true;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressMaster":
                    {
                        #region WorkInProgressMaster
                        objParam.IsVisibleWorkInProgressDetail = true;
                        objParam.IsVisibleWorkInProgressDetailChild = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleApplicationNo = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCompanyName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCustomerName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleFromDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleStatus = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleToDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCompany = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCustomer = true;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressViewer":
                    {
                        #region WorkInProgressViewer
                        objParam.IsVisibleWorkInProgressDetail = true;
                        objParam.IsVisibleWorkInProgressDetailChild = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleApplicationNo = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCompanyName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleCustomerName = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleFromDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleStatus = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleToDate = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCompany = true;
                        objParam._WorkInProgressMasterViewModel.IsVisibleWorkInProgressMasterCustomer = true;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                default:
                    {
                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// Readonly Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> ReadonlyControl(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "WorkInProgressMaker":
                    {
                        #region WorkInProgressMaker
                        objParam.IsDisableWorkInProgressDetail = false;
                        objParam.IsDisableWorkInProgressDetailChild = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableApplicationNo = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCompanyName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCustomerName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableFromDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableStatus = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableToDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCompany = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCustomer = false;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressChecker":
                    {
                        #region WorkInProgressChecker
                        objParam.IsDisableWorkInProgressDetail = false;
                        objParam.IsDisableWorkInProgressDetailChild = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableApplicationNo = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCompanyName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCustomerName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableFromDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableStatus = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableToDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCompany = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCustomer = false;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressMaster":
                    {
                        #region WorkInProgressMaster
                        objParam.IsDisableWorkInProgressDetail = false;
                        objParam.IsDisableWorkInProgressDetailChild = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableApplicationNo = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCompanyName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCustomerName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableFromDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableStatus = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableToDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCompany = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCustomer = false;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                case "WorkInProgressViewer":
                    {
                        #region WorkInProgressViewer
                        objParam.IsDisableWorkInProgressDetail = false;
                        objParam.IsDisableWorkInProgressDetailChild = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableApplicationNo = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCompanyName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableCustomerName = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableFromDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableStatus = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableToDate = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCompany = false;
                        objParam._WorkInProgressMasterViewModel.IsDisableWorkInProgressMasterCustomer = false;
                        #endregion

                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
                default:
                    {
                        await System.Threading.Tasks.Task.WhenAll();

                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// LoadMetaData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadMetaData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam.lstStatusViewModel = _StatusRepository.GetListActiveAll();
            objParam.lstTypeViewModel = _TypeRepository.GetListActiveAll();

            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }
        #endregion
    }
}
