﻿using System;
using LITS.Interface.Service.Main.ReportsChart;
using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Service.Main.ReportsChart
{
    public class ReportsChartDetailService : IReportsChartDetailService
    {


        public ReportsChartDetailService()
        {

        }

        public void Create(ReportsChartDetailViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? Id)
        {
            throw new NotImplementedException();
        }

        public ReportsChartDetailViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public ReportsChartDetailViewModel GetById(int? Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
