﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using AutoMapper;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Data.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.Main.SalesCoordinators;

namespace LITS.Service.Main.SalesCoordinators
{
    public class ApplicationInformationService : IApplicationInformationService
    {
        private readonly ICustomerInformationRepository _applicationInformationRepository;
        
        private readonly IUnitOfWork _unitOfWork;

        public ApplicationInformationService(ICustomerInformationRepository applicationInformationRepository,            
            IUnitOfWork unitOfWork)
        {
            this._applicationInformationRepository = applicationInformationRepository;            
            this._unitOfWork = unitOfWork;
        }

        #region ApplicationInformationService Members

        public ApplicationInformationViewModel GetById(int? Id)
        {
            ApplicationInformationViewModel obj = new ApplicationInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var applicationInfo = entities.application_information.FirstOrDefault(p => p.pk_id == Id);

            //obj = new ApplicationInformationViewModel()
            //{
            //    ArmCode = applicationInfo.arm_code,
            //    ReceivedDate = applicationInfo.received_date,
            //    SaleStaffBankID = applicationInfo.sale_staff_bank_id,
            //    SaleStaffName = applicationInfo.sale_staff_name
            //};

            //obj = Mapper.Map<ApplicationInformationViewModel, application_information>(ApplicationInformationViewModel);

            return obj;
        }

        public ApplicationInformationViewModel GetAll()
        {           
            ApplicationInformationViewModel obj = new ApplicationInformationViewModel();
            return obj;
        }

        public application_information GetApplicationInformation(int? Id)
        {
            application_information obj = new application_information();

            return obj;
        }

        public void Create(ApplicationInformationViewModel sc)
        { }

        public void Delete(int? Id)
        { }

        public void Save()
        { }

        #endregion
    }
}
