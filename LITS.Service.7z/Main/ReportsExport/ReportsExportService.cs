﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.ReportsExport;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Service.Main.ReportsExport
{
    public class ReportsExportService : IReportsExportService
    {
        private readonly IReportsExportMasterRepository _ReportsExportMasterRepository;
        private readonly IReportsExportDetailRepository _ReportsExportDetailRepository;
        private readonly IReportsExportTreeRepository _ReportsExportTreeRepository;
        private readonly IReportsExportRepository _ReportsExportRepository;
        private LITSEntities _LITSEntities;

        private readonly IUnitOfWork _unitOfWork;

        public ReportsExportService(IReportsExportMasterRepository ReportsExportMasterRepository,
            IReportsExportDetailRepository ReportsExportDetailRepository,
            IReportsExportTreeRepository ReportsExportTreeRepository,
            IReportsExportRepository ReportsExportRepository,
            IUnitOfWork unitOfWork,
            LITSEntities litsEntities)
        {
            this._ReportsExportDetailRepository = ReportsExportDetailRepository;
            this._ReportsExportMasterRepository = ReportsExportMasterRepository;
            this._ReportsExportTreeRepository = ReportsExportTreeRepository;
            this._ReportsExportRepository = ReportsExportRepository;
            this._unitOfWork = unitOfWork;
            this._LITSEntities = litsEntities;
        }
        public ReportsExportViewModel LoadIndex()
        {
            ReportsExportViewModel obj = new ReportsExportViewModel();

            obj._ReportsExportTreeViewModel = _ReportsExportTreeRepository.GetListTreeProductIsActive();
            obj._ReportsExportMasterViewModel._ReportsExportMasterCustomerViewModel = _ReportsExportMasterRepository.GetListCustomerLargeDatabase();
            obj._ReportsExportMasterViewModel._ReportsExportMasterCompanyViewModel = _ReportsExportMasterRepository.GetListCompanyLargeDatabase();

            return obj;
        }
    }
}
