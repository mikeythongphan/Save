﻿using System;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Service.Main.ReportsExport
{
    public class ReportsExportMasterService : IReportsExportMasterService
    {
        public ReportsExportMasterService()
        {

        }

        public void Create(ReportsExportMasterViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? Id)
        {
            throw new NotImplementedException();
        }

        public ReportsExportMasterViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public ReportsExportMasterViewModel GetById(int? Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
