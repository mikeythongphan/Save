﻿using System;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Service.Main.ReportsExport
{
    public class ReportsExportDetailService : IReportsExportDetailService
    {


        public ReportsExportDetailService()
        {

        }

        public void Create(ReportsExportDetailViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? Id)
        {
            throw new NotImplementedException();
        }

        public ReportsExportDetailViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public ReportsExportDetailViewModel GetById(int? Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
