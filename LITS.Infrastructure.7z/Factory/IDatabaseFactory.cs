﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;

namespace LITS.Infrastructure.Factory
{
    public interface IDatabaseFactory : IDisposable
    {
        LITSEntities Get();
    }
}
