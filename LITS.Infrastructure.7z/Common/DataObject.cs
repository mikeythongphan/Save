﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using Microsoft.ApplicationBlocks.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace LITS.Infrastructure.Common
{
    public class DataObject
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceString"></param>
        /// <returns></returns>
        public static string EscapeString(string sourceString)
        {
            if (string.IsNullOrEmpty(sourceString))
                return null;
            return sourceString.Trim()
            .Replace(@"/", @"//")
            .Replace("'", "''")
            .Replace("%", @"/%")
            .Replace("[", @"/[");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string BuildFullIndexSearchString(string str)
        {
            if (str == null)
                return str;
            // make string standard "a b c d"
            str = str.Trim();
            while (str.IndexOf("  ") >= 0) str = str.Replace("  ", " ");

            // escape " by ""
            str = str.Replace("\"", "\"\"")
                    // replace [space] by [" AND "]
                    .Replace(" ", "\" AND \"")
                    // replace ' by ''
                    .Replace("'", "''");

            if (str != string.Empty)
                //wrap string by " "
                return string.Format("\"{0}\"", str);

            return str;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool CheckColumnData(IDataReader reader, string name)
        {

            int ordinal = GetOrdinal(reader, name);
            if (ordinal >= 0 && !reader.IsDBNull(ordinal))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static int GetOrdinal(IDataReader reader, string name)
        {
            try
            {
                return reader.GetOrdinal(name);
            }
            catch (IndexOutOfRangeException)
            {
                return -1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanType"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public static int GetApplicationNextAppNo(string loanType, int year)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                DbCommand dbCommand = database.GetStoredProcCommand("_spApplicationGetNextAppNo");

                SqlParameter sqlParaLoanType = new SqlParameter();
                sqlParaLoanType.ParameterName = "@loanType";
                sqlParaLoanType.SqlDbType = SqlDbType.NVarChar;
                sqlParaLoanType.Direction = ParameterDirection.Input;

                SqlParameter sqlParaYear = new SqlParameter();
                sqlParaYear.ParameterName = "@loanType";
                sqlParaYear.SqlDbType = SqlDbType.Int;
                sqlParaYear.Direction = ParameterDirection.Input;

                database.AddInParameter(dbCommand, "@loanType", DbType.AnsiString, loanType);
                database.AddInParameter(dbCommand, "@year", DbType.Int32, year);

                DataSet ds = SqlHelper.ExecuteDataset(database.ConnectionStringWithoutCredentials,
                    CommandType.StoredProcedure, "_spApplicationGetNextAppNo");

                int appNo = 0;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Int32.TryParse(ds.Tables[0].Rows[0][0].ToString(), out appNo);
                }
                return appNo;
            }
            catch (Exception ex)
            {
                // log this exception
                return 0;
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="minTime"></param>
        /// <param name="maxTime"></param>
        /// <returns></returns>
        public static int GetMinuteBetweenTime(DateTime minTime, DateTime maxTime)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                DbCommand dbCommand = database.GetStoredProcCommand("_fGetMinuteBetweenTime");

                database.AddInParameter(dbCommand, "@minTime", DbType.DateTime, minTime);
                database.AddInParameter(dbCommand, "@maxTime", DbType.DateTime, maxTime);
                database.AddOutParameter(dbCommand, "@minute", DbType.Int32, 0);

                //DataAccessHelper.ExecuteNonQuery(database, dbCommand);
                return (int)database.GetParameterValue(dbCommand, "@minute");
            }
            catch (Exception ex)
            {
                // log this exception
                return 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public static int GetBusinessDays(DateTime startDate, DateTime endDate)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                DbCommand dbCommand = database.GetStoredProcCommand("_GetBusinessDays");

                database.AddInParameter(dbCommand, "@startdate", DbType.DateTime, startDate);
                database.AddInParameter(dbCommand, "@enddate", DbType.DateTime, endDate);
                database.AddOutParameter(dbCommand, "@days", DbType.Int32, 0);

                //DataAccessHelper.ExecuteNonQuery(database, dbCommand);
                return (int)database.GetParameterValue(dbCommand, "@days");
            }
            catch (Exception ex)
            {
                // log this exception
                return 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public static int GetDaysInHolidays(DateTime startDate, DateTime endDate)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                DbCommand dbCommand = database.GetStoredProcCommand("_GetDaysInHolidays");

                database.AddInParameter(dbCommand, "@startdate", DbType.DateTime, startDate);
                database.AddInParameter(dbCommand, "@enddate", DbType.DateTime, endDate);
                database.AddOutParameter(dbCommand, "@days", DbType.Int32, 0);

                //DataAccessHelper.ExecuteNonQuery(database, dbCommand);
                return (int)database.GetParameterValue(dbCommand, "@days");
            }
            catch (Exception ex)
            {
                // log this exception
                return 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public static DataSet GetDataByTable(string tableName)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                string query = "select * from " + tableName + " order by ID desc";
                DbCommand dbCommand = database.GetSqlStringCommand(query);

                DataSet ds = null;
                //DataAccessHelper.ExecuteDataSet(database, dbCommand);
                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static DataSet GetDataByTableAndType(string tableName, string type)
        {
            try
            {
                Database database = MyDatabaseFactory.CreateDatabase();
                string query = "select * from " + tableName + " where Type = '" + type + "' order by ID desc";
                DbCommand dbCommand = database.GetSqlStringCommand(query);

                DataSet ds = null;
                //DataAccessHelper.ExecuteDataSet(database, dbCommand);
                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string RemoveSpecialCharacters(string input)
        {
            string result = null;
            try
            {
                if (!string.IsNullOrEmpty(input))
                    result = input.Replace("'", "").Replace('"', ' ');
            }
            catch (Exception ex)
            {
            }
            return result;
        }

        /// <summary>
        /// If value NULL Or "" then return DBNull.Value. for not error when call store procedure 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static object ChangeDataType(string value)
        {
            if (string.IsNullOrEmpty(value))
                return DBNull.Value;
            return value;
        }

        public static object ChangeDataType(int? value)
        {
            if (!value.HasValue)
                return DBNull.Value;
            return value;
        }

        public static object ChangeDataType(decimal? value)
        {
            if (!value.HasValue)
                return DBNull.Value;
            return value;
        }

        public static object ChangeDataType(DateTime? value)
        {
            if (!value.HasValue)
                return DBNull.Value;
            return value;
        }

        public static object ChangeDataType(bool? value)
        {
            if (!value.HasValue)
                return DBNull.Value;
            return value;
        }


    }
}
