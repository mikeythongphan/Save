﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Infrastructure.Common
{
    public static class ViewUtil
    {
        public static string ConvertBoolToText(bool? Value)
        {
            try
            {
                return (Value.Value) ? "Yes" : "No";
            }
            catch (Exception ex)
            {
                return "No";
            }
        }







    }
}
