﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.DirectoryServices;
using System.Data;
using System.Net;
using System.IO;
using Aspose.Cells;
using Aspose.Words;
using System.Data.SqlTypes;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Drawing;

namespace LITS.Infrastructure.Common
{
    public static class Utilities
    {
        public static int IndexMUE = int.Parse(ConfigurationManager.AppSettings["CapMUEForIncome"].ToString());        
        public static string BeingFraudCase = "This customer was being in the FRAUD list with the investigation status: {0}";
        public static string SplitDisbursementCondition = "@@@";        

        #region LO Re-ModifySC / CI Modify data SC

        #region CharactersSplitRemodify

        public static string split = "<![@]>";
        public static string splitAppStart = "<![STARTAPP]>";
        public static string splitAppEnd = "<![ENDAPP]>";

        #region PL

        public static string splitCustomer = "<![PLCUST]>";
        public static string splitIncome = "<![PLINCOME]>";
        public static string splitFinance = "<![PLFINANCE]>";
        public static string splitDetails = "<![PLASSETANDDETAIL]>";
        public static string splitRelative = "<![PLRELATIVE]>";
        public static string splitCustomerNews = "<![PLCUSTNEWS]>";
        public static string splitCreditLife = "<![PLCLIFE]>";

        #endregion

        #region ML

        public static string splitCustMB = "<![CUSTMB]>";
        public static string splitCustCB1 = "<![CUSTCB1]>";
        public static string splitCustCB2 = "<![CUSTCB2]>";
        public static string splitCustCB3 = "<![CUSTCB3]>";
        public static string splitCustIncomeSalaried = "<![CUSTINCOMESALARIED]>";
        public static string splitCustIncomeHouse = "<![CUSTINCOMEHOUSE]>";
        public static string splitCustIncomeCar = "<![CUSTINCOMECAR]>";
        public static string splitCustIncomePrivate = "<![CUSTINCOMEPRIVATE]>";
        // CB1
        public static string splitCustIncomeSalariedCB1 = "<![CUSTINCOMESALARIEDCB1]>";
        public static string splitCustIncomeHouseCB1 = "<![CUSTINCOMEHOUSECB1]>";
        public static string splitCustIncomeCarCB1 = "<![CUSTINCOMECARCB1]>";
        public static string splitCustIncomePrivateCB1 = "<![CUSTINCOMEPRIVATECB1]>";
        // CB2
        public static string splitCustIncomeSalariedCB2 = "<![CUSTINCOMESALARIEDCB2]>";
        public static string splitCustIncomeHouseCB2 = "<![CUSTINCOMEHOUSECB2]>";
        public static string splitCustIncomeCarCB2 = "<![CUSTINCOMECARCB2]>";
        public static string splitCustIncomePrivateCB2 = "<![CUSTINCOMEPRIVATECB2]>";

        public static string splitProperty1 = "<![PROPERTY1]>";
        public static string splitProperty2 = "<![PROPERTY2]>";
        public static string splitProperty3 = "<![PROPERTY3]>";
        public static string splitProperty4 = "<![PROPERTY4]>";
        public static string splitProperty5 = "<![PROPERTY5]>";
        public static string splitCollateral1 = "<![COLLATERAL1]>";
        public static string splitCollateral2 = "<![COLLATERAL2]>";
        public static string splitCollateral3 = "<![COLLATERAL3]>";
        public static string splitAppliedLoan = "<![APPLIED]>";
        public static string splitMRTA = "<![MRTA]>";

        // NEWS 
        public static string splitCustMBNews = "<![CUSTMBNEWS]>";
        public static string splitCustCB1News = "<![CUSTCB1NEWS]>";
        public static string splitCustCB2News = "<![CUSTCB2NEWS]>";
        public static string splitCustCB3News = "<![CUSTCB3NEWS]>";

        #endregion

        #endregion

        public static string[] GetValuesInString(string inputValue, int idxStart, int idxEnd, int lengthValueStart)
        {
            idxStart = (idxStart + lengthValueStart);
            int length = (idxEnd - idxStart);
            string value = inputValue.Substring(idxStart, length);

            string[] strSplit = new string[] { split };
            string[] array = value.Split(strSplit, StringSplitOptions.None);

            return array;
        }

        #region LO Re-ModifySC

        // PL Application
        public static void LoadPLApplicationLORemodifySC(string value, ref string[] infoApp, ref string[] infoCust, ref string[] infoCustIncome,
                                                                     ref string[] infoFinance, ref string[] infoDetails, ref string[] infoRelative, ref string[] infoCustNews)
        {
            if (value != null)
            {
                int idxCust = value.IndexOf(splitCustomer);
                int idxIncome = value.IndexOf(splitIncome);
                int idxFinance = value.IndexOf(splitFinance);
                int idxDetails = value.IndexOf(splitDetails);
                int idxRelative = value.IndexOf(splitRelative);
                int idxCustNews = value.IndexOf(splitCustomerNews);
                int idxEnd = value.IndexOf(splitAppEnd);

                infoApp = GetValuesInString(value, 0, idxCust, splitAppStart.Length);
                infoCust = GetValuesInString(value, idxCust, idxIncome, splitCustomer.Length);
                infoCustIncome = GetValuesInString(value, idxIncome, idxFinance, splitIncome.Length);
                infoFinance = GetValuesInString(value, idxFinance, idxDetails, splitFinance.Length);
                infoDetails = GetValuesInString(value, idxDetails, idxRelative, splitDetails.Length);

                if (idxCustNews != -1)
                {
                    infoRelative = GetValuesInString(value, idxRelative, idxCustNews, splitRelative.Length);
                    infoCustNews = GetValuesInString(value, idxCustNews, idxEnd, splitCustomerNews.Length);
                }
                else
                    infoRelative = GetValuesInString(value, idxRelative, idxEnd, splitRelative.Length);
            }
        }

        // ML Application
        public static void LoadMLApplicationLORemodifySC(string value, ref string[] infoApp,
          ref string[] infoCustMB, ref string[] infoCustMBSalaried, ref string[] infoCustMBHouse, ref string[] infoCustMBCar, ref string[] infoCustMBPrivate,
          ref string[] infoCustCB1, ref string[] infoCustCB1Salaried, ref string[] infoCustCB1House, ref string[] infoCustCB1Car, ref string[] infoCustCB1Private,
          ref string[] infoCustCB2, ref string[] infoCustCB2Salaried, ref string[] infoCustCB2House, ref string[] infoCustCB2Car, ref string[] infoCustCB2Private,
          ref string[] infoCustCB3, ref string[] infoPro1, ref string[] infoPro2, ref string[] infoPro3, ref string[] infoPro4, ref string[] infoPro5,
          ref string[] infoColl1, ref string[] infoColl2, ref string[] infoColl3, ref string[] infoAppliedLoan,
          ref string[] infoCustMBNews, ref string[] infoCustCB1News, ref string[] infoCustCB2News, ref string[] infoCustCB3News)
        {
            if (value != null)
            {
                #region GetIndexOfSubString

                // MB
                int idxCustMB = value.IndexOf(splitCustMB);
                int idxCustMBSalaried = value.IndexOf(splitCustIncomeSalaried);
                int idxCustMBHouse = value.IndexOf(splitCustIncomeHouse);
                int idxCustMBCar = value.IndexOf(splitCustIncomeCar);
                int idxCustMBPrivate = value.IndexOf(splitCustIncomePrivate);

                // CB1
                int idxCustCB1 = value.IndexOf(splitCustCB1);
                int idxCustCB1Salaried = value.IndexOf(splitCustIncomeSalariedCB1);
                int idxCustCB1House = value.IndexOf(splitCustIncomeHouseCB1);
                int idxCustCB1Car = value.IndexOf(splitCustIncomeCarCB1);
                int idxCustCB1Private = value.IndexOf(splitCustIncomePrivateCB1);

                // CB2
                int idxCustCB2 = value.IndexOf(splitCustCB2);
                int idxCustCB2Salaried = value.IndexOf(splitCustIncomeSalariedCB2);
                int idxCustCB2House = value.IndexOf(splitCustIncomeHouseCB2);
                int idxCustCB2Car = value.IndexOf(splitCustIncomeCarCB2);
                int idxCustCB2Private = value.IndexOf(splitCustIncomePrivateCB2);

                // CB3
                int idxCustCB3 = value.IndexOf(splitCustCB3);

                // Property
                int idxProperty1 = value.IndexOf(splitProperty1);
                int idxProperty2 = value.IndexOf(splitProperty2);
                int idxProperty3 = value.IndexOf(splitProperty3);
                int idxProperty4 = value.IndexOf(splitProperty4);
                int idxProperty5 = value.IndexOf(splitProperty5);

                // Collateral
                int idxCollateral1 = value.IndexOf(splitCollateral1);
                int idxCollateral2 = value.IndexOf(splitCollateral2);
                int idxCollateral3 = value.IndexOf(splitCollateral3);

                // Applied Loan
                int idxApplied = value.IndexOf(splitAppliedLoan);

                // NEWS
                int idxCustMBNews = value.IndexOf(splitCustMBNews);
                int idxCustCB1News = value.IndexOf(splitCustCB1News);
                int idxCustCB2News = value.IndexOf(splitCustCB2News);
                int idxCustCB3News = value.IndexOf(splitCustCB3News);

                int idxEnd = value.IndexOf(splitAppEnd);

                #endregion

                infoApp = GetValuesInString(value, 0, idxCustMB, splitAppStart.Length);

                #region CustomerDetails

                // CustMB
                infoCustMB = GetValuesInString(value, idxCustMB, idxCustMBSalaried, splitCustMB.Length);
                // Income
                infoCustMBSalaried = GetValuesInString(value, idxCustMBSalaried, idxCustMBHouse, splitCustIncomeSalaried.Length);
                infoCustMBHouse = GetValuesInString(value, idxCustMBHouse, idxCustMBCar, splitCustIncomeHouse.Length);
                infoCustMBCar = GetValuesInString(value, idxCustMBCar, idxCustMBPrivate, splitCustIncomeCar.Length);
                infoCustMBPrivate = GetValuesInString(value, idxCustMBPrivate, idxCustCB1, splitCustIncomePrivate.Length);

                // CustCB1
                infoCustCB1 = GetValuesInString(value, idxCustCB1, idxCustCB1Salaried, splitCustCB1.Length);
                // Income
                if (infoCustCB1.Length > 1)
                {
                    infoCustCB1Salaried = GetValuesInString(value, idxCustCB1Salaried, idxCustCB1House, splitCustIncomeSalariedCB1.Length);
                    infoCustCB1House = GetValuesInString(value, idxCustCB1House, idxCustCB1Car, splitCustIncomeHouseCB1.Length);
                    infoCustCB1Car = GetValuesInString(value, idxCustCB1Car, idxCustCB1Private, splitCustIncomeCarCB1.Length);
                    infoCustCB1Private = GetValuesInString(value, idxCustCB1Private, idxCustCB2, splitCustIncomePrivateCB1.Length);
                }

                // CustCB2
                infoCustCB2 = GetValuesInString(value, idxCustCB2, idxCustCB2Salaried, splitCustCB2.Length);
                // Income
                if (infoCustCB2.Length > 1)
                {
                    infoCustCB2Salaried = GetValuesInString(value, idxCustCB2Salaried, idxCustCB2House, splitCustIncomeSalariedCB2.Length);
                    infoCustCB2House = GetValuesInString(value, idxCustCB2House, idxCustCB2Car, splitCustIncomeHouseCB2.Length);
                    infoCustCB2Car = GetValuesInString(value, idxCustCB2Car, idxCustCB2Private, splitCustIncomeCarCB2.Length);
                    infoCustCB2Private = GetValuesInString(value, idxCustCB2Private, idxCustCB3, splitCustIncomePrivateCB2.Length);
                }

                // CustCB3
                infoCustCB3 = GetValuesInString(value, idxCustCB3, idxProperty1, splitCustCB3.Length);

                #endregion

                #region Property & Collateral

                infoPro1 = GetValuesInString(value, idxProperty1, idxProperty2, splitProperty1.Length);
                infoPro2 = GetValuesInString(value, idxProperty2, idxProperty3, splitProperty2.Length);
                infoPro3 = GetValuesInString(value, idxProperty3, idxProperty4, splitProperty3.Length);
                infoPro4 = GetValuesInString(value, idxProperty4, idxProperty5, splitProperty4.Length);
                infoPro5 = GetValuesInString(value, idxProperty5, idxCollateral1, splitProperty5.Length);

                infoColl1 = GetValuesInString(value, idxCollateral1, idxCollateral2, splitCollateral1.Length);
                infoColl2 = GetValuesInString(value, idxCollateral2, idxCollateral3, splitCollateral2.Length);
                infoColl3 = GetValuesInString(value, idxCollateral3, idxApplied, splitCollateral3.Length);

                #endregion

                if (idxCustMBNews != -1)
                {
                    infoAppliedLoan = GetValuesInString(value, idxApplied, idxCustMBNews, splitAppliedLoan.Length);
                    // NEWS
                    //infoCustMBNews = GetValuesInString(value, idxCustMBNews, idxEnd, splitCustMBNews.Length);
                    infoCustMBNews = GetValuesInString(value, idxCustMBNews, idxCustCB1News, splitCustMBNews.Length);
                    infoCustCB1News = GetValuesInString(value, idxCustCB1News, idxCustCB2News, splitCustCB1News.Length);
                    infoCustCB2News = GetValuesInString(value, idxCustCB2News, idxCustCB3News, splitCustCB2News.Length);
                    infoCustCB3News = GetValuesInString(value, idxCustCB3News, idxEnd, splitCustCB3News.Length);
                }
                else
                    infoAppliedLoan = GetValuesInString(value, idxApplied, idxEnd, splitAppliedLoan.Length);
            }
        }

        public static void LoadMLApplicationOSRemodifySC(string value, ref string[] infoApp,
          ref string[] infoCustMB, ref string[] infoCustCB1, ref string[] infoCustCB2, ref string[] infoCustCB3,
          ref string[] infoPro1, ref string[] infoPro2, ref string[] infoPro3, ref string[] infoPro4, ref string[] infoPro5,
          ref string[] infoColl1, ref string[] infoColl2, ref string[] infoColl3, ref string[] infoAppliedLoan, ref string[] infoCustMBNews)
        {
            if (value != null)
            {
                #region GetIndexOfSubString

                // MB
                int idxCustMB = value.IndexOf(splitCustMB);
                int idxCustMBSalaried = value.IndexOf(splitCustIncomeSalaried);
                int idxCustMBHouse = value.IndexOf(splitCustIncomeHouse);
                int idxCustMBCar = value.IndexOf(splitCustIncomeCar);
                int idxCustMBPrivate = value.IndexOf(splitCustIncomePrivate);

                // CB1
                int idxCustCB1 = value.IndexOf(splitCustCB1);
                int idxCustCB1Salaried = value.IndexOf(splitCustIncomeSalariedCB1);
                int idxCustCB1House = value.IndexOf(splitCustIncomeHouseCB1);
                int idxCustCB1Car = value.IndexOf(splitCustIncomeCarCB1);
                int idxCustCB1Private = value.IndexOf(splitCustIncomePrivateCB1);

                // CB2
                int idxCustCB2 = value.IndexOf(splitCustCB2);
                int idxCustCB2Salaried = value.IndexOf(splitCustIncomeSalariedCB2);
                int idxCustCB2House = value.IndexOf(splitCustIncomeHouseCB2);
                int idxCustCB2Car = value.IndexOf(splitCustIncomeCarCB2);
                int idxCustCB2Private = value.IndexOf(splitCustIncomePrivateCB2);

                // CB3
                int idxCustCB3 = value.IndexOf(splitCustCB3);

                // Property
                int idxProperty1 = value.IndexOf(splitProperty1);
                int idxProperty2 = value.IndexOf(splitProperty2);
                int idxProperty3 = value.IndexOf(splitProperty3);
                int idxProperty4 = value.IndexOf(splitProperty4);
                int idxProperty5 = value.IndexOf(splitProperty5);

                // Collateral
                int idxCollateral1 = value.IndexOf(splitCollateral1);
                int idxCollateral2 = value.IndexOf(splitCollateral2);
                int idxCollateral3 = value.IndexOf(splitCollateral3);

                // Applied Loan
                int idxApplied = value.IndexOf(splitAppliedLoan);

                // NEWS
                int idxCustMBNews = value.IndexOf(splitCustMBNews);

                int idxEnd = value.IndexOf(splitAppEnd);

                #endregion

                infoApp = GetValuesInString(value, 0, idxCustMB, splitAppStart.Length);

                #region CustomerDetails

                string[] infoCustMBSalaried = null, infoCustMBHouse, infoCustMBCar = null, infoCustMBPrivate = null;
                string[] infoCustCB1Salaried = null, infoCustCB1House, infoCustCB1Car = null, infoCustCB1Private = null;
                string[] infoCustCB2Salaried = null, infoCustCB2House, infoCustCB2Car = null, infoCustCB2Private = null;
                // CustMB
                infoCustMB = GetValuesInString(value, idxCustMB, idxCustMBSalaried, splitCustMB.Length);
                // Income
                infoCustMBSalaried = GetValuesInString(value, idxCustMBSalaried, idxCustMBHouse, splitCustIncomeSalaried.Length);
                infoCustMBHouse = GetValuesInString(value, idxCustMBHouse, idxCustMBCar, splitCustIncomeHouse.Length);
                infoCustMBCar = GetValuesInString(value, idxCustMBCar, idxCustMBPrivate, splitCustIncomeCar.Length);
                infoCustMBPrivate = GetValuesInString(value, idxCustMBPrivate, idxCustCB1, splitCustIncomePrivate.Length);

                // CustCB1
                infoCustCB1 = GetValuesInString(value, idxCustCB1, idxCustCB1Salaried, splitCustCB1.Length);
                // Income
                if (infoCustCB1.Length > 1)
                {
                    infoCustCB1Salaried = GetValuesInString(value, idxCustCB1Salaried, idxCustCB1House, splitCustIncomeSalariedCB1.Length);
                    infoCustCB1House = GetValuesInString(value, idxCustCB1House, idxCustCB1Car, splitCustIncomeHouseCB1.Length);
                    infoCustCB1Car = GetValuesInString(value, idxCustCB1Car, idxCustCB1Private, splitCustIncomeCarCB1.Length);
                    infoCustCB1Private = GetValuesInString(value, idxCustCB1Private, idxCustCB2, splitCustIncomePrivateCB1.Length);
                }

                // CustCB2
                infoCustCB2 = GetValuesInString(value, idxCustCB2, idxCustCB2Salaried, splitCustCB2.Length);
                // Income
                if (infoCustCB2.Length > 1)
                {
                    infoCustCB2Salaried = GetValuesInString(value, idxCustCB2Salaried, idxCustCB2House, splitCustIncomeSalariedCB2.Length);
                    infoCustCB2House = GetValuesInString(value, idxCustCB2House, idxCustCB2Car, splitCustIncomeHouseCB2.Length);
                    infoCustCB2Car = GetValuesInString(value, idxCustCB2Car, idxCustCB2Private, splitCustIncomeCarCB2.Length);
                    infoCustCB2Private = GetValuesInString(value, idxCustCB2Private, idxCustCB3, splitCustIncomePrivateCB2.Length);
                }

                // CustCB3
                infoCustCB3 = GetValuesInString(value, idxCustCB3, idxProperty1, splitCustCB3.Length);

                #endregion

                #region Property & Collateral

                infoPro1 = GetValuesInString(value, idxProperty1, idxProperty2, splitProperty1.Length);
                infoPro2 = GetValuesInString(value, idxProperty2, idxProperty3, splitProperty2.Length);
                infoPro3 = GetValuesInString(value, idxProperty3, idxProperty4, splitProperty3.Length);
                infoPro4 = GetValuesInString(value, idxProperty4, idxProperty5, splitProperty4.Length);
                infoPro5 = GetValuesInString(value, idxProperty5, idxCollateral1, splitProperty5.Length);

                infoColl1 = GetValuesInString(value, idxCollateral1, idxCollateral2, splitCollateral1.Length);
                infoColl2 = GetValuesInString(value, idxCollateral2, idxCollateral3, splitCollateral2.Length);
                infoColl3 = GetValuesInString(value, idxCollateral3, idxApplied, splitCollateral3.Length);

                #endregion

                if (idxCustMBNews != -1)
                {
                    infoAppliedLoan = GetValuesInString(value, idxApplied, idxCustMBNews, splitAppliedLoan.Length);
                    // NEWS
                    infoCustMBNews = GetValuesInString(value, idxCustMBNews, idxEnd, splitCustMBNews.Length);

                }
                else
                    infoAppliedLoan = GetValuesInString(value, idxApplied, idxEnd, splitAppliedLoan.Length);
            }
        }

        #endregion

        #region CI Modify SC

        // PL Application
        public static void LoadPLApplicationCIModifiedSC(string value, ref string[] infoApp, ref string[] infoCust)
        {
            if (value != null)
            {
                int idxCust = value.IndexOf(splitCustomer);
                int idxEnd = value.IndexOf(splitAppEnd);

                infoApp = GetValuesInString(value, 0, idxCust, splitAppStart.Length);
                infoCust = GetValuesInString(value, idxCust, idxEnd, splitCustomer.Length);
            }
        }

        // ML Application
        public static void LoadMLApplicationCIModifiedSC(string value, ref string[] infoApp,
          ref string[] infoCustMB, ref string[] infoCustCB1, ref string[] infoCustCB2, ref string[] infoCustCB3,
          ref string[] infoPro1, ref string[] infoPro2, ref string[] infoPro3, ref string[] infoPro4, ref string[] infoPro5,
          ref string[] infoColl1, ref string[] infoColl2, ref string[] infoColl3)
        {
            if (value != null)
            {
                #region GetIndexOfSubString

                // Customer
                int idxCustMB = value.IndexOf(splitCustMB);
                int idxCustCB1 = value.IndexOf(splitCustCB1);
                int idxCustCB2 = value.IndexOf(splitCustCB2);
                int idxCustCB3 = value.IndexOf(splitCustCB3);

                // Property
                int idxProperty1 = value.IndexOf(splitProperty1);
                int idxProperty2 = value.IndexOf(splitProperty2);
                int idxProperty3 = value.IndexOf(splitProperty3);
                int idxProperty4 = value.IndexOf(splitProperty4);
                int idxProperty5 = value.IndexOf(splitProperty5);

                // Collateral
                int idxCollateral1 = value.IndexOf(splitCollateral1);
                int idxCollateral2 = value.IndexOf(splitCollateral2);
                int idxCollateral3 = value.IndexOf(splitCollateral3);

                int idxEnd = value.IndexOf(splitAppEnd);

                #endregion

                infoApp = GetValuesInString(value, 0, idxCustMB, splitAppStart.Length);

                #region Customer

                infoCustMB = GetValuesInString(value, idxCustMB, idxCustCB1, splitCustMB.Length);
                infoCustCB1 = GetValuesInString(value, idxCustCB1, idxCustCB2, splitCustCB1.Length);
                infoCustCB2 = GetValuesInString(value, idxCustCB2, idxCustCB3, splitCustCB2.Length);
                infoCustCB3 = GetValuesInString(value, idxCustCB3, idxProperty1, splitCustCB3.Length);

                #endregion

                #region Property & Collateral

                infoPro1 = GetValuesInString(value, idxProperty1, idxProperty2, splitProperty1.Length);
                infoPro2 = GetValuesInString(value, idxProperty2, idxProperty3, splitProperty2.Length);
                infoPro3 = GetValuesInString(value, idxProperty3, idxProperty4, splitProperty3.Length);
                infoPro4 = GetValuesInString(value, idxProperty4, idxProperty5, splitProperty4.Length);
                infoPro5 = GetValuesInString(value, idxProperty5, idxCollateral1, splitProperty5.Length);

                infoColl1 = GetValuesInString(value, idxCollateral1, idxCollateral2, splitCollateral1.Length);
                infoColl2 = GetValuesInString(value, idxCollateral2, idxCollateral3, splitCollateral2.Length);
                infoColl3 = GetValuesInString(value, idxCollateral3, idxEnd, splitCollateral3.Length);

                #endregion
            }
        }

        #endregion

        public static DataTable CompareTables(DataTable tbl1, DataTable tbl2, out bool isDifference)
        {
            isDifference = false;
            DataTable finalTable = tbl1.Clone();

            if (tbl1.Rows.Count != tbl2.Rows.Count || tbl1.Columns.Count != tbl2.Columns.Count)
                return null;

            for (int i = 0; i < tbl1.Rows.Count; i++)
            {
                DataRow row1 = finalTable.NewRow();
                DataRow row2 = finalTable.NewRow();
                // fill ApplicationNo
                row1[0] = tbl1.Rows[i][0];
                row2[0] = tbl2.Rows[i][0];

                for (int c = 1; c < tbl1.Columns.Count; c++)
                {
                    if (!Equals(tbl1.Rows[i][c], tbl2.Rows[i][c]))
                    {
                        row1[c] = tbl1.Rows[i][c];
                        row2[c] = tbl2.Rows[i][c];

                        if (c != 0 && c != 1 && c != 2 && c != 3 && c != 4)
                            isDifference = true;
                    }
                }
                finalTable.Rows.Add(row1);
                finalTable.Rows.Add(row2);
            }
            return finalTable;
        }

        #endregion

        #region GetIPAddress
        public static string GetIPAddress()
        {
            try
            {
                string myIP = "";
                string strHostName = Dns.GetHostName();

                // get IP Address based on host name above
                myIP = Dns.GetHostEntry(strHostName).AddressList[0].ToString();
                return myIP;
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GetDataFromExcel

        /// <summary>
        /// Get Data From XLS
        /// </summary>
        /// <param name="path">string</param>
        /// <param name="sheet">string</param>
        /// <param name="isHeader">bool</param>
        /// <returns>DataTable</returns>
        public static DataTable GetDataFromXLS(string path, string sheet, bool isHeader)
        {
            try
            {
                //Datatable Object
                DataTable dt = new DataTable();

                //Creating a file stream containing the Excel file to be opened
                FileStream fstream = new FileStream(path, FileMode.Open);

                //Opening the Excel file through the file stream
                Workbook workbook = new Workbook(fstream);

                //Accessing the first worksheet in the Excel file
                Worksheet worksheet = workbook.Worksheets[sheet];

                ExportTableOptions opts = new ExportTableOptions();
                opts.CheckMixedValueType = true; //commmenting this line will throw exception
                opts.ExportColumnName = isHeader;

                //Exporting the contents of x rows and x columns starting from 1st cell to DataTable
                dt = worksheet.Cells.ExportDataTable(0, 0, worksheet.Cells.MaxDataRow + 1, worksheet.Cells.MaxDataColumn + 1, opts);

                //Closing the file stream to free all resources
                fstream.Close();

                //return result
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region ConvertData

        private static List<string> m_ignoredDateTimes;
        public static List<string> IgnoredDateTimes
        {
            get
            {
                if (m_ignoredDateTimes == null || m_ignoredDateTimes.Count < 0)
                {
                    m_ignoredDateTimes = new List<string>(new string[] { "00/00/0000" });
                }

                return m_ignoredDateTimes;
            }

            set
            {
                m_ignoredDateTimes = value;
            }
        }

        private static List<string> m_dateTimeFormats;
        public static List<string> DateTimeFormats
        {
            get
            {
                if (m_dateTimeFormats == null || m_dateTimeFormats.Count < 0)
                {
                    m_dateTimeFormats = new List<string>(new string[] { "d-MMM", "dd/MM/yyyy", "MM/dd/yyyy", "M/d/yyyy", "d/M/yyyy", "yyyyMMdd", "MM/dd/yyyy", "MM-dd-yyyy", "d-MMM-yy", "dd/MM/yyyy", "dd-MMM-yy", "dd MMM yy", "dd/MMM/yy", "dd-MM-yyyy", "d-MMM-yyyy", "M/dd/yyyy hh:mm:ss tt", "000000" });
                }

                return m_dateTimeFormats;
            }

            set
            {
                m_dateTimeFormats = value;
            }
        }

        public static string TryParseSQLDateTime(string text, List<string> ignoredText,
          List<string> formats, out DateTime? dateTime, string cultureString)
        {
            try
            {
                dateTime = null;
                if (!string.IsNullOrEmpty(text.Trim()) && !ignoredText.Contains(text.Trim()))
                {
                    DateTime result;
                    if (DateTime.TryParseExact(text.Trim(), formats.ToArray(), cultureString == null ? null : CultureInfo.CreateSpecificCulture(cultureString), DateTimeStyles.None, out result))
                    {
                        if (result >= (DateTime)SqlDateTime.MinValue && result <= (DateTime)SqlDateTime.MaxValue)
                        {
                            dateTime = result;
                            return "valid";
                        }

                        return "overflowing";
                    }

                    return "invalid";
                }

                return "valid";
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region CheckCIAction
        public static bool IsCI1AllowedAction(string userCI2, string currentUser)
        {
            bool isAllowed = false;

            if (!string.IsNullOrEmpty(userCI2))
            {
                if (currentUser != userCI2)
                    isAllowed = true;
            }
            else
                isAllowed = true;

            return isAllowed;
        }

        public static bool IsCI2AllowedAction(string userCI1, string currentUser)
        {
            bool isAllowed = false;

            if (!string.IsNullOrEmpty(userCI1))
            {
                if (currentUser != userCI1)
                    isAllowed = true;
            }
            else
                isAllowed = true;

            return isAllowed;
        }
        #endregion

        #region MailMerge_CreateDataTable

        /// <summary>
        /// Create Data Table
        /// </summary>
        /// <param name="columnNames">string</param>
        /// <returns>DataTable</returns>
        public static DataTable CreateDataTable(string columnNames)
        {
            DataTable dataTable = new DataTable();
            try
            {
                string[] listColumn = columnNames.Split(',');
                foreach (string sCol in listColumn)
                    dataTable.Columns.Add(sCol);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Mail Merge Word
        /// </summary>
        /// <param name="path">string</param>
        /// <param name="dataTable">DataTable</param>
        /// <param name="savedFileName">string</param>
        public static void MailMergeWord(string path, DataTable dataTable, string savedFileName)
        {
            try
            {
                Aspose.Words.Document doc = new Aspose.Words.Document(path);

                doc.MailMerge.Execute(dataTable);
                doc.Protect(Aspose.Words.ProtectionType.NoProtection);
                doc.Save(savedFileName + ".docx", Aspose.Words.SaveFormat.Docx, Aspose.Words.SaveType.OpenInWord, HttpContext.Current.Response);

                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Mail Merge PDF
        /// </summary>
        /// <param name="path">string</param>
        /// <param name="dataTable">DataTable</param>
        /// <param name="savedFileName">string</param>
        public static void MailMergePDF(string path, DataTable dataTable, string savedFileName)
        {
            try
            {
                Aspose.Words.Document doc = new Aspose.Words.Document(path);

                doc.MailMerge.Execute(dataTable);
                doc.Protect(Aspose.Words.ProtectionType.ReadOnly);
                doc.Save(savedFileName + ".pdf", Aspose.Words.SaveFormat.Pdf, Aspose.Words.SaveType.OpenInWord, HttpContext.Current.Response);

                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region MappingRejectedReason

        /// <summary>
        /// Get Rejected Reason Vietnamese
        /// </summary>
        /// <param name="rejectedCode">string</param>
        /// <param name="pathMappingFile">string</param>
        /// <returns>string</returns>
        public static string GetRejectedReasonVietnamese(string rejectedCode, string pathMappingFile)
        {
            string reasonVN = string.Empty;
            try
            {
                rejectedCode = GetShortRejectedCode(rejectedCode);

                DataTable dtReason = GetDataFromXLS(pathMappingFile, "Sheet1", false);
                if (dtReason.Rows.Count > 0)
                {
                    foreach (DataRow row in dtReason.Rows)
                    {
                        string codeReject = row[0].ToString();
                        if (codeReject.StartsWith(rejectedCode))
                        {
                            reasonVN = row[3].ToString();
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return reasonVN;
        }

        /// <summary>
        /// Get Short Rejected Code
        /// </summary>
        /// <param name="rejectedReason">string</param>
        /// <returns>string</returns>
        public static string GetShortRejectedCode(string rejectedReason)
        {
            if (!string.IsNullOrEmpty(rejectedReason))
            {
                int idxEnd = rejectedReason.IndexOf('-');
                rejectedReason = rejectedReason.Substring(0, idxEnd);

                return rejectedReason.Trim();
            }

            return null;
        }

        #endregion

        #region MethodSupportTAT

        public static double HoursAdded(DateTime? startTime, DateTime? endTime)
        {
            double _hoursAdded = 0;

            #region Variables

            int hourWorkingEnd = 0, minWorkingEnd = 0, hourWorkingStart = 0, minWorkingStart = 0;
            GetInfoCutOffTime(out hourWorkingEnd, out minWorkingEnd, out hourWorkingStart, out minWorkingStart);

            DateTime dateSubTract = new DateTime();
            TimeSpan spanTime = new TimeSpan();

            #endregion

            #region StartTime

            if (startTime.Value.Hour > hourWorkingEnd || (startTime.Value.Hour == hourWorkingEnd && startTime.Value.Minute > minWorkingEnd))
            {
                dateSubTract = new DateTime(startTime.Value.Year, startTime.Value.Month, startTime.Value.Day, hourWorkingEnd, minWorkingEnd, 0);
                spanTime = startTime.Value.Subtract(dateSubTract);
            }
            if (startTime.Value.Hour < hourWorkingStart || (startTime.Value.Hour == hourWorkingStart && startTime.Value.Minute < minWorkingStart))
            {
                dateSubTract = new DateTime(startTime.Value.Year, startTime.Value.Month, startTime.Value.Day, hourWorkingStart, minWorkingStart, 0);
                spanTime = dateSubTract.Subtract(startTime.Value);
            }
            #endregion

            #region EndTime

            if (endTime.Value.Hour > hourWorkingEnd || (endTime.Value.Hour == hourWorkingEnd && endTime.Value.Minute > minWorkingEnd))
            {
                dateSubTract = new DateTime(endTime.Value.Year, endTime.Value.Month, endTime.Value.Day, hourWorkingEnd, minWorkingEnd, 0);
                spanTime = endTime.Value.Subtract(dateSubTract);
            }
            if (endTime.Value.Hour < hourWorkingStart || (endTime.Value.Hour == hourWorkingStart && endTime.Value.Minute < minWorkingStart))
            {
                dateSubTract = new DateTime(endTime.Value.Year, endTime.Value.Month, endTime.Value.Day, hourWorkingStart, minWorkingStart, 0);
                spanTime = dateSubTract.Subtract(endTime.Value);
            }
            #endregion

            _hoursAdded = spanTime.TotalHours;

            return _hoursAdded;
        }

        public static bool IsRangeCutOffTime(DateTime? startTime, DateTime? endTime)
        {
            int hourWorkingEnd = 0, minWorkingEnd = 0, hourWorkingStart = 0, minWorkingStart = 0;
            GetInfoCutOffTime(out hourWorkingEnd, out minWorkingEnd, out hourWorkingStart, out minWorkingStart);

            if ((startTime.Value.Hour > hourWorkingEnd && endTime.Value.Hour > hourWorkingEnd) ||
                ((startTime.Value.Hour == hourWorkingEnd && startTime.Value.Minute > minWorkingEnd) && (endTime.Value.Hour == hourWorkingEnd && endTime.Value.Minute > minWorkingEnd)) ||
                 ((startTime.Value.Hour == hourWorkingEnd && startTime.Value.Minute > minWorkingEnd) && (endTime.Value.Hour > hourWorkingEnd)) ||
                 ((startTime.Value.Hour > hourWorkingEnd) && (endTime.Value.Hour == hourWorkingEnd && endTime.Value.Minute > minWorkingEnd)))
                return true;
            return false;
        }

        public static bool IsWeekend(DateTime date)
        {
            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                return true;
            return false;
        }

        public static bool IsWorkingTime(DateTime time)
        {
            string timeEnd = ConfigurationManager.AppSettings["working_EndTime"];
            string timeStart = ConfigurationManager.AppSettings["working_StartTime"];

            TimeSpan spanStart = new TimeSpan(int.Parse(timeStart.Substring(0, 2)), int.Parse(timeStart.Substring(3, 2)), 0);
            TimeSpan spanEnd = new TimeSpan(int.Parse(timeEnd.Substring(0, 2)), int.Parse(timeEnd.Substring(3, 2)), 0);

            if (time.TimeOfDay >= spanStart && time.TimeOfDay <= spanEnd)
                return true;
            return false;
        }

        public static bool IsOutOfWorkingTimeStart(DateTime time)
        {
            string timeStart = ConfigurationManager.AppSettings["working_StartTime"];

            TimeSpan spanStart = new TimeSpan(int.Parse(timeStart.Substring(0, 2)), int.Parse(timeStart.Substring(3, 2)), 0);

            if (time.TimeOfDay < spanStart)
                return true;
            return false;
        }

        public static bool IsOutOfWorkingTimeEnd(DateTime time)
        {
            string timeEnd = ConfigurationManager.AppSettings["working_EndTime"];

            TimeSpan spanEnd = new TimeSpan(int.Parse(timeEnd.Substring(0, 2)), int.Parse(timeEnd.Substring(3, 2)), 0);

            if (time.TimeOfDay > spanEnd)
                return true;
            return false;
        }

        public static double GetCutOffTime()
        {
            string timeOffStart = ConfigurationManager.AppSettings["working_EndTime"];
            string timeOffEnd = ConfigurationManager.AppSettings["working_StartTime"];

            DateTime cutOffStart = DateTime.Now.AddDays(-1).AddHours(int.Parse(timeOffStart.Substring(0, 2))).AddMinutes(int.Parse(timeOffStart.Substring(3, 2))).AddSeconds(0);
            DateTime cutOffEnd = DateTime.Now.AddHours(int.Parse(timeOffEnd.Substring(0, 2))).AddMinutes(int.Parse(timeOffEnd.Substring(3, 2))).AddSeconds(0);

            TimeSpan spanCutOff = cutOffEnd.Subtract(cutOffStart);
            return spanCutOff.TotalHours;
        }

        public static void GetInfoCutOffTime(out int _hourWEnd, out int _minWEnd, out int _hourWStart, out int _minWStart)
        {
            _hourWEnd = _minWEnd = _hourWStart = _minWStart = 0;

            string timeWorkingEnd = ConfigurationManager.AppSettings["working_EndTime"];
            _hourWEnd = int.Parse(timeWorkingEnd.Substring(0, 2));
            _minWEnd = int.Parse(timeWorkingEnd.Substring(3, 2));

            string timeWorkingStart = ConfigurationManager.AppSettings["working_StartTime"];
            _hourWStart = int.Parse(timeWorkingStart.Substring(0, 2));
            _minWStart = int.Parse(timeWorkingStart.Substring(3, 2));
        }

        #region CuttOffTime

        public static double CutOffTime(DateTime? startTime, DateTime? endTime)
        {
            try
            {
                double cutOffTime = 0;

                TimeSpan spanDay = DateTime.Parse(endTime.Value.ToShortDateString()).Subtract(DateTime.Parse(startTime.Value.ToShortDateString()));
                if (spanDay.Days >= 1)
                    cutOffTime = (GetCutOffTime() * spanDay.Days);
                else
                {
                    if (IsRangeCutOffTime(startTime, endTime))
                        return 0;
                    else
                    {
                        #region Variables

                        int hourWorkingEnd = 0, minWorkingEnd = 0, hourWorkingStart = 0, minWorkingStart = 0;
                        GetInfoCutOffTime(out hourWorkingEnd, out minWorkingEnd, out hourWorkingStart, out minWorkingStart);

                        DateTime dateSubTract = new DateTime();
                        TimeSpan spanTime = new TimeSpan();

                        #endregion

                        // subtract times out of working time in day (End of day)
                        if (endTime.Value.Hour > hourWorkingEnd || (endTime.Value.Hour == hourWorkingEnd && endTime.Value.Minute > minWorkingEnd))
                        {
                            dateSubTract = new DateTime(endTime.Value.Year, endTime.Value.Month, endTime.Value.Day, hourWorkingEnd, minWorkingEnd, 0);
                            spanTime = DateTime.Parse(endTime.Value.ToString()).Subtract(dateSubTract);

                            cutOffTime = spanTime.TotalHours;
                        }
                        // Start of day
                        if (startTime.Value.Hour < hourWorkingStart || (startTime.Value.Hour == hourWorkingStart && startTime.Value.Minute < minWorkingStart))
                        {
                            dateSubTract = new DateTime(startTime.Value.Year, startTime.Value.Month, startTime.Value.Day, hourWorkingStart, minWorkingStart, 0);
                            spanTime = dateSubTract.Subtract(DateTime.Parse(startTime.Value.ToString()));

                            cutOffTime = (cutOffTime + spanTime.TotalHours);
                        }
                    }
                }
                return cutOffTime;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        #endregion

        #region CutOffLunchTime

        private static void OutDateLunchTime(DateTime? _inputTime, out DateTime _outLunchDateStart, out DateTime _outLunchDateEnd)
        {
            _outLunchDateStart = _outLunchDateEnd = new DateTime();

            string[] slunchTime = ConfigurationManager.AppSettings["LunchTime"].Split('-');
            int _lunchHourStart = int.Parse(slunchTime[0]);
            int _lunchHourEnd = int.Parse(slunchTime[1]);

            _outLunchDateStart = new DateTime(_inputTime.Value.Year, _inputTime.Value.Month, _inputTime.Value.Day, _lunchHourStart, 0, 0);
            _outLunchDateEnd = new DateTime(_inputTime.Value.Year, _inputTime.Value.Month, _inputTime.Value.Day, _lunchHourEnd, 0, 0);
        }

        private static DateTime OutDateLunchTimeStart(DateTime? _inputTime)
        {
            string[] slunchTime = ConfigurationManager.AppSettings["LunchTime"].Split('-');
            int _lunchHourStart = int.Parse(slunchTime[0]);

            return new DateTime(_inputTime.Value.Year, _inputTime.Value.Month, _inputTime.Value.Day, _lunchHourStart, 0, 0);
        }

        private static bool IsRangeLunchTime(DateTime? _checkedTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            OutDateLunchTime(_checkedTime, out _dtStart, out _dtEnd);

            if (_checkedTime.Value > _dtStart && _checkedTime.Value <= _dtEnd)
                return true;
            return false;
        }

        private static bool IsStartBeforeLunchAndEndAfterLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (_startTime.Value <= _dtStart && _endTime >= _dtEnd2)
                return true;
            return false;
        }

        private static bool IsStartAfterLunchAndEndBeforeLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (_startTime.Value >= _dtEnd && _endTime.Value <= _dtStart2)
                return true;
            return false;
        }

        private static bool IsStartInLunchAndEndBeforeLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (IsRangeLunchTime(_startTime) && _endTime.Value.Hour <= _dtStart2.Hour)
                return true;
            return false;
        }

        private static bool IsStartAfterLunchAndEndInLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (IsRangeLunchTime(_endTime) && _startTime.Value.Hour >= _dtEnd2.Hour)
                return true;
            return false;
        }

        private static bool IsStartAndEndAfterLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (_startTime.Value.Hour >= _dtEnd.Hour && _endTime.Value.Hour >= _dtEnd2.Hour)
                return true;
            return false;
        }

        private static bool IsStartAndEndBeforeLunch(DateTime? _startTime, DateTime? _endTime)
        {
            DateTime _dtStart = new DateTime();
            DateTime _dtEnd = new DateTime();

            DateTime _dtStart2 = new DateTime();
            DateTime _dtEnd2 = new DateTime();

            OutDateLunchTime(_startTime, out _dtStart, out _dtEnd);
            OutDateLunchTime(_endTime, out _dtStart2, out _dtEnd2);

            if (_startTime.Value.Hour <= _dtStart.Hour && _endTime.Value.Hour <= _dtStart2.Hour)
                return true;
            return false;
        }

        private static double GetTimeHours(DateTime? _startTime, DateTime? _endTime)
        {
            double _hours = 0;

            TimeSpan _spanTime = _endTime.Value.Subtract(_startTime.Value);
            _hours = _spanTime.TotalHours;

            return _hours;
        }

        public static int LunchTime()
        {
            string[] slunchTime = ConfigurationManager.AppSettings["LunchTime"].Split('-');
            int _lunchHourStart = int.Parse(slunchTime[0]);
            int _lunchHourEnd = int.Parse(slunchTime[1]);
            return (_lunchHourEnd - _lunchHourStart);
        }

        public static double GetHoursLunchTime(DateTime? startTime, DateTime? endTime, out int _indexDays)
        {
            double _subtractedHours = 0;
            _indexDays = 0;

            DateTime _dtLunchStart = new DateTime();

            if (!IsRangeLunchTime(startTime))
            {
                if (IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, endTime);
                    _indexDays = 1;
                }
                else
                {
                    if (IsStartBeforeLunchAndEndAfterLunch(startTime, endTime))
                        _subtractedHours = LunchTime(); // 1

                    if (IsStartAfterLunchAndEndBeforeLunch(startTime, endTime))
                        _subtractedHours = 0;

                    _indexDays = 2;
                }
            }
            else
            {
                if (!IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(startTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, startTime);
                    _indexDays = 1;
                }
                else
                {
                    _dtLunchStart = OutDateLunchTimeStart(startTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, startTime);

                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = (_subtractedHours + GetTimeHours(_dtLunchStart, endTime));

                    _indexDays = 2;
                }
            }

            if (IsStartInLunchAndEndBeforeLunch(startTime, endTime))
            {
                _dtLunchStart = OutDateLunchTimeStart(startTime);
                _subtractedHours = GetTimeHours(_dtLunchStart, startTime);
                _indexDays = 1;
            }

            if (IsStartAfterLunchAndEndInLunch(startTime, endTime))
            {
                _dtLunchStart = OutDateLunchTimeStart(endTime);
                _subtractedHours = GetTimeHours(_dtLunchStart, endTime);
                _indexDays = 1;
            }

            if (IsStartAndEndAfterLunch(startTime, endTime) || IsStartAndEndBeforeLunch(startTime, endTime))
            {
                _subtractedHours = 0;
                _indexDays = 2;
            }

            return _subtractedHours;
        }

        public static double GetHoursLunchTimeInOneDay(DateTime? startTime, DateTime? endTime)
        {
            double _subtractedHours = 0;
            DateTime _dtLunchStart = new DateTime();

            string[] slunchTime = ConfigurationManager.AppSettings["LunchTime"].Split('-');
            int _lunchHourStart = int.Parse(slunchTime[0]);
            int _lunchHourEnd = int.Parse(slunchTime[1]);

            if (IsRangeLunchTime(startTime))
            {
                _dtLunchStart = OutDateLunchTimeStart(startTime);
                _subtractedHours = GetTimeHours(_dtLunchStart, startTime);

                if (IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = _subtractedHours + GetTimeHours(_dtLunchStart, endTime);
                }
                else if (endTime.Value.Hour < _lunchHourStart)
                {
                    _dtLunchStart = OutDateLunchTimeStart(startTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, startTime);
                }
                else if (endTime.Value.Hour >= _lunchHourEnd)
                {
                    _subtractedHours = _subtractedHours + LunchTime();
                }
            }
            else if (startTime.Value.Hour < _lunchHourStart)
            {
                if (IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = LunchTime() + GetTimeHours(_dtLunchStart, endTime);
                }
                else if (endTime.Value.Hour < _lunchHourStart)
                {
                    _subtractedHours = LunchTime();
                }
                else if (endTime.Value.Hour >= _lunchHourEnd)
                {
                    _subtractedHours = LunchTime() * 2;
                }
            }
            else if (startTime.Value.Hour >= _lunchHourEnd)
            {
                if (IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, endTime);
                }
                else if (endTime.Value.Hour < _lunchHourStart)
                {
                    _subtractedHours = 0;
                }
                else if (endTime.Value.Hour >= _lunchHourEnd)
                {
                    _subtractedHours = LunchTime();
                }
            }

            return _subtractedHours;
        }

        public static double GetHoursLunchTimeInDay(DateTime? startTime, DateTime? endTime)
        {
            double _subtractedHours = 0;

            string[] slunchTime = ConfigurationManager.AppSettings["LunchTime"].Split('-');
            int _lunchHourStart = int.Parse(slunchTime[0]);
            int _lunchHourEnd = int.Parse(slunchTime[1]);
            int _lunchTime = (_lunchHourEnd - _lunchHourStart);

            DateTime _dtLunchStart = new DateTime();

            if (startTime.Value.Hour < _lunchHourStart)
            {
                if (IsRangeLunchTime(endTime))
                {
                    _dtLunchStart = OutDateLunchTimeStart(endTime);
                    _subtractedHours = GetTimeHours(_dtLunchStart, endTime);
                }
                else if (endTime.Value.Hour >= _lunchHourEnd)
                {
                    _subtractedHours = _lunchTime;
                }
            }
            else
            {
                if (IsRangeLunchTime(startTime))
                {
                    if (IsRangeLunchTime(endTime))
                    {
                        TimeSpan _spanHours = endTime.Value.Subtract((DateTime)startTime);
                        _subtractedHours = _spanHours.TotalHours;
                    }
                    else
                    {
                        _dtLunchStart = OutDateLunchTimeStart(startTime);
                        _subtractedHours = GetTimeHours(_dtLunchStart, startTime);
                    }
                }
            }

            return _subtractedHours;
        }

        public static double CutOffLunchTime(DateTime? startTime, DateTime? endTime)
        {
            double _subtractedHour = 0;

            TimeSpan spanDay = DateTime.Parse(endTime.Value.ToShortDateString()).Subtract(DateTime.Parse(startTime.Value.ToShortDateString()));
            if (spanDay.Days > 1)
            {
                int _indexDays = 0;
                _subtractedHour = GetHoursLunchTime(startTime, endTime, out _indexDays);
                _subtractedHour = (LunchTime() * ((spanDay.Days + 1) - _indexDays)) + _subtractedHour;
            }
            else if (spanDay.Days == 1)
                _subtractedHour = GetHoursLunchTimeInOneDay(startTime, endTime);
            else
            {
                _subtractedHour = GetHoursLunchTimeInDay(startTime, endTime);
            }

            return _subtractedHour;
        }

        #endregion

        #region CutOffHolidays

        public static double CutOffPublicHolidays(DateTime? startTime, DateTime? endTime, bool isOneDay, out bool isHoliday)
        {
            double totalHoursHolidays = 0;
            isHoliday = false;

            int hourHolidays = (DataObject.GetDaysInHolidays((DateTime)startTime, (DateTime)endTime) * 24);
            if (hourHolidays != 0)
            {
                totalHoursHolidays = (hourHolidays - (DataObject.GetDaysInHolidays((DateTime)startTime, (DateTime)endTime) * GetCutOffTime()));

                if (isOneDay)
                    isHoliday = true;
            }

            return totalHoursHolidays;
        }

        #endregion
        #endregion
    }

    public static class EnhancedMath
    {
        private delegate double RoundingFunction(double value);

        private enum RoundingDirection { Up, Down }

        public static double RoundUp(double value, int precision)
        {
            return Round(value, precision, RoundingDirection.Up);
        }

        public static double RoundDown(double value, int precision)
        {
            return Round(value, precision, RoundingDirection.Down);
        }

        private static double Round(double value, int precision, RoundingDirection roundingDirection)
        {
            RoundingFunction roundingFunction;
            if (roundingDirection == RoundingDirection.Up)
                roundingFunction = Math.Ceiling;
            else
                roundingFunction = Math.Floor;

            value *= Math.Pow(10, precision);
            value = roundingFunction(value);
            double _result = value * Math.Pow(10, -1 * precision);

            return _result;
        }
    }

    public class Code128
    {
        public Code128() { }
        /// <summary>
        /// Encode la chaine en code128
        /// </summary>
        /// <param name="chaine">Chaine à transcrire</param>
        /// <returns></returns>
        public String Encode(String chaine)
        {
            int ind = 1;
            int checksum = 0;
            int mini;
            int dummy;
            bool tableB;
            String code128;
            int longueur;

            code128 = "";
            longueur = chaine.Length;


            if (longueur == 0)
            {
                Console.WriteLine("\n chaine vide");
            }
            else
            {
                for (ind = 0; ind < longueur; ind++)
                {
                    if ((chaine[ind] < 32) || (chaine[ind] > 126))
                    {
                        Console.WriteLine("\n chaine invalide");
                    }
                }
            }


            tableB = true;
            ind = 0;



            while (ind < longueur)
            {

                if (tableB == true)
                {
                    if ((ind == 0) || (ind + 3 == longueur - 1))
                    {
                        mini = 4;
                    }
                    else
                    {
                        mini = 6;
                    }

                    mini = mini - 1;

                    if ((ind + mini) <= longueur - 1)
                    {
                        while (mini >= 0)
                        {
                            if ((chaine[ind + mini] < 48) || (chaine[ind + mini] > 57))
                            {
                                Console.WriteLine("\n exit");
                                break;
                            }
                            mini = mini - 1;
                        }
                    }


                    if (mini < 0)
                    {
                        if (ind == 0)
                        {
                            code128 = Char.ToString((char)205);

                        }
                        else
                        {
                            code128 = code128 + Char.ToString((char)199);

                        }
                        tableB = false;
                    }
                    else
                    {

                        if (ind == 0)
                        {
                            code128 = Char.ToString((char)204);
                        }
                    }
                }

                if (tableB == false)
                {
                    mini = 2;
                    mini = mini - 1;
                    if (ind + mini < longueur)
                    {
                        while (mini >= 0)
                        {

                            if (((chaine[ind + mini]) < 48) || ((chaine[ind]) > 57))
                            {
                                break;
                            }
                            mini = mini - 1;
                        }
                    }
                    if (mini < 0)
                    {
                        dummy = Int32.Parse(chaine.Substring(ind, 2));

                        Console.WriteLine("\n  dummy ici : " + dummy);

                        if (dummy < 95)
                        {
                            dummy = dummy + 32;
                        }
                        else
                        {
                            dummy = dummy + 100;
                        }
                        code128 = code128 + (char)(dummy);

                        ind = ind + 2;
                    }
                    else
                    {
                        code128 = code128 + Char.ToString((char)200);
                        tableB = true;
                    }
                }
                if (tableB == true)
                {

                    code128 = code128 + chaine[ind];
                    ind = ind + 1;
                }
            }

            for (ind = 0; ind <= code128.Length - 1; ind++)
            {
                dummy = code128[ind];
                Console.WriteLine("\n  et voila dummy : " + dummy);
                if (dummy < 127)
                {
                    dummy = dummy - 32;
                }
                else
                {
                    dummy = dummy - 100;
                }
                if (ind == 0)
                {
                    checksum = dummy;
                }
                checksum = (checksum + (ind) * dummy) % 103;
            }

            if (checksum < 95)
            {
                checksum = checksum + 32;
            }
            else
            {
                checksum = checksum + 100;
            }
            code128 = code128 + Char.ToString((char)checksum)
                    + Char.ToString((char)206);

            return code128;
        }
    }        

    public static class PredicateBuilder
    {
        public static Expression<Func<T, bool>> True<T>() { return f => true; }
        public static Expression<Func<T, bool>> False<T>() { return f => false; }

        public static Expression<Func<T, bool>> Or<T>(this Expression<Func<T, bool>> expr1,
                                                            Expression<Func<T, bool>> expr2)
        {
            var invokedExpr = Expression.Invoke(expr2, expr1.Parameters.Cast<Expression>());
            return Expression.Lambda<Func<T, bool>>
                  (Expression.OrElse(expr1.Body, invokedExpr), expr1.Parameters);
        }

        public static Expression<Func<T, bool>> And<T>(this Expression<Func<T, bool>> expr1,
                                                             Expression<Func<T, bool>> expr2)
        {
            var invokedExpr = Expression.Invoke(expr2, expr1.Parameters.Cast<Expression>());
            return Expression.Lambda<Func<T, bool>>
                  (Expression.AndAlso(expr1.Body, invokedExpr), expr1.Parameters);
        }
    }
}
