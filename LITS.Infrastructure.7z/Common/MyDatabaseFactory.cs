﻿using System;
using System.Data.Common;
using System.Data;
using System.Data.Entity;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace LITS.Infrastructure.Common
{
    public static class MyDatabaseFactory
    {
        private static string _connectionString;
        public static string ConnectionString
        {
            get { return MyDatabaseFactory._connectionString; }
            set { MyDatabaseFactory._connectionString = value; }
        }

        private static string _databaseName;
        public static string DatabaseName
        {
            get { return MyDatabaseFactory._databaseName; }
            set { MyDatabaseFactory._databaseName = value; }
        }

        public static Microsoft.Practices.EnterpriseLibrary.Data.Database CreateDatabase()
        {
            string dbFactory = "System.Data.SqlClient";
            Microsoft.Practices.EnterpriseLibrary.Data.Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(ConnectionString))
                {
                    db = new GenericDatabase(ConnectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Microsoft.Practices.EnterpriseLibrary.Data.Database CreateDatabase(string connectionString)
        {
            string dbFactory = "System.Data.SqlClient";
            Microsoft.Practices.EnterpriseLibrary.Data.Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(connectionString))
                {
                    db = new GenericDatabase(connectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Microsoft.Practices.EnterpriseLibrary.Data.Database CreateDatabaseAccess()
        {
            string dbFactory = "System.Data.OleDb";
            Microsoft.Practices.EnterpriseLibrary.Data.Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(ConnectionString))
                {
                    db = new GenericDatabase(ConnectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Microsoft.Practices.EnterpriseLibrary.Data.Database CreateDatabaseAccess(string connectionString)
        {
            string dbFactory = "System.Data.OleDb";
            Microsoft.Practices.EnterpriseLibrary.Data.Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(connectionString))
                {
                    db = new GenericDatabase(connectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static bool TestConnection()
        {
            Microsoft.Practices.EnterpriseLibrary.Data.Database db = MyDatabaseFactory.CreateDatabase();
            try
            {
                DbConnection dbConnection = db.CreateConnection();
                dbConnection.Open();
                if (dbConnection.State == ConnectionState.Open)
                {
                    dbConnection.Close();
                    return true;
                }
                else
                {
                    dbConnection.Close();
                    return false;
                }
                return false;

            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool CheckConnectionADCS()
        {            
            using (var db = new Context.ADCSEntities())
            {
                try
                {
                    db.Database.Connection.Open();
                    if (db.Database.Connection.State == ConnectionState.Open)
                    {                        
                        db.Database.Connection.Close();
                        return true;
                    }

                    return false;
                }
                catch
                {
                    return false;
                }
            }
        }

        public static bool CheckConnectionLITS()
        {
            using (var db = new Context.LITSEntities())
            {
                try
                {
                    db.Database.Connection.Open();
                    if (db.Database.Connection.State == ConnectionState.Open)
                    {
                        db.Database.Connection.Close();
                        return true;
                    }

                    return false;
                }
                catch
                {
                    return false;
                }
            }
        }

        public static bool CheckConnectionLITSHISTORY()
        {
            using (var db = new Context.LITSHISTORYEntities())
            {
                try
                {
                    db.Database.Connection.Open();
                    if (db.Database.Connection.State == ConnectionState.Open)
                    {
                        db.Database.Connection.Close();
                        return true;
                    }

                    return false;
                }
                catch
                {
                    return false;
                }
            }
        }
    }
}
