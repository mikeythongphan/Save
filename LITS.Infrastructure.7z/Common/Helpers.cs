﻿using System;
using System.Collections.Generic;
using System.Data;
using Aspose.Cells;
using System.Drawing;
using System.Configuration;
using System.Net.Mail;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using System.Data.SqlClient;

namespace LITS.Infrastructure.Common
{
    public static class Helpers
    {
        #region Helpers

        /// <summary>
        /// 
        /// </summary>
        /// <param name="channel"></param>
        /// <returns></returns>
        public static bool IsOnlinePL(string channel)
        {
            if (!string.IsNullOrEmpty(channel))
                if (channel.StartsWith(EnumList.ExpressType.Online.ToString()))
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paymentType"></param>
        /// <returns></returns>
        public static bool IsSecuredPL(string paymentType)
        {
            if (!string.IsNullOrEmpty(paymentType))
                if (paymentType.StartsWith(EnumList.ExpressType.Secured.ToString()))
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="iOnline"></param>
        /// <returns></returns>
        public static bool VisibleOnlineFlag(int? iOnline)
        {
            if (iOnline != null)
                if (iOnline.Value == 1)
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="iSecured"></param>
        /// <returns></returns>
        public static bool VisibleSecuredFlag(int? iSecured)
        {
            if (iSecured != null)
                if (iSecured.Value == 1)
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="iFASG"></param>
        /// <returns></returns>
        public static bool VisibleFASG(int? iFASG)
        {
            if (iFASG != null)
                if (iFASG.Value == 1)
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="wb"></param>
        /// <param name="countSheet"></param>
        public static void ProtectWorkSheet(Aspose.Cells.Workbook wb, int countSheet)
        {
            for (int i = 0; i < countSheet; i++)
            {
                wb.Worksheets[i].Protect(Aspose.Cells.ProtectionType.Contents);
                wb.Worksheets[i].Protection.Password = "SYSTEM.NEVERUNPROTECTED";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workBook"></param>
        /// <param name="ds"></param>
        /// <param name="isNeedHeader"></param>
        /// <returns></returns>
        public static Workbook FillDataToWorkbook(Workbook workBook, DataSet ds, bool isNeedHeader)
        {
            Worksheet sheet = workBook.Worksheets[0];
            int rowIndex = 0;

            // Create header
            if (isNeedHeader)
            {
                for (int colIndex = 0; colIndex < ds.Tables[0].Columns.Count; colIndex++)
                {
                    sheet.Cells[rowIndex, colIndex].PutValue(ds.Tables[0].Columns[colIndex].ColumnName.ToString());
                }
                rowIndex++;
                SetBackgroundColorForRow(workBook, sheet, 0);
            }

            // Fill data row
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                for (int colIndex = 0; colIndex < ds.Tables[0].Columns.Count; colIndex++)
                {
                    sheet.Cells[rowIndex, colIndex].PutValue(row[colIndex]);
                }
                rowIndex++;
            }

            workBook.Worksheets[0].Copy(sheet);

            return workBook;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="wb"></param>
        /// <param name="sheet"></param>
        /// <param name="idxRow"></param>
        public static void SetBackgroundColorForRow(Workbook wb, Worksheet sheet, int idxRow)
        {
            Aspose.Cells.Style style = wb.Styles[1];

            style.BackgroundColor = Color.Gray;
            style.Font.Color = Color.White;
            style.Font.IsBold = true;
            style.Pattern = BackgroundType.Gray6;

            StyleFlag styleFlag = new StyleFlag();
            styleFlag.All = true;

            Row row = sheet.Cells.Rows[idxRow];
            row.ApplyStyle(style, styleFlag);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="totalMUE"></param>
        /// <returns></returns>
        public static bool IsCapTUE24xIncomeValid(decimal? totalMUE)
        {
            decimal capMUE = decimal.Parse(ConfigurationManager.AppSettings["CapMUEForIncome"]);
            if (totalMUE != null)
                if (totalMUE.Value <= capMUE)
                    return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nsg"></param>
        /// <param name="appStatus"></param>
        /// <returns></returns>
        public static bool IsNotCompletedNSGUnderwriter(int? nsg, int appStatus)
        {
            if (nsg == null || nsg == 0)
            {
                if (appStatus == (int)EnumList.ApplicationStatus.OSChecked || appStatus == (int)EnumList.ApplicationStatus.CIModified)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nsg"></param>
        /// <param name="appStatus"></param>
        /// <param name="teleStatus"></param>
        /// <returns></returns>
        public static bool IsNotCompletedNSGTele(int? nsg, int appStatus, string teleStatus)
        {
            if (nsg == null || nsg == 0)
            {
                if (appStatus == (int)EnumList.ApplicationStatus.OSChecked || appStatus == (int)EnumList.ApplicationStatus.CIModified)
                {
                    if (string.IsNullOrEmpty(teleStatus) || teleStatus == EnumList.TeleQueue.Tele_Modified.ToString())
                        return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isSale"></param>
        /// <param name="isCI"></param>
        /// <returns></returns>
        public static string GetRequeueLogType(bool isSale, bool isCI)
        {
            if (isSale)
                return EnumList.RequeueLogType.SENTBACK.ToString();

            if (isCI)
                return EnumList.RequeueLogType.REQUEUE.ToString();

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="teleStatus"></param>
        /// <param name="approvalStatus"></param>
        /// <returns></returns>
        public static bool IsCIAllowedToRecommend(string teleStatus, string approvalStatus)
        {
            if (teleStatus == EnumList.TeleQueue.Tele_Completed.ToString())
                return true;

            if (approvalStatus == EnumList.CRApproval.Rejected.ToString())
                return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="teleStatus"></param>
        /// <param name="approvalStatus"></param>
        /// <returns></returns>
        public static bool IsCIAllowedToAIPRecommend(string teleStatus, string approvalStatus)
        {
            if (teleStatus == EnumList.TeleQueue.Tele_Completed.ToString())
                return true;

            if (approvalStatus == EnumList.CRApproval.Approved.ToString())
                return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="status"></param>
        /// <param name="teleStatus"></param>
        /// <returns></returns>
        public static bool IsSaleNotAllowedToSubmitApplication(int status, string teleStatus)
        {
            if (status == (int)EnumList.ApplicationStatus.CISendBack &&
                (teleStatus == EnumList.TeleQueue.Tele_SentBack.ToString() || teleStatus == EnumList.TeleQueue.Tele_SCModified.ToString()))
            {
                if (teleStatus != EnumList.TeleQueue.Tele_Completed.ToString())
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Case must be rejected with code R08 with Investigation result is FRAUD
        /// </summary>
        /// <param name="investigationResult"></param>
        /// <returns></returns>
        public static bool IsFraudCaseForceToReject(string investigationResult)
        {
            if (investigationResult == EnumList.FraudInvestigationResult.Fraud.ToString())
                return true;

            return false;
        }

        /// <summary>
        /// In the case was rejected, NOT be allowed to use code R08
        /// </summary>
        /// <param name="investigationResult"></param>
        /// <returns></returns>
        public static bool IsFraudCaseUnavaiableToReject(string investigationResult, string rejectedCode)
        {
            if (investigationResult != EnumList.FraudInvestigationResult.Fraud.ToString() && rejectedCode.StartsWith("R08"))
                return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static T Min<T>(T first, T second)
        {
            if (Comparer<T>.Default.Compare(first, second) < 0)
                return first;
            return second;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static T Max<T>(T first, T second)
        {
            if (Comparer<T>.Default.Compare(first, second) > 0)
                return first;
            return second;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static bool IsLowerValue<T>(T first, T second)
        {
            if (Comparer<T>.Default.Compare(first, second) < 0)
                return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static bool IsLowerOrEqualToValue<T>(T first, T second)
        {
            if (Comparer<T>.Default.Compare(first, second) <= 0)
                return true;

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="propertyTrxPrice1"></param>
        /// <param name="propertyTrxPrice2"></param>
        /// <param name="propertyTrxPrice3"></param>
        /// <param name="propertyTrxPrice4"></param>
        /// <param name="propertyTrxPrice5"></param>
        /// <returns></returns>
        public static string WriteValuePropertyTrxPriceToLog(decimal? propertyTrxPrice1, decimal? propertyTrxPrice2, decimal? propertyTrxPrice3, decimal? propertyTrxPrice4, decimal? propertyTrxPrice5)
        {
            string result = (propertyTrxPrice1 != null ? propertyTrxPrice1.Value : 0) + Utilities.split +
                     (propertyTrxPrice2 != null ? propertyTrxPrice2.Value : 0) + Utilities.split +
                     (propertyTrxPrice3 != null ? propertyTrxPrice3.Value : 0) + Utilities.split +
                     (propertyTrxPrice4 != null ? propertyTrxPrice4.Value : 0) + Utilities.split +
                     (propertyTrxPrice5 != null ? propertyTrxPrice5.Value : 0);

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        public static double CalculateHours_TATNotUsed(DateTime? startTime, DateTime? endTime)
        {
            double hourTAT = 0;
            try
            {
                DateTime _startDate = DateTime.Parse(startTime.Value.ToShortDateString());
                DateTime _endDate = DateTime.Parse(endTime.Value.ToShortDateString());
                bool isOneDay = false;
                bool isHoliday = false;

                if (_endDate > _startDate)
                {
                    TimeSpan spanTime = endTime.Value.Subtract((DateTime)startTime);
                    hourTAT = spanTime.TotalHours;

                    DateTime d = startTime.Value;
                    while (d <= endTime.Value)
                    {
                        if (startTime.Value.DayOfWeek == DayOfWeek.Saturday)
                        {
                            if (endTime.Value.DayOfWeek != DayOfWeek.Saturday || endTime.Value.DayOfWeek != DayOfWeek.Sunday)
                            {

                            }
                        }
                    }

                    if (startTime.Value.DayOfWeek == DayOfWeek.Saturday)
                    {
                        if (endTime.Value.DayOfWeek != DayOfWeek.Saturday || endTime.Value.DayOfWeek != DayOfWeek.Sunday)
                        {

                        }
                    }
                    else
                    {
                        double _hoursAdded = Utilities.HoursAdded(startTime, endTime);

                        hourTAT = (hourTAT + _hoursAdded);
                        hourTAT = (hourTAT - Utilities.CutOffTime(startTime, endTime));
                        hourTAT = (hourTAT - Utilities.CutOffLunchTime(startTime, endTime));
                        hourTAT = (hourTAT - Utilities.CutOffPublicHolidays(startTime, endTime, isOneDay, out isHoliday));
                    }
                }
                else
                {
                    if (!Utilities.IsRangeCutOffTime(startTime, endTime))
                    {
                        TimeSpan spanTime = endTime.Value.Subtract((DateTime)startTime);
                        hourTAT = spanTime.TotalHours;

                        #region unused
                        /*double _hoursAdded = 0;
            DateTime _startDate = DateTime.Parse(startTime.Value.ToShortDateString());
            DateTime _endDate = DateTime.Parse(endTime.Value.ToShortDateString());
            if (_endDate > _startDate)
              _hoursAdded = HoursAdded(startTime, endTime);

            hourTAT = (hourTAT + _hoursAdded);*/
                        #endregion

                        isOneDay = true;
                        hourTAT = (hourTAT - Utilities.CutOffTime(startTime, endTime));
                        hourTAT = (hourTAT - Utilities.CutOffLunchTime(startTime, endTime));
                        hourTAT = (hourTAT - Utilities.CutOffPublicHolidays(startTime, endTime, isOneDay, out isHoliday));

                        if (isHoliday)
                            hourTAT = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
            return hourTAT;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static DataTable ConvertToDataTable<T>(System.Collections.Generic.IList<T> data)
        {
            System.ComponentModel.PropertyDescriptorCollection properties = System.ComponentModel.TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();

            foreach (System.ComponentModel.PropertyDescriptor prop in properties)
            {
                if (prop.Name == "ApplicationNo" || prop.Name == "Action" || prop.Name == "UserName" || prop.Name == "ActionDate")
                    table.Columns.Add(prop.Name, typeof(string));
            }

            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (System.ComponentModel.PropertyDescriptor prop in properties)
                {
                    if (prop.Name == "ApplicationNo" || prop.Name == "Action" || prop.Name == "UserName")
                        row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                    else if (prop.Name == "ActionDate")
                        row[prop.Name] = prop.GetValue(item) == DBNull.Value ? "" : Convert.ToDateTime(prop.GetValue(item)).ToString("MM/dd/yyyy HH:mm");
                }
                table.Rows.Add(row);
            }

            return table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        public static double CalculateHours_TAT(DateTime? startTime, DateTime? endTime)
        {
            double _tat = 0;

            int hourWorkingEnd = 0, minWorkingEnd = 0, hourWorkingStart = 0, minWorkingStart = 0;
            Utilities.GetInfoCutOffTime(out hourWorkingEnd, out minWorkingEnd, out hourWorkingStart, out minWorkingStart);

            DateTime _dtStart = DateTime.Parse(startTime.Value.ToShortDateString());
            DateTime _dtEnd = DateTime.Parse(endTime.Value.ToShortDateString());

            if (_dtEnd > _dtStart)
            {
                _tat = TATMoreThanOneDay(startTime.Value, endTime.Value, _dtStart, _dtEnd, hourWorkingStart, minWorkingStart, hourWorkingEnd, minWorkingEnd);
            }
            else
            {
                _tat = TATInOneDay(startTime.Value, endTime.Value, _dtStart, hourWorkingStart, minWorkingStart, hourWorkingEnd, minWorkingEnd);
            }

            return _tat;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="_dtStart"></param>
        /// <param name="_dtEnd"></param>
        /// <param name="hourWorkingStart"></param>
        /// <param name="minWorkingStart"></param>
        /// <param name="hourWorkingEnd"></param>
        /// <param name="minWorkingEnd"></param>
        /// <returns></returns>
        private static double TATMoreThanOneDay(DateTime startTime, DateTime endTime, DateTime _dtStart, DateTime _dtEnd,
        int hourWorkingStart, int minWorkingStart, int hourWorkingEnd, int minWorkingEnd)
        {
            double _resultTAT = 0;

            DateTime _start = _dtStart;
            DateTime _datetime = new DateTime();

            TimeSpan _spanTime = new TimeSpan();
            DateTime workingStart = new DateTime(), workingEnd = new DateTime();

            while (_dtStart <= _dtEnd)
            {
                if (!DateIsHolidays(_dtStart))
                {
                    if (!Utilities.IsWeekend(_dtStart))
                    {
                        if (_dtStart == _start || _dtStart == _dtEnd)
                        {
                            if (_dtStart == _start)
                                _datetime = startTime;
                            else if (_dtStart == _dtEnd)
                                _datetime = endTime;

                            workingStart = new DateTime(_datetime.Year, _datetime.Month, _datetime.Day, hourWorkingStart, minWorkingStart, 0);
                            workingEnd = new DateTime(_datetime.Year, _datetime.Month, _datetime.Day, hourWorkingEnd, minWorkingEnd, 0);

                            if (_dtStart == _dtEnd)
                            {
                                if (Utilities.IsWorkingTime(_datetime))
                                {
                                    _spanTime = _datetime.Subtract(workingStart);
                                    _resultTAT = (_resultTAT + _spanTime.TotalHours);
                                }
                                else
                                {
                                    if (Utilities.IsOutOfWorkingTimeEnd(_datetime))
                                    {
                                        _spanTime = workingEnd.Subtract(workingStart);
                                        _resultTAT = (_resultTAT + _spanTime.TotalHours);
                                    }
                                }
                            }
                            else
                            {
                                if (Utilities.IsWorkingTime(_datetime))
                                {
                                    _spanTime = workingEnd.Subtract(_datetime);
                                    _resultTAT = (_resultTAT + _spanTime.TotalHours);
                                }
                                else
                                {
                                    if (Utilities.IsOutOfWorkingTimeStart(_datetime))
                                    {
                                        _spanTime = workingEnd.Subtract(workingStart);
                                        _resultTAT = (_resultTAT + _spanTime.TotalHours);
                                    }
                                }
                            }
                        }
                        else
                        {
                            _resultTAT = (_resultTAT + (24 - Utilities.GetCutOffTime()));
                        }
                    }
                }

                _dtStart = _dtStart.AddDays(1);
            }

            return _resultTAT;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="shortDateStart"></param>
        /// <param name="hourWorkingStart"></param>
        /// <param name="minWorkingStart"></param>
        /// <param name="hourWorkingEnd"></param>
        /// <param name="minWorkingEnd"></param>
        /// <returns></returns>
        private static double TATInOneDay(DateTime startTime, DateTime endTime, DateTime shortDateStart,
        int hourWorkingStart, int minWorkingStart, int hourWorkingEnd, int minWorkingEnd)
        {
            double _resultTAT = 0;

            TimeSpan _spanTime = new TimeSpan();
            DateTime workingStart = new DateTime(), workingEnd = new DateTime();

            if (!DateIsHolidays(shortDateStart))
            {
                if (!Utilities.IsWeekend(shortDateStart))
                {
                    if (Utilities.IsWorkingTime(startTime))
                    {
                        if (Utilities.IsWorkingTime(endTime))
                        {
                            _spanTime = endTime.Subtract(startTime);
                        }
                        else
                        {
                            workingEnd = new DateTime(endTime.Year, endTime.Month, endTime.Day, hourWorkingEnd, minWorkingEnd, 0);
                            _spanTime = workingEnd.Subtract(startTime);
                        }
                    }
                    else
                    {
                        if (Utilities.IsOutOfWorkingTimeStart(startTime))
                        {
                            if (Utilities.IsWorkingTime(endTime))
                            {
                                workingStart = new DateTime(startTime.Year, startTime.Month, startTime.Day, hourWorkingStart, minWorkingStart, 0);
                                _spanTime = endTime.Subtract(workingStart);
                            }
                            else if (Utilities.IsOutOfWorkingTimeEnd(endTime))
                            {
                                workingEnd = new DateTime(endTime.Year, endTime.Month, endTime.Day, hourWorkingEnd, minWorkingEnd, 0);
                                workingStart = new DateTime(startTime.Year, startTime.Month, startTime.Day, hourWorkingStart, minWorkingStart, 0);
                                _spanTime = workingEnd.Subtract(workingStart);

                            }
                        }
                    }
                    _resultTAT = _spanTime.TotalHours;
                }
            }

            return _resultTAT;
        }

        public static bool DateIsHolidays(DateTime date)
        {
            //if (HolidayService.DateIsHoliday(date))
            //    return true;
            return false;
        }

        #endregion
    }

    public class CommonHelpers
    {

        public static void NotifyEmail(string receiptListName, string section, string message)
        {
            SmtpClient smtpClient;
            MailMessage mailMsg = new MailMessage();

            try
            {
                string[] toEmails = ConfigurationManager.AppSettings["NotifyEmail"].Split(';');

                if (toEmails.Length <= 0 || ConfigurationManager.AppSettings["NotifyEmail"] == null
                  || ConfigurationManager.AppSettings["NotifyEmail"].ToString() == "")
                {
                    //PMT_CONFIG config = PMT_CONFIGService.GetByName(receiptListName,
                    //  EnumList.ConfigurationType.PRD.ToString());

                    //if (config == null)
                    //    return;

                    //if (!string.IsNullOrEmpty(config.ConfigValue))
                    //{
                    //    toEmails = config.ConfigValue.Split(';');
                    //}
                    //else
                    //{
                    //    if (!string.IsNullOrEmpty(config.ConfigBKValue))
                    //    {
                    //        toEmails = config.ConfigBKValue.Split(';');
                    //    }

                    //    return;
                    //}
                }

                // To
                foreach (string s in toEmails)
                {
                    if (s != "")
                        mailMsg.To.Add(s.Trim());
                }

                if (mailMsg.To.Count > 0)
                {

                    // From
                    MailAddress mailAddress = new MailAddress("PMTGWT@sc.com");
                    mailMsg.From = mailAddress;

                    // Subject and Body
                    mailMsg.Subject = string.Format("PMTGWT Notification - {0}", section);
                    mailMsg.Body = message;

                    smtpClient = new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"]);

                    smtpClient.UseDefaultCredentials = true;
                    smtpClient.Send(mailMsg);
                }

            }
            catch (Exception ex)
            {
                //Logger.Error("Utilities.CommonHelpers::NotifyEmail", ex);
                //ExLog.SaveExceptionLogger(ex.Message, ex.StackTrace, "SCB.PMTGWT.Utils.Helpers", "Utilities.CommonHelpers::NotifyEmail", null, 3);

                try
                {
                    if (mailMsg.To.Count > 0)
                    {
                        smtpClient = new SmtpClient(ConfigurationManager.AppSettings["SMTPServerBK"]);
                        smtpClient.Send(mailMsg);
                    }
                }
                catch (Exception ext)
                {

                    //Logger.Error("Utilities.CommonHelpers::NotifyEmail", ext);
                    //ExLog.SaveExceptionLogger(ext.Message, ext.StackTrace, "SCB.PMTGWT.Utils.Helpers", "Utilities.CommonHelpers::NotifyEmail", null, 3);
                }
            }
        }

        public static void NotifyEmailWithAttach(string receiptListName, string section, string message, string[] attachFiles)
        {
            SmtpClient smtpClient;
            MailMessage mailMsg = new MailMessage();

            try
            {
                string[] toEmails = null;

                //PMT_CONFIG config = PMT_CONFIGService.GetByName(receiptListName,
                //  EnumList.ConfigurationType.PRD.ToString());

                //if (config == null)
                //{
                //    toEmails = ConfigurationManager.AppSettings["NotifyEmail"].Split(';');
                //}

                //if (!string.IsNullOrEmpty(config.ConfigValue))
                //{
                //    toEmails = config.ConfigValue.Split(';');
                //}
                //else
                //{
                //    if (!string.IsNullOrEmpty(config.ConfigBKValue))
                //    {
                //        toEmails = config.ConfigBKValue.Split(';');
                //    }

                //    return;
                //}

                if (toEmails == null || toEmails.Length == 0)
                    return;

                // To
                foreach (string s in toEmails)
                {
                    if (s != "")
                        mailMsg.To.Add(s.Trim());
                }

                if (mailMsg.To.Count > 0)
                {

                    // From
                    MailAddress mailAddress = new MailAddress("PMTGWT@sc.com");
                    mailMsg.From = mailAddress;

                    // Subject and Body
                    mailMsg.Subject = string.Format("PMTGWT Notification - {0}", section);
                    mailMsg.Body = message;

                    foreach (string file in attachFiles)
                    {
                        if (File.Exists(file.Trim()))
                            mailMsg.Attachments.Add(new Attachment(file.Trim()));
                    }

                    smtpClient = new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"]);

                    smtpClient.UseDefaultCredentials = true;
                    smtpClient.Send(mailMsg);
                }

            }
            catch (Exception ex)
            {
                //Logger.Error("Utilities.CommonHelpers::NotifyEmail", ex);

                try
                {
                    if (mailMsg.To.Count > 0)
                    {
                        smtpClient = new SmtpClient(ConfigurationManager.AppSettings["SMTPServerBK"]);
                        smtpClient.Send(mailMsg);
                    }
                }
                catch (Exception ext)
                {

                    //Logger.Error("Utilities.CommonHelpers::NotifyEmail", ext);
                    //ExLog.SaveExceptionLogger(ext.Message, ext.StackTrace, "SCB.PMTGWT.Utils.Helpers", "Utilities.CommonHelpers::NotifyEmail", null, 3);
                }
            }
        }

        public static void BulkCopyToImport(DataTable dt, object[] mappings, string tableName)
        {
            try
            {
                DatabaseConfigurationView view = new DatabaseConfigurationView(new SystemConfigurationSource());
                ConnectionStringSettings settings = view.GetConnectionStringSettings(view.DefaultName);

                using (SqlConnection destinationConnection = new SqlConnection(settings.ConnectionString))
                {
                    // open the connection
                    destinationConnection.Open();
                    using (SqlBulkCopy bulkCopy =
                                new SqlBulkCopy(settings.ConnectionString))
                    {
                        bulkCopy.BulkCopyTimeout = 3600000;
                        bulkCopy.BatchSize = 500;

                        // column mappings
                        if (mappings != null)
                        {
                            for (int i = 0; i < mappings.Length; i++)
                            {
                                SqlBulkCopyColumnMapping mapping = (SqlBulkCopyColumnMapping)mappings[i];
                                bulkCopy.ColumnMappings.Add(mapping);
                            }
                        }

                        bulkCopy.DestinationTableName = tableName;
                        bulkCopy.WriteToServer(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                //Logger.Error(string.Format("Utilities.CommonHelpers::BulkCopyToImport{0}", tableName), ex);
                //ExLog.SaveExceptionLogger(ex.Message, ex.StackTrace, "SCB.PMTGWT.Utils.Helpers", string.Format("Utilities.CommonHelpers::BulkCopyToImport{0}", tableName), null, 3);
                //throw;
            }
        }

        public static string FindValueByKey(IDictionary<string, string> dictionary, string key)
        {
            if (dictionary == null)
                return null;

            foreach (KeyValuePair<string, string> pair in dictionary)
                if (key.Equals(pair.Key)) return pair.Value;

            return null;
        }

        public static void SaveActionLog(string paymentID, string messageID, string action, string actionBy)
        {
            string logAction = ConfigurationManager.AppSettings["LogAction"];
            if (logAction == "1")
            {
                //PMT_ACTION p = new PMT_ACTION();
                //p.PMT_ID = paymentID;
                //p.MSG_ID = messageID;
                //p.Action = action;
                //p.ActionBy = actionBy;
                //p.ActionDate = DateTime.Now;

                //PMT_ACTIONService.CreatePMT_ACTION(p);
            }
        }
    }
}
