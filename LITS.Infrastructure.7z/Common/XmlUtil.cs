﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web.UI.WebControls;

namespace LITS.Infrastructure.Common
{
    public class XmlUtil
    {
        private XmlDataSource m_xmlData;

        #region XML

        public XmlDataSource GetXmlDataSource(string usDataFile, string xmlPath)
        {
            XmlDataSource dsData = new XmlDataSource();
            dsData.DataFile = usDataFile;
            dsData.XPath = xmlPath;
            return dsData;
        }

        public XmlDataSource GetEmailTemplateXmlData(string xmlPath)
        {
            return GetXmlDataSource("~/App_Data/MailTemplate.xml", xmlPath);
        }

        public XmlDataSource GetStatusXmlData(string xmlPath)
        {
            return GetXmlDataSource("~/App_Data/ProcessStatus.xml", xmlPath);
        }

        public string GetStatusItem(object status)
        {
            m_xmlData = GetStatusXmlData("Items/ProcessStatus/Status");

            XmlNode node = m_xmlData.GetXmlDocument().SelectSingleNode("Items/ProcessStatus/Status" + "[@Id='" + status.ToString() + "']");
            if (node != null)
                return node.Attributes["Value"].Value;
            else
                return "";
        }

        #endregion
    }

    public class XmlSerializeHelper
    {
        public static string Serialize<T>(T obj)
        {
            return Serialize<T>(obj, Encoding.UTF8);
        }

        /// <summary>
        /// Serialize
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string Serialize<T>(T obj, Encoding encoding)
        {
            try
            {

                if (obj == null)
                    throw new ArgumentNullException("obj");

                var ser = new XmlSerializer(obj.GetType());
                using (var ms = new MemoryStream())
                {
                    using (var writer = new XmlTextWriter(ms, encoding))
                    {
                        writer.Formatting = Formatting.Indented;
                        ser.Serialize(writer, obj);
                    }
                    var xml = encoding.GetString(ms.ToArray());
                    xml = xml.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
                    xml = xml.Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
                    return xml;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// DeSerialize
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xml"></param>
        /// <returns></returns>
        public static T DeSerialize<T>(string xml)
            where T : new()
        {
            return DeSerialize<T>(xml, Encoding.UTF8);
        }

        /// <summary>
        /// DeSerialize
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xml"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static T DeSerialize<T>(string xml, Encoding encoding)
            where T : new()
        {
            try
            {
                var mySerializer = new XmlSerializer(typeof(T));
                using (var ms = new MemoryStream(encoding.GetBytes(xml)))
                {
                    using (var sr = new StreamReader(ms, encoding))
                    {
                        return (T)mySerializer.Deserialize(sr);
                    }
                }
            }
            catch (Exception e)
            {
                return default(T);
            }

        }
    }
}
