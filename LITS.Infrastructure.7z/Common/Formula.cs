﻿using System;
using System.Collections.Generic;
using System.IO;
using Aspose.Cells;

namespace LITS.Infrastructure.Common
{
    public static class Formula
    {
        public static IncomeResults CaculateIncome(string customerName, decimal baseSalary, decimal basicAllowance,
          decimal periodOfSubmittedBS, List<IncomeCaculation> inputIncomeList, List<BonusCaculation> inputBonusList,
          string templateFile, string outputFile, bool isSavedFile)
        {
            IncomeResults incomeResults = new IncomeResults();
            try
            {
                if (File.Exists(templateFile))
                {
                    File.Copy(templateFile, outputFile);
                }

                Workbook workBook = new Workbook(outputFile);

                Worksheet sheet = workBook.Worksheets[0];

                IncomeInputValue(sheet, customerName, baseSalary, basicAllowance, periodOfSubmittedBS, inputIncomeList, inputBonusList);

                workBook.CalculateFormula();

                string n9 = sheet.Cells["N9"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N9"].Value.ToString() : "0";
                string n43 = sheet.Cells["N43"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N43"].Value.ToString() : "0";
                string n50 = sheet.Cells["N50"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N50"].Value.ToString() : "0";
                string n51 = sheet.Cells["N51"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N51"].Value.ToString() : "0";

                #region Calculate Performance Bonus
                string n18 = sheet.Cells["N18"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N18"].Value.ToString() : "0";
                string n25 = sheet.Cells["N25"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N25"].Value.ToString() : "0";
                string n29 = sheet.Cells["N29"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N29"].Value.ToString() : "0";
                string n33 = sheet.Cells["N33"].Value.ToString() != "#DIV/0!" ? sheet.Cells["N33"].Value.ToString() : "0";
                decimal performanceBonus = decimal.Parse(n18) + decimal.Parse(n25) + decimal.Parse(n29) + decimal.Parse(n33);
                #endregion

                incomeResults.FixedIncomeBiaBS = Math.Round(decimal.Parse(n9), 0);
                incomeResults.TotalMonthlyIncomeViaBS = Math.Round(decimal.Parse(n43), 0);
                incomeResults.EligibleFixedIncomeLC = Math.Round(decimal.Parse(n50), 0);
                incomeResults.FinalIncome = Math.Round(decimal.Parse(n51), 0);
                incomeResults.PerformanceBonus = Math.Round(performanceBonus, 0);

                if (isSavedFile)
                {
                    workBook.Save(outputFile, SaveFormat.Xlsx);

                    //zip archive file
                    ZipUtil.ZipFile(outputFile, outputFile + ".zip", null);

                    incomeResults.FileName = outputFile + ".zip";
                }

                File.Delete(outputFile);
            }
            catch (Exception ex)
            {
            }

            return incomeResults;
        }

        public static void IncomeInputValue(Worksheet sheet, string customerName, decimal baseSalary,
        decimal basicAllowance, decimal periodOfSubmittedBS, List<IncomeCaculation> inputIncomeList, List<BonusCaculation> inputBonusList)
        {
            try
            {
                if (sheet != null && inputIncomeList != null)
                {
                    sheet.Cells["C2"].PutValue(customerName);
                    if (periodOfSubmittedBS != -1) sheet.Cells["C3"].PutValue(periodOfSubmittedBS);
                    sheet.Cells["N48"].PutValue(baseSalary);
                    sheet.Cells["N49"].PutValue(basicAllowance);

                    #region Input Income List
                    for (int i = 0; i < inputIncomeList.Count; i++)
                    {
                        int count = i + 7;
                        if (i == inputIncomeList[i].Monthly - 1)
                        {
                            sheet.Cells["C" + count.ToString()].PutValue(inputIncomeList[i].FirstTime);
                            sheet.Cells["D" + count.ToString()].PutValue(inputIncomeList[i].SecondTime);
                            sheet.Cells["E" + count.ToString()].PutValue(inputIncomeList[i].ThirdTime);
                            sheet.Cells["I" + count.ToString()].PutValue(inputIncomeList[i].InputVerification);
                        }
                    }
                    #endregion

                    #region Input Bonus List
                    for (int i = 0; i < inputBonusList.Count; i++)
                    {
                        if (inputBonusList[i].BonusType == "Variable Monthly M-1")
                        {
                            sheet.Cells["C16"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D16"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Variable Monthly M-2")
                        {
                            sheet.Cells["C17"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D17"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Variable Monthly M-3")
                        {
                            sheet.Cells["C18"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D18"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Variable Monthly M-4")
                        {
                            sheet.Cells["C19"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D19"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Variable Monthly M-5")
                        {
                            sheet.Cells["C20"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D20"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Variable Monthly M-6")
                        {
                            sheet.Cells["C21"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D21"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Others Variable M-1")
                        {
                            sheet.Cells["C23"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D23"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Others Variable M-2")
                        {
                            sheet.Cells["C24"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D24"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Others Variable M-3")
                        {
                            sheet.Cells["C25"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D25"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Quaterly bonus 1"
                          || inputBonusList[i].BonusType == "Quaterly bonus")
                        {
                            sheet.Cells["C27"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D27"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Quaterly bonus 2")
                        {
                            sheet.Cells["C28"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D28"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Half-year bonus")
                        {
                            sheet.Cells["C29"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D29"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Lunar New year")
                        {
                            sheet.Cells["C31"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D31"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Western New Year")
                        {
                            sheet.Cells["C32"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D32"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Independent day")
                        {
                            sheet.Cells["C33"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D33"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Re-union day")
                        {
                            sheet.Cells["C34"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D34"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "Annual Bonus")
                        {
                            sheet.Cells["C35"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D35"].PutValue(inputBonusList[i].Bonus2);
                        }
                        else if (inputBonusList[i].BonusType == "13th salary")
                        {
                            sheet.Cells["C37"].PutValue(inputBonusList[i].Bonus1);
                            sheet.Cells["D37"].PutValue(inputBonusList[i].Bonus2);
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
            }
        }

        public static void CleanUpIncomeFiles(string path2Clean, string appNo)
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(path2Clean);
                foreach (FileInfo f in di.GetFiles(string.Format("IncomeCaculation_{0}*.xls.zip", appNo)))
                {
                    f.Delete();
                }
            }
            catch (Exception ex)
            {
            }
        }

        public static decimal CalculateCCF13EMICard(string isAutoCalEMI, string emi, string outStanding, decimal emiCardValue)
        {
            decimal result = 0;
            try
            {
                if (!bool.Parse(isAutoCalEMI))
                    result = decimal.Parse(emi);
                else
                {
                    decimal tmp = (decimal.Parse(outStanding) * emiCardValue) / 100;
                    result = Math.Round(decimal.Parse(tmp.ToString()));
                }
            }
            catch (Exception ex)
            {
            }

            return result;
        }

    }

    public class IncomeCaculation
    {
        private decimal? monthly;
        public decimal? Monthly
        {
            get { return monthly; }
            set { monthly = value; }
        }

        //C7-C12
        private decimal firstTime = 0;
        public decimal FirstTime
        {
            get { return firstTime; }
            set { firstTime = value; }
        }

        private decimal secondTime = 0;
        public decimal SecondTime
        {
            get { return secondTime; }
            set { secondTime = value; }
        }

        private decimal thirdTime = 0;
        public decimal ThirdTime
        {
            get { return thirdTime; }
            set { thirdTime = value; }
        }

        private string inputVerification = null;
        public string InputVerification
        {
            get { return inputVerification; }
            set { inputVerification = value; }
        }

    }

    public class BonusCaculation
    {
        string bonusType;
        public string BonusType
        {
            get { return bonusType; }
            set { bonusType = value; }
        }

        //C16-C18
        private decimal bonus1 = 0;
        public decimal Bonus1
        {
            get { return bonus1; }
            set { bonus1 = value; }
        }

        private decimal bonus2 = 0;
        public decimal Bonus2
        {
            get { return bonus2; }
            set { bonus2 = value; }
        }

        //B33
        private decimal grossSalary = 0;
        public decimal GrossSalary
        {
            get { return grossSalary; }
            set { grossSalary = value; }
        }
    }

    public class IncomeResults
    {
        private decimal performanceBonus = 0;
        public decimal PerformanceBonus
        {
            get { return performanceBonus; }
            set { performanceBonus = value; }
        }

        //private decimal monthlyIncome = 0;
        //public decimal MonthlyIncome
        //{
        //  get { return monthlyIncome; }
        //  set { monthlyIncome = value; }
        //}

        private decimal guaranteedBonusIncome = 0;
        public decimal GuaranteedBonusIncome
        {
            get { return guaranteedBonusIncome; }
            set { guaranteedBonusIncome = value; }
        }

        //private decimal totalIncome = 0;
        //public decimal TotalIncome
        //{
        //  get { return totalIncome; }
        //  set { totalIncome = value; }
        //}

        //O33
        private decimal netSalary = 0;
        public decimal NetSalary
        {
            get { return netSalary; }
            set { netSalary = value; }
        }

        private string fileName = "";
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }

        private decimal eligibleFixedIncomeLC = 0;
        public decimal EligibleFixedIncomeLC
        {
            get { return eligibleFixedIncomeLC; }
            set { eligibleFixedIncomeLC = value; }
        }

        private decimal fixedIncomeBiaBS = 0;
        public decimal FixedIncomeBiaBS
        {
            get { return fixedIncomeBiaBS; }
            set { fixedIncomeBiaBS = value; }
        }

        private decimal totalMonthlyIncomeViaBS = 0;
        public decimal TotalMonthlyIncomeViaBS
        {
            get { return totalMonthlyIncomeViaBS; }
            set { totalMonthlyIncomeViaBS = value; }
        }

        private decimal finalIncome = 0;
        public decimal FinalIncome
        {
            get { return finalIncome; }
            set { finalIncome = value; }
        }
    }
}
