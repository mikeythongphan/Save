﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using System.Configuration;

namespace LITS.Infrastructure.Security
{
    public static class LDAP
    {
        public static string CheckingLDAP = ConfigurationManager.AppSettings["CheckingLDAP"];

        #region GetInfoLDAP

        public enum objectClass { user, group, computer }

        /// <summary>
        /// Get Full Name From LDAP
        /// </summary>
        /// <param name="objectCls">objectClass</param>
        /// <param name="objectName">string</param>
        /// <returns>string</returns>
        public static string GetFullNameFromLDAP(objectClass objectCls, string objectName)
        {
            string displayName = string.Empty;

            try
            {
                if (CheckingLDAP == "1")
                {
                    DirectoryEntry entry = new DirectoryEntry("LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net");
                    DirectorySearcher mySearcher = new DirectorySearcher(entry);

                    switch (objectCls)
                    {
                        case objectClass.user:
                            mySearcher.Filter = "(&(objectClass=user)(|(cn=" + objectName + ")))";
                            break;
                        case objectClass.group:
                            mySearcher.Filter = "(&(objectClass=group)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                            break;
                        case objectClass.computer:
                            mySearcher.Filter = "(&(objectClass=computer)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                            break;
                    }
                    SearchResult result = mySearcher.FindOne();

                    if (result == null)
                    {
                        string err = "unable to locate the displayName for the object " + objectName + " in the LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net domain";
                        return null;
                    }

                    DirectoryEntry directoryObject = result.GetDirectoryEntry();

                    #region GetDataLDAP

                    //string name = "LDAP://" + directoryObject.Properties["givenName"].Value;
                    //name = name.Replace("LDAP://", "");

                    displayName = "LDAP://" + directoryObject.Properties["displayName"].Value;
                    displayName = displayName.Replace("LDAP://", "");

                    #endregion

                    entry.Close();
                    entry.Dispose();
                    mySearcher.Dispose();
                }
            }
            catch (Exception ex)
            { }
            return displayName;
        }

        /// <summary>
        /// Get Email From LDAP
        /// </summary>
        /// <param name="objectCls">objectClass</param>
        /// <param name="objectName">string</param>
        /// <returns>string</returns>
        public static string GetEmailFromLDAP(objectClass objectCls, string objectName)
        {
            string email = string.Empty;
            try
            {
                if (CheckingLDAP == "1")
                {
                    DirectoryEntry entry = new DirectoryEntry("LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net");
                    DirectorySearcher mySearcher = new DirectorySearcher(entry);

                    switch (objectCls)
                    {
                        case objectClass.user:
                            mySearcher.Filter = "(&(objectClass=user)(|(cn=" + objectName + ")))";
                            break;
                        case objectClass.group:
                            mySearcher.Filter = "(&(objectClass=group)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                            break;
                        case objectClass.computer:
                            mySearcher.Filter = "(&(objectClass=computer)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                            break;
                    }
                    SearchResult result = mySearcher.FindOne();

                    if (result == null)
                    {
                        string err = "unable to locate the displayName for the object " + objectName + " in the LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net domain";
                        return null;
                    }

                    DirectoryEntry directoryObject = result.GetDirectoryEntry();

                    #region GetDataLDAP

                    email = "LDAP://" + directoryObject.Properties["mail"].Value;
                    email = email.Replace("LDAP://", "");

                    #endregion

                    entry.Close();
                    entry.Dispose();
                    mySearcher.Dispose();
                }
            }
            catch (Exception ex)
            {
                //Logger.Error("ERROR::GetEmailFromLDAP", ex);
            }
            return email;
        }

        public static bool LoginByLDAP(string username, string password)
        {
            bool IsLogin = false;
            DirectoryEntry entry;
            try
            {
                entry = new DirectoryEntry("LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net", username, password);
                string name = entry.Name;
                if (name != null)
                {
                    IsLogin = true;
                }
            }
            catch (Exception ex)
            {
                //Logging.LogHelper.WriteLogError("LoginByLDAP::Error:", ex);
                IsLogin = false;
            }

            return IsLogin;
        }
        #endregion
    }

    public class LDAPUtilities
    {
        public enum objectClass { user, group, computer }
        public static PersonalInformation GetPersonalInformationFromLDAP(objectClass objectCls, string objectName)
        {
            PersonalInformation personal = new PersonalInformation();
            try
            {
                string resultOut = string.Empty;
                DirectoryEntry entry = new DirectoryEntry("LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net");
                DirectorySearcher mySearcher = new DirectorySearcher(entry);

                switch (objectCls)
                {
                    case objectClass.user:
                        mySearcher.Filter = "(&(objectClass=user)(|(cn=" + objectName + ")))";
                        break;
                    case objectClass.group:
                        mySearcher.Filter = "(&(objectClass=group)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                        break;
                    case objectClass.computer:
                        mySearcher.Filter = "(&(objectClass=computer)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                        break;
                }
                SearchResult result = mySearcher.FindOne();

                if (result == null)
                {
                    string err = "unable to locate the displayName for the object " + objectName + " in the LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net domain";
                    return null;
                }

                DirectoryEntry directoryObject = result.GetDirectoryEntry();

                #region GetDataLDAP

                string pid = "LDAP://" + directoryObject.Properties["name"].Value;
                string name = "LDAP://" + directoryObject.Properties["givenName"].Value;
                string displayName = "LDAP://" + directoryObject.Properties["displayName"].Value;
                string mobile = "LDAP://" + directoryObject.Properties["mobile"].Value;
                string tel = "LDAP://" + directoryObject.Properties["telephoneNumber"].Value;
                string ext = "LDAP://" + directoryObject.Properties["ipPhone"].Value;
                string email = "LDAP://" + directoryObject.Properties["mail"].Value;
                string title = "LDAP://" + directoryObject.Properties["title"].Value;
                string location = "LDAP://" + directoryObject.Properties["physicalDeliveryOfficeName"].Value;
                string country = "LDAP://" + directoryObject.Properties["co"].Value;
                string dept = "LDAP://" + directoryObject.Properties["department"].Value;
                //string memberOf = "LDAP://" + directoryObject.Properties["memberOf"].Value;
                string manager = "LDAP://" + directoryObject.Properties["manager"].Value;

                pid = pid.Replace("LDAP://", "");
                name = name.Replace("LDAP://", "");
                displayName = displayName.Replace("LDAP://", "");
                mobile = mobile.Replace("LDAP://", "");
                tel = tel.Replace("LDAP://", "");
                ext = ext.Replace("LDAP://", "");
                email = email.Replace("LDAP://", "");
                title = title.Replace("LDAP://", "");
                location = location.Replace("LDAP://", "");
                country = country.Replace("LDAP://", "");
                dept = dept.Replace("LDAP://", "");
                //memberOf = memberOf.Replace("LDAP://", "");
                manager = manager.Replace("LDAP://", "");

                #endregion

                #region AddToObject

                country = country.ToUpper();
                personal.PID = pid;
                personal.FullName = displayName;
                personal.Mobile = mobile;
                personal.Telephone = tel;
                personal.Ext = ext;
                personal.Email = email;
                personal.Title = title;
                personal.Location = location;
                personal.Country = country;
                personal.Dept = dept;
                //personal.MemberOf = memberOf;

                if (manager.Length > 9)
                    personal.Manager = manager.Substring(3, 7);


                #endregion

                entry.Close();
                entry.Dispose();
                mySearcher.Dispose();
            }
            catch (Exception ex)
            {
                return null;
            }
            return personal;
        }

        public static string GetFullNameFromLDAP(objectClass objectCls, string objectName)
        {
            string resultOut = string.Empty;
            DirectoryEntry entry = new DirectoryEntry("LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net");
            DirectorySearcher mySearcher = new DirectorySearcher(entry);

            try
            {
                switch (objectCls)
                {
                    case objectClass.user:
                        mySearcher.Filter = "(&(objectClass=user)(|(cn=" + objectName + ")))";
                        break;
                    case objectClass.group:
                        mySearcher.Filter = "(&(objectClass=group)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                        break;
                    case objectClass.computer:
                        mySearcher.Filter = "(&(objectClass=computer)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                        break;
                }
                SearchResult result = mySearcher.FindOne();

                if (result == null)
                {
                    string err = "unable to locate the displayName for the object " + objectName + " in the LDAP://zone1.scb.net/DC=zone1,DC=scb,DC=net domain";
                    return null;
                }

                DirectoryEntry directoryObject = result.GetDirectoryEntry();

                #region GetDataLDAP

                string displayName = "LDAP://" + directoryObject.Properties["displayName"].Value;
                displayName = displayName.Replace("LDAP://", "");

                #endregion

                entry.Close();
                entry.Dispose();
                mySearcher.Dispose();

                return displayName;
            }
            catch (Exception ex)
            {
            }
            return null;
        }
    }

    public class PersonalInformation
    {
        private string pid = string.Empty;
        private string fullName = string.Empty;
        private string mobile = string.Empty;
        private string email = string.Empty;
        private string tel = string.Empty;
        private string ext = string.Empty;
        private string location = string.Empty;
        private string title = string.Empty;
        private string country = string.Empty;
        private string dept = string.Empty;
        private string manager = string.Empty;

        public string PID
        {
            get { return pid; }
            set { pid = value; }
        }

        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }

        public string Mobile
        {
            get { return mobile; }
            set { mobile = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Telephone
        {
            get { return tel; }
            set { tel = value; }
        }

        public string Ext
        {
            get { return ext; }
            set { ext = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public string Dept
        {
            get { return dept; }
            set { dept = value; }
        }

        public string Manager
        {
            get { return manager; }
            set { manager = value; }
        }
    }
}
