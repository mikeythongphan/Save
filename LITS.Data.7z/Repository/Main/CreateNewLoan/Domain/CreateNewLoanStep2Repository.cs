﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanStep2Repository : RepositoryBase<CreateNewLoanStep2ViewModel>, ICreateNewLoanStep2Repository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanStep2Repository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(CreateNewLoanStep2ViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CreateNewLoanStep2ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CreateNewLoanStep2ViewModel Get(Expression<Func<CreateNewLoanStep2ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CreateNewLoanStep2ViewModel> GetMany(Expression<Func<CreateNewLoanStep2ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CreateNewLoanStep2ViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanStep2ViewModel, bool>> where, Expression<Func<CreateNewLoanStep2ViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CreateNewLoanStep2ViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        #endregion
    }
}
