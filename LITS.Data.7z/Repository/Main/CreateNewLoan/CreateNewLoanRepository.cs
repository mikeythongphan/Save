﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Core.Resources;
using LITS.Core.Main;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Models;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanRepository : RepositoryBase<CreateNewLoanViewModel>, ICreateNewLoanRepository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public override void Add(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CreateNewLoanViewModel Get(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CreateNewLoanViewModel> GetMany(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CreateNewLoanViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanViewModel, bool>> where, Expression<Func<CreateNewLoanViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndexStep1
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varType = _LITSEntities.m_type.Where(x => x.is_active == true &&
            (x.pk_id == (int)EnumList.Type.LITS || x.parent_id == (int)EnumList.Type.LITS)).ToList();

            objParam._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree =
                Mapper.Map<List<m_type>, List<CreateNewLoanStep1TreeViewModel>>(varType);

            return objParam;
        }

        /// <summary>
        /// LoadIndexStep2
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// LoadIndexStep3
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._CreateNewLoanStep3ViewModel.ApplicationID = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
            objParam._CreateNewLoanStep3ViewModel.ApplicationNo = objParam._CreateNewLoanStep2ViewModel.ApplicationNo;
            objParam._CreateNewLoanStep3ViewModel.ApplicationType = objParam._CreateNewLoanStep2ViewModel.ApplicationType;
            objParam._CreateNewLoanStep3ViewModel.ApplicationTypeID = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
            objParam._CreateNewLoanStep3ViewModel.CreateBy = objParam._CreateNewLoanStep2ViewModel.CreateBy;
            objParam._CreateNewLoanStep3ViewModel.CreateDate = objParam._CreateNewLoanStep2ViewModel.CreateDate;
            objParam._CreateNewLoanStep3ViewModel.IsActive = objParam._CreateNewLoanStep2ViewModel.IsActive;
            objParam._CreateNewLoanStep3ViewModel.ProductType = objParam._CreateNewLoanStep2ViewModel.ProductType;
            objParam._CreateNewLoanStep3ViewModel.ProductTypeID = objParam._CreateNewLoanStep2ViewModel.ProductTypeID;
            objParam._CreateNewLoanStep3ViewModel.ReceivedDate = objParam._CreateNewLoanStep2ViewModel.CreateDate;

            return objParam;
        }

        /// <summary>
        /// GetApplicationNextAppNo
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel GetApplicationNextAppNo(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._CreateNewLoanStep2ViewModel.ApplicationNo =
                BusinessRule.GetApplicationNextAppNo(DateTime.Now, objParam._CreateNewLoanStep2ViewModel.ProductType, (int)objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

            return objParam;
        }

        /// <summary>
        /// CreateNewLoan
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// CheckBlackList
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckBlackList(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            ReturnMessageViewModel varReturnMessage = new ReturnMessageViewModel();

            //BusinessRule.CheckBlackList(objParam._CreateNewLoanStep2ViewModel.ApplicationID,
            //    objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID,
            //    objParam._CreateNewLoanStep2ViewModel.DateOfBirthMain,
            //    objParam._CreateNewLoanStep2ViewModel.CompanyNameID,
            //    objParam._CreateNewLoanStep2ViewModel.CompanyCode,
            //    varReturnMessage.Content,
            //    EnumList.BlackListType.BlackListSC
            //    );

            return objParam;
        }

        /// <summary>
        /// CheckDeDuplicate
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckDeDuplicate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CreateNewLoanViewModel</returns>
        public CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            objParam = GetApplicationNextAppNo(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

                            if (!string.IsNullOrEmpty(objParam._CreateNewLoanStep2ViewModel.ApplicationNo))
                            {
                                #region Create Application Information
                                objParam = CreateNewApplication(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                                #endregion

                                #region Create Customer Information

                                objParam = CreateNewCustomer(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

                                #endregion

                                #region Check Black List
                                objParam = CheckBlackList(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                                #endregion

                                #region Check DeDuplicate
                                objParam = CheckDeDuplicate(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                                #endregion

                                transaction.Commit();
                            }
                            else
                            {
                                objParam._ReturnMessageViewModel.Code = ConstantDefination.MSG_ERROR_WHEN_PROCESSING;
                            }
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                AreaName = AreaNameParam,
                                ControllerName = ControllerNameParam,
                                ActionName = "Submit",
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);

                            objParam._ReturnMessageViewModel.Code = ConstantDefination.MSG_ERROR_SYSTEM;
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("Submit::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewApplication
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CreateNewLoanViewModel</returns>
        public CreateNewLoanViewModel CreateNewApplication(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    #region Create Application Information
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {

                            var varAppInfo = new application_information();

                            varAppInfo.application_no = objParam._CreateNewLoanStep2ViewModel.ApplicationNo;
                            varAppInfo.created_by = UserPWIDParam;
                            varAppInfo.created_date = DateTime.Now;
                            varAppInfo.received_date = DateTime.Now;
                            varAppInfo.fk_m_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            varAppInfo.fk_m_status_id = (int)EnumList.ALApplicationStatus.SCCreated;
                            varAppInfo.is_active = true;

                            context.application_information.Add(varAppInfo);
                            context.SaveChanges();
                            transaction.Commit();

                            objParam._CreateNewLoanStep2ViewModel.ApplicationID = varAppInfo.pk_id;
                            objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID = varAppInfo.fk_m_status_id;
                            objParam._CreateNewLoanStep2ViewModel.IsActive = (bool)varAppInfo.is_active;
                            objParam._CreateNewLoanStep2ViewModel.CreateDate = varAppInfo.created_date;
                            objParam._CreateNewLoanStep2ViewModel.CreateBy = varAppInfo.created_by;
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                AreaName = AreaNameParam,
                                ControllerName = ControllerNameParam,
                                ActionName = "Submit",
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);

                            objParam._ReturnMessageViewModel.Code = ConstantDefination.MSG_ERROR_SYSTEM;

                            #endregion
                        }
                    }
                    #endregion       

                    #region Create AL Application Information
                    if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                    {
                        if (objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALPERSONAL)
                            objParam = CreateNewAutoLoanPersonal(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                        if (objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALCORPORATE)
                            objParam = CreateNewAutoLoanCorporate(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                    }
                    #endregion
                }
                else
                {
                    LogHelper.WriteLogWarning("");
                }
            }
            return objParam;
        }

        /// <summary>
        /// CreateNewCustomer
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewCustomer(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    #region Customer Information Main
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveMain
                                && objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID != null)
                            {
                                customer_information _customer_information_main = new customer_information();
                                _customer_information_main.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_main.is_active = true;
                                _customer_information_main.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_main.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_main.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_main.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_main.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_main.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameMain;
                                _customer_information_main.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthMain;
                                _customer_information_main.fk_m_borrower_type_id = (int)EnumList.BorrowerType.MainBorrower;

                                context.customer_information.Add(_customer_information_main);
                                context.SaveChanges();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID = _customer_information_main.pk_id;
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomer",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Information Co1
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo1
                                        && objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID != null)
                            {
                                customer_information _customer_information_co1 = new customer_information();
                                _customer_information_co1.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co1.is_active = true;
                                _customer_information_co1.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co1.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co1.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co1.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co1.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co1.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1;
                                _customer_information_co1.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo1;
                                _customer_information_co1.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower1;

                                context.customer_information.Add(_customer_information_co1);
                                context.SaveChanges();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID = _customer_information_co1.pk_id;
                            }


                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomer",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Information Co2
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2)
                            {
                                customer_information _customer_information_co2 = new customer_information();
                                _customer_information_co2.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co2.is_active = true;
                                _customer_information_co2.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co2.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co2.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co2.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co2.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co2.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2;
                                _customer_information_co2.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo2;
                                _customer_information_co2.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower2;

                                context.customer_information.Add(_customer_information_co2);
                                context.SaveChanges();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID = _customer_information_co2.pk_id;
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomer",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Information Co3
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo3)
                            {
                                customer_information _customer_information_co3 = new customer_information();
                                _customer_information_co3.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co3.is_active = true;
                                _customer_information_co3.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co3.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co3.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co3.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co3.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co3.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3;
                                _customer_information_co3.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo3;
                                _customer_information_co3.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower3;

                                context.customer_information.Add(_customer_information_co3);
                                context.SaveChanges();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID = _customer_information_co3.pk_id;
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomer",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion                    

                    #region Create Customer Identification
                    objParam = CreateNewCustomerIdentification(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                    #endregion

                    #region Create AL Customer Information 
                    if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                    {
                        objParam = CreateNewCustomerAutoLoan(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                    }
                    #endregion
                }
                else
                {
                    LogHelper.WriteLogWarning("CreateNewCustomer::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewCustomerIdentification
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewCustomerIdentification(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    #region Customer Identification Main
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain != null
                                && objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain.Count() > 0)
                            {
                                foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain)
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID != null)
                                    {
                                        customer_identification varIdent = new customer_identification();
                                        varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                        varIdent.created_date = DateTime.Now;
                                        varIdent.fk_customer_information_id = (int)objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID;
                                        varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                        varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                        varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                        varIdent.identification_no = obj.IdentificationNo;
                                        varIdent.is_active = true;

                                        context.customer_identification.Add(varIdent);
                                        context.SaveChanges();
                                    }
                                }
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomerIdentification",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Identification Co1
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1 != null
                                && objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1.Count > 0)
                            {
                                foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1)
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID != null)
                                    {
                                        customer_identification varIdent = new customer_identification();
                                        varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                        varIdent.created_date = DateTime.Now;
                                        varIdent.fk_customer_information_id = (int)objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID;
                                        varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                        varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                        varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                        varIdent.identification_no = obj.IdentificationNo;
                                        varIdent.is_active = true;

                                        context.customer_identification.Add(varIdent);
                                        context.SaveChanges();
                                    }
                                }
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomerIdentification",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Identification Co2
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2 != null
                                    && objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2.Count() > 0)
                            {
                                if (objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID != null)
                                {
                                    foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2)
                                    {

                                        customer_identification varIdent = new customer_identification();
                                        varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                        varIdent.created_date = DateTime.Now;
                                        varIdent.fk_customer_information_id = (int)objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID;
                                        varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                        varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                        varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                        varIdent.identification_no = obj.IdentificationNo;
                                        varIdent.is_active = true;

                                        context.customer_identification.Add(varIdent);
                                        context.SaveChanges();
                                    }
                                }
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomerIdentification",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion

                    #region Customer Identification Co3
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3 != null
                                && objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3.Count() > 0)
                            {
                                foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3)
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID != null)
                                    {
                                        customer_identification varIdent = new customer_identification();
                                        varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                        varIdent.created_date = DateTime.Now;
                                        varIdent.fk_customer_information_id = (int)objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID;
                                        varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                        varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                        varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                        varIdent.identification_no = obj.IdentificationNo;
                                        varIdent.is_active = true;

                                        context.customer_identification.Add(varIdent);
                                        context.SaveChanges();
                                    }
                                }
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewCustomerIdentification",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                    #endregion
                }
                else
                {
                    LogHelper.WriteLogWarning("CreateNewCustomerIdentification::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }
        /// <summary>
        /// CreateNewAutoLoanPersonal
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CreateNewLoanViewModel</returns>
        public CreateNewLoanViewModel CreateNewAutoLoanPersonal(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            #region AutoLoanPersonal                        
                            if (objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALPERSONAL)
                            {
                                al_personal_application _al_personal_application = new al_personal_application();
                                _al_personal_application.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _al_personal_application.is_active = objParam._CreateNewLoanStep2ViewModel.IsActive;
                                _al_personal_application.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _al_personal_application.fk_status_id = objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID;
                                _al_personal_application.created_date = (DateTime)objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _al_personal_application.created_by = UserPWIDParam;

                                context.al_personal_application.Add(_al_personal_application);
                                context.SaveChanges();
                            }
                            #endregion

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewAutoLoanPersonal",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewAutoLoanPersonal]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("CreateNewAutoLoanPersonal::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewAutoLoanCorporate
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewAutoLoanCorporate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            #region AutoLoanCorporate
                            if (objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALCORPORATE)
                            {
                                al_corporate_application _al_corporate_application = new al_corporate_application();
                                _al_corporate_application.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _al_corporate_application.is_active = objParam._CreateNewLoanStep2ViewModel.IsActive;
                                _al_corporate_application.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _al_corporate_application.fk_status_id = objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID;
                                _al_corporate_application.created_date = DateTime.Now;
                                _al_corporate_application.created_by = UserPWIDParam;

                                context.al_corporate_application.Add(_al_corporate_application);
                                context.SaveChanges();
                            }
                            #endregion

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "CreateNewAutoLoanCorporate",
                                AreaName = AreaNameParam,
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewAutoLoanCorporate]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("CreateNewAutoLoanCorporate::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewCustomerAutoLoan
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewCustomerAutoLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    if (context.Database.Exists())
                    {
                        if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                        {
                            #region Customer Information Main
                            using (DbContextTransaction transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.IsActiveMain
                                        && objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID != null)
                                    {
                                        al_customer_information _customer_information_main = new al_customer_information();
                                        _customer_information_main.fk_customer_information_id = objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID;
                                        _customer_information_main.is_active = true;
                                        _customer_information_main.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                        _customer_information_main.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                        _customer_information_main.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                        _customer_information_main.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;

                                        context.al_customer_information.Add(_customer_information_main);
                                        context.SaveChanges();
                                    }

                                    transaction.Commit();
                                }
                                catch (Exception ex)
                                {
                                    #region Exception
                                    transaction.Rollback();

                                    ExceptionLogger logger = new ExceptionLogger()
                                    {
                                        ExceptionMessage = ex.Message,
                                        ExceptionStackTrace = ex.StackTrace,
                                        ControllerName = ControllerNameParam,
                                        ActionName = "CreateNewCustomerAutoLoan",
                                        AreaName = AreaNameParam,
                                        ProcessesId = (int)EnumList.Process.LITS,
                                        LogBy = UserPWIDParam,
                                        LogTime = DateTime.Now
                                    };

                                    LogHelper.WriteLogError(
                                        "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                        , ex, logger, true);
                                    #endregion
                                }
                            }
                            #endregion

                            #region Customer Information Co1
                            using (DbContextTransaction transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo1
                                        && objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID != null)
                                    {
                                        al_customer_information _customer_information_co1 = new al_customer_information();
                                        _customer_information_co1.fk_customer_information_id = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID;
                                        _customer_information_co1.is_active = true;
                                        _customer_information_co1.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                        _customer_information_co1.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                        _customer_information_co1.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                        _customer_information_co1.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;

                                        context.al_customer_information.Add(_customer_information_co1);
                                        context.SaveChanges();
                                    }

                                    transaction.Commit();
                                }
                                catch (Exception ex)
                                {
                                    #region Exception
                                    transaction.Rollback();

                                    ExceptionLogger logger = new ExceptionLogger()
                                    {
                                        ExceptionMessage = ex.Message,
                                        ExceptionStackTrace = ex.StackTrace,
                                        ControllerName = ControllerNameParam,
                                        ActionName = "CreateNewCustomerAutoLoan",
                                        AreaName = AreaNameParam,
                                        ProcessesId = (int)EnumList.Process.LITS,
                                        LogBy = UserPWIDParam,
                                        LogTime = DateTime.Now
                                    };

                                    LogHelper.WriteLogError(
                                        "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                        , ex, logger, true);
                                    #endregion
                                }
                            }
                            #endregion

                            #region Customer Information Co2
                            using (DbContextTransaction transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2
                                        && objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID != null)
                                    {
                                        al_customer_information _customer_information_co2 = new al_customer_information();
                                        _customer_information_co2.fk_customer_information_id = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID;
                                        _customer_information_co2.is_active = true;
                                        _customer_information_co2.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                        _customer_information_co2.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                        _customer_information_co2.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                        _customer_information_co2.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;

                                        context.al_customer_information.Add(_customer_information_co2);
                                        context.SaveChanges();
                                    }

                                    transaction.Commit();
                                }
                                catch (Exception ex)
                                {
                                    #region Exception
                                    transaction.Rollback();

                                    ExceptionLogger logger = new ExceptionLogger()
                                    {
                                        ExceptionMessage = ex.Message,
                                        ExceptionStackTrace = ex.StackTrace,
                                        ControllerName = ControllerNameParam,
                                        ActionName = "CreateNewCustomerAutoLoan",
                                        AreaName = AreaNameParam,
                                        ProcessesId = (int)EnumList.Process.LITS,
                                        LogBy = UserPWIDParam,
                                        LogTime = DateTime.Now
                                    };

                                    LogHelper.WriteLogError(
                                        "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                        , ex, logger, true);
                                    #endregion
                                }
                            }
                            #endregion

                            #region Customer Information Co3
                            using (DbContextTransaction transaction = context.Database.BeginTransaction())
                            {
                                try
                                {
                                    if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo3
                                        && objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID != null)
                                    {
                                        al_customer_information _customer_information_co3 = new al_customer_information();
                                        _customer_information_co3.fk_customer_information_id = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID;
                                        _customer_information_co3.is_active = true;
                                        _customer_information_co3.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                        _customer_information_co3.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                        _customer_information_co3.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                        _customer_information_co3.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;

                                        context.al_customer_information.Add(_customer_information_co3);
                                        context.SaveChanges();
                                    }

                                    transaction.Commit();
                                }
                                catch (Exception ex)
                                {
                                    #region Exception
                                    transaction.Rollback();

                                    ExceptionLogger logger = new ExceptionLogger()
                                    {
                                        ExceptionMessage = ex.Message,
                                        ExceptionStackTrace = ex.StackTrace,
                                        ControllerName = ControllerNameParam,
                                        ActionName = "CreateNewCustomerAutoLoan",
                                        AreaName = AreaNameParam,
                                        ProcessesId = (int)EnumList.Process.LITS,
                                        LogBy = UserPWIDParam,
                                        LogTime = DateTime.Now
                                    };

                                    LogHelper.WriteLogError(
                                        "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                        , ex, logger, true);
                                    #endregion
                                }
                            }
                            #endregion
                        }
                    }
                    else
                    {
                        LogHelper.WriteLogWarning("CreateNewCustomerAutoLoan::ConnectionFailure::LITSEntities");
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("CreateNewCustomerAutoLoan::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }
        #endregion
    }
}
