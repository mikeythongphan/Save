﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Core.Main;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Models;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanRepository : RepositoryBase<CreateNewLoanViewModel>, ICreateNewLoanRepository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public override void Add(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CreateNewLoanViewModel Get(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CreateNewLoanViewModel> GetMany(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CreateNewLoanViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanViewModel, bool>> where, Expression<Func<CreateNewLoanViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndexStep1
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varType = _LITSEntities.m_type.Where(x => x.is_active == true &&
            (x.pk_id == (int)EnumList.Type.LITS || x.parent_id == (int)EnumList.Type.LITS)).ToList();

            objParam._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree =
                Mapper.Map<List<m_type>, List<CreateNewLoanStep1TreeViewModel>>(varType);

            return objParam;
        }

        /// <summary>
        /// LoadIndexStep2
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// LoadIndexStep3
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// GetApplicationNextAppNo
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel GetApplicationNextAppNo(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam._CreateNewLoanStep2ViewModel.ApplicationNo = BusinessRule.GetApplicationNextAppNo(objParam._CreateNewLoanStep2ViewModel.ProductType, DateTime.Now);

            return objParam;
        }

        /// <summary>
        /// CreateNewLoan
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// CheckBlackList
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckBlackList(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            ReturnMessageViewModel varReturnMessage = new ReturnMessageViewModel();

            //BusinessRule.CheckBlackList(objParam._CreateNewLoanStep2ViewModel.ApplicationID,
            //    objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID,
            //    objParam._CreateNewLoanStep2ViewModel.DateOfBirthMain,
            //    objParam._CreateNewLoanStep2ViewModel.CompanyNameID,
            //    objParam._CreateNewLoanStep2ViewModel.CompanyCode,
            //    varReturnMessage.Content,
            //    EnumList.BlackListType.BlackListSC
            //    );

            return objParam;
        }

        /// <summary>
        /// CheckDeDuplicate
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckDeDuplicate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        objParam = GetApplicationNextAppNo(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

                        #region Create Application Information
                        var varAppInfo = new application_information();

                        varAppInfo.application_no = objParam._CreateNewLoanStep2ViewModel.ApplicationNo;
                        varAppInfo.created_by = UserPWIDParam;
                        varAppInfo.created_date = DateTime.Now;
                        varAppInfo.received_date = DateTime.Now;
                        varAppInfo.fk_m_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                        varAppInfo.fk_m_status_id = (int)EnumList.ALApplicationStatus.SCCreated;
                        varAppInfo.is_active = true;

                        context.application_information.Add(varAppInfo);
                        context.SaveChanges();

                        objParam._CreateNewLoanStep2ViewModel.ApplicationID = varAppInfo.pk_id;
                        objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID = varAppInfo.fk_m_status_id;
                        objParam._CreateNewLoanStep2ViewModel.IsActive = (bool)varAppInfo.is_active;
                        objParam._CreateNewLoanStep2ViewModel.CreateDate = varAppInfo.created_date;
                        objParam._CreateNewLoanStep2ViewModel.CreateBy = varAppInfo.created_by;
                        #endregion                        

                        #region Create AL Application Information
                        if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                        {
                            if (objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALPERSONAL)
                                objParam = CreateNewAutoLoanPersonal(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                            if (objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALCORPORATE)
                                objParam = CreateNewAutoLoanCorporate(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                        }
                        #endregion

                        #region Create Customer Information

                        objParam = CreateNewCustomer(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

                        #endregion

                        #region Create AL Customer Information 
                        if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                        {
                            objParam = CreateNewCustomerAutoLoan(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                        }
                        #endregion

                        #region Check Black List
                        objParam = CheckBlackList(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                        #endregion

                        #region Check DeDuplicate
                        objParam = CheckDeDuplicate(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
                        #endregion

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();

                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,                                                        
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        Infrastructure.Logging.LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                    }
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewCustomer
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewCustomer(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        #region Customer Information Main
                        if (objParam._CreateNewLoanStep2ViewModel.IsActiveMain)
                        {
                            customer_information _customer_information_main = new customer_information();
                            _customer_information_main.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _customer_information_main.is_active = true;
                            _customer_information_main.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _customer_information_main.fk_status_id = (int)EnumList.CustomerStatus.Active;
                            _customer_information_main.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                            _customer_information_main.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                            _customer_information_main.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                            _customer_information_main.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameMain;
                            _customer_information_main.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthMain;
                            _customer_information_main.fk_m_borrower_type_id = (int)EnumList.BorrowerType.MainBorrower;

                            context.customer_information.Add(_customer_information_main);
                            context.SaveChanges();

                            foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain)
                            {
                                customer_identification varIdent = new customer_identification();
                                varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                varIdent.created_date = DateTime.Now;
                                varIdent.fk_customer_information_id = _customer_information_main.pk_id;
                                varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                varIdent.identification_no = obj.IdentificationNo;
                                varIdent.is_active = true;

                                context.customer_identification.Add(varIdent);
                                context.SaveChanges();
                            }

                            objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID = _customer_information_main.pk_id;
                        }
                        #endregion

                        #region Customer Information Co1
                        if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo1)
                        {
                            customer_information _customer_information_co1 = new customer_information();
                            _customer_information_co1.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _customer_information_co1.is_active = true;
                            _customer_information_co1.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _customer_information_co1.fk_status_id = (int)EnumList.CustomerStatus.Active;
                            _customer_information_co1.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                            _customer_information_co1.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                            _customer_information_co1.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                            _customer_information_co1.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1;
                            _customer_information_co1.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo1;
                            _customer_information_co1.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower1;

                            context.customer_information.Add(_customer_information_co1);
                            context.SaveChanges();

                            foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1)
                            {
                                customer_identification varIdent = new customer_identification();
                                varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                varIdent.created_date = DateTime.Now;
                                varIdent.fk_customer_information_id = _customer_information_co1.pk_id;
                                varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                varIdent.identification_no = obj.IdentificationNo;
                                varIdent.is_active = true;

                                context.customer_identification.Add(varIdent);
                                context.SaveChanges();
                            }

                            objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID = _customer_information_co1.pk_id;
                        }
                        #endregion

                        #region Customer Information Co2
                        if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2)
                        {
                            customer_information _customer_information_co2 = new customer_information();
                            _customer_information_co2.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _customer_information_co2.is_active = true;
                            _customer_information_co2.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _customer_information_co2.fk_status_id = (int)EnumList.CustomerStatus.Active;
                            _customer_information_co2.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                            _customer_information_co2.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                            _customer_information_co2.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                            _customer_information_co2.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2;
                            _customer_information_co2.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo2;
                            _customer_information_co2.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower2;

                            context.customer_information.Add(_customer_information_co2);
                            context.SaveChanges();

                            foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2)
                            {
                                customer_identification varIdent = new customer_identification();
                                varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                varIdent.created_date = DateTime.Now;
                                varIdent.fk_customer_information_id = _customer_information_co2.pk_id;
                                varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                varIdent.identification_no = obj.IdentificationNo;
                                varIdent.is_active = true;

                                context.customer_identification.Add(varIdent);
                                context.SaveChanges();
                            }

                            objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID = _customer_information_co2.pk_id;
                        }
                        #endregion

                        #region Customer Information Co3
                        if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2)
                        {
                            customer_information _customer_information_co3 = new customer_information();
                            _customer_information_co3.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _customer_information_co3.is_active = true;
                            _customer_information_co3.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _customer_information_co3.fk_status_id = (int)EnumList.CustomerStatus.Active;
                            _customer_information_co3.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                            _customer_information_co3.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                            _customer_information_co3.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                            _customer_information_co3.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3;
                            _customer_information_co3.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo3;
                            _customer_information_co3.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower3;

                            context.customer_information.Add(_customer_information_co3);
                            context.SaveChanges();

                            foreach (CustomerIdentificationViewModel obj in objParam._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3)
                            {
                                customer_identification varIdent = new customer_identification();
                                varIdent.created_by = Convert.ToInt32(UserPWIDParam);
                                varIdent.created_date = DateTime.Now;
                                varIdent.fk_customer_information_id = _customer_information_co3.pk_id;
                                varIdent.fk_m_identification_type_id = obj.IdentificationTypeID;
                                varIdent.fk_status_id = (int)EnumList.ActiveStatus.Active;
                                varIdent.fk_type_id = objParam._CreateNewLoanStep1ViewModel.ApplicationTypeID;
                                varIdent.identification_no = obj.IdentificationNo;
                                varIdent.is_active = true;

                                context.customer_identification.Add(varIdent);
                                context.SaveChanges();
                            }

                            objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID = _customer_information_co3.pk_id;
                        }
                        #endregion                        

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();

                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            ControllerName = ControllerNameParam,
                            ActionName = "CreateNewCustomer",
                            AreaName = AreaNameParam,
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        Infrastructure.Logging.LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewCustomer]" + "]"
                            , ex, logger, true);
                    }
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewAutoLoanPersonal
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewAutoLoanPersonal(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        #region AutoLoanPersonal                        
                        if (objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALPERSONAL)
                        {
                            al_personal_application _al_personal_application = new al_personal_application();
                            _al_personal_application.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _al_personal_application.is_active = objParam._CreateNewLoanStep2ViewModel.IsActive;
                            _al_personal_application.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _al_personal_application.fk_status_id = objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID;
                            _al_personal_application.created_date = (DateTime)objParam._CreateNewLoanStep2ViewModel.CreateDate;
                            _al_personal_application.created_by = UserPWIDParam;

                            context.al_personal_application.Add(_al_personal_application);
                            context.SaveChanges();
                        }
                        #endregion

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();

                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            ControllerName = ControllerNameParam,
                            ActionName = "CreateNewAutoLoanPersonal",
                            AreaName = AreaNameParam,
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        Infrastructure.Logging.LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewAutoLoanPersonal]" + "]"
                            , ex, logger, true);
                    }
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewAutoLoanCorporate
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewAutoLoanCorporate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        #region AutoLoanCorporate
                        if (objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID == (int)EnumList.LoanType.ALCORPORATE)
                        {
                            al_corporate_application _al_corporate_application = new al_corporate_application();
                            _al_corporate_application.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                            _al_corporate_application.is_active = objParam._CreateNewLoanStep2ViewModel.IsActive;
                            _al_corporate_application.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                            _al_corporate_application.fk_status_id = objParam._CreateNewLoanStep2ViewModel.ApplicationStatusID;
                            _al_corporate_application.created_date = DateTime.Now;
                            _al_corporate_application.created_by = UserPWIDParam;

                            context.al_corporate_application.Add(_al_corporate_application);
                            context.SaveChanges();
                        }
                        #endregion

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();

                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            ControllerName = ControllerNameParam,
                            ActionName = "CreateNewAutoLoanCorporate",
                            AreaName = AreaNameParam,
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        Infrastructure.Logging.LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[CreateNewAutoLoanCorporate]" + "]"
                            , ex, logger, true);
                    }
                }
            }

            return objParam;
        }

        /// <summary>
        /// CreateNewCustomerAutoLoan
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewCustomerAutoLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (objParam._CreateNewLoanStep1ViewModel.ProductTypeID == (int)EnumList.Type.AL)
                        {
                            #region Customer Information Main
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveMain)
                            {
                                customer_information _customer_information_main = new customer_information();
                                _customer_information_main.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_main.is_active = true;
                                _customer_information_main.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_main.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_main.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_main.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_main.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_main.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameMain;
                                _customer_information_main.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthMain;
                                _customer_information_main.fk_m_borrower_type_id = (int)EnumList.BorrowerType.MainBorrower;

                                context.customer_information.Add(_customer_information_main);
                                context.SaveChanges();
                                transaction.Commit();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameMainID = _customer_information_main.pk_id;
                            }
                            #endregion

                            #region Customer Information Co1
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo1)
                            {
                                customer_information _customer_information_co1 = new customer_information();
                                _customer_information_co1.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co1.is_active = true;
                                _customer_information_co1.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co1.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co1.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co1.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co1.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co1.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1;
                                _customer_information_co1.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo1;
                                _customer_information_co1.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower1;

                                context.customer_information.Add(_customer_information_co1);
                                context.SaveChanges();

                                transaction.Commit();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo1ID = _customer_information_co1.pk_id;
                            }
                            #endregion

                            #region Customer Information Co2
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2)
                            {
                                customer_information _customer_information_co2 = new customer_information();
                                _customer_information_co2.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co2.is_active = true;
                                _customer_information_co2.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co2.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co2.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co2.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co2.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co2.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2;
                                _customer_information_co2.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo2;
                                _customer_information_co2.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower2;

                                context.customer_information.Add(_customer_information_co2);
                                context.SaveChanges();

                                transaction.Commit();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo2ID = _customer_information_co2.pk_id;
                            }
                            #endregion

                            #region Customer Information Co3
                            if (objParam._CreateNewLoanStep2ViewModel.IsActiveCo2)
                            {
                                customer_information _customer_information_co3 = new customer_information();
                                _customer_information_co3.fk_application_information_id = objParam._CreateNewLoanStep2ViewModel.ApplicationID;
                                _customer_information_co3.is_active = true;
                                _customer_information_co3.fk_type_id = objParam._CreateNewLoanStep2ViewModel.ApplicationTypeID;
                                _customer_information_co3.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                _customer_information_co3.created_date = objParam._CreateNewLoanStep2ViewModel.CreateDate;
                                _customer_information_co3.created_by = objParam._CreateNewLoanStep2ViewModel.CreateBy;
                                _customer_information_co3.initital = objParam._CreateNewLoanStep2ViewModel.Intitial;
                                _customer_information_co3.full_name = objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3;
                                _customer_information_co3.dob = objParam._CreateNewLoanStep2ViewModel.DateOfBirthCo3;
                                _customer_information_co3.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower3;

                                context.customer_information.Add(_customer_information_co3);
                                context.SaveChanges();

                                transaction.Commit();

                                objParam._CreateNewLoanStep2ViewModel.CustomerNameCo3ID = _customer_information_co3.pk_id;
                            }
                            #endregion
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();

                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            ControllerName = ControllerNameParam,
                            ActionName = "CreateNewCustomerAutoLoan",
                            AreaName = AreaNameParam,
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        Infrastructure.Logging.LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                    }
                }
            }

            return objParam;
        }
        #endregion
    }
}
