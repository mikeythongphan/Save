﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsExport;
using LITS.Model.PartialViews.Main.ReportsExport;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsExport
{
    public class ReportsExportTreeRepository : RepositoryBase<ReportsExportTreeViewModel>, IReportsExportTreeRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsExportTreeRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities)
            : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public ReportsExportTreeViewModel Get(int id)
        {
            throw new NotImplementedException();
        }

        public List<ReportsExportTreeViewModel> GetListTreeProductIsActive()
        {
            List<ReportsExportTreeViewModel> obj = new List<ReportsExportTreeViewModel>();

            var dataType = _LITSEntities.m_type.Where(x => x.is_active == true
            && (x.pk_id == 2 || x.parent_id == 2 || x.parent_id == 3)).ToList();

            obj = AutoMapper.Mapper.Map<List<m_type>, List<ReportsExportTreeViewModel>>(dataType);

            return obj;
        }

        public void Modify(ReportsExportTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Remove(ReportsExportTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

    }
}
