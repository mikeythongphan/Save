﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsExport;
using LITS.Model.PartialViews.Main.ReportsExport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsExport
{
    public class ReportsExportDetailRepository : RepositoryBase<ReportsExportDetailViewModel>, IReportsExportDetailRepository
    {
        public ReportsExportDetailRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
