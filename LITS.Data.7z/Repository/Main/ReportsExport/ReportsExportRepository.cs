﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsExport;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsExport
{
    public class ReportsExportRepository : RepositoryBase<ReportsExportViewModel>, IReportsExportRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsExportRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public ReportsExportViewModel SearchData(ReportsExportViewModel obj, string strAreaName, string strControllerName)
        {
            throw new NotImplementedException();
        }
    }
}
