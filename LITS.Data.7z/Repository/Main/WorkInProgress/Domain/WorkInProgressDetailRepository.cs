﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Core.Resources;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressDetailRepository : RepositoryBase<WorkInProgressDetailViewModel>, IWorkInProgressDetailRepository
    {
        public WorkInProgressDetailRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        /// <summary>
        /// LoadChildDetail
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        objParam._WorkInProgressDetailChildViewModel = new List<WorkInProgressDetailChildViewModel>();

                        var varResult = context.sp_work_in_progress_load_child_detail(objParam._WorkInProgressMasterViewModel.ApplicationID)
                            .ToList<sp_work_in_progress_load_child_detail_Result>();

                        await System.Threading.Tasks.Task.WhenAll();

                        if (varResult != null && varResult.Count() > 0)
                        {
                            foreach (var r in varResult)
                            {
                                WorkInProgressDetailChildViewModel w = new WorkInProgressDetailChildViewModel();
                                w.ApplicationID = r.ApplicationID;
                                w.ApplicationNo = r.ApplicationNo;
                                w.ChannelID = r.ChannelID;
                                w.ChannelName = r.ChannelName;
                                w.CustomerID = r.CustomerID == null ? 0 : (int)r.CustomerID;
                                w.CustomerName = r.CustomerName;
                                w.CustomerSegment = r.CustomerSegment;
                                w.CustomerSegmentID = r.CustomerSegmentID;
                                w.LocationID = r.LocationID;
                                w.LocationName = r.LocationName;
                                w.IDNumber = r.IDNumber;
                                w.AmountApproved = r.AmountApproved;
                                w.AmountRequest = r.AmountRequest;

                                objParam._WorkInProgressDetailChildViewModel.Add(w);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "LoadChildDetail",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[LoadChildDetail]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("WorkInProgressDetailRepository::LoadChildDetail::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }
    }
}
