﻿using System;
using PagedList;
using AutoMapper;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data.Entity;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Infrastructure.Context;
using LITS.Model.Views.Main;
using LITS.Core.Resources;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressTreeRepository : RepositoryBase<WorkInProgressTreeViewModel>, IWorkInProgressTreeRepository
    {
        public WorkInProgressTreeRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        { }

        #region Base
        public override void Add(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new WorkInProgressTreeViewModel Get(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<WorkInProgressTreeViewModel> GetMany(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<WorkInProgressTreeViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressTreeViewModel, bool>> where, Expression<Func<WorkInProgressTreeViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }
        #endregion

        #region Custom
        /// <summary>
        /// GetListTreeProductIsActive
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> GetListTreeProductIsActive(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var dataType = await context.m_type.Where(x => x.is_active == true
                        && (x.pk_id == (int)EnumList.Type.LITS || x.parent_id == (int)EnumList.Type.LITS)).ToListAsync();

                        objParam._WorkInProgressTreeViewModel = 
                            Mapper.Map<List<m_type>, List<WorkInProgressTreeViewModel>>(dataType);
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "GetListTreeProductIsActive",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[GetListTreeProductIsActive]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("WorkInProgressTreeRepository::GetListTreeProductIsActive::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }
        #endregion
    }
}
