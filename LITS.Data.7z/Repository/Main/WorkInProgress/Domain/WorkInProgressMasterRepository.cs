﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;
using LITS.Core.Resources;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressMasterRepository : RepositoryBase<WorkInProgressMasterViewModel>, IWorkInProgressMasterRepository
    {
        public WorkInProgressMasterRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public override void Add(WorkInProgressMasterViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new WorkInProgressMasterViewModel Get(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<WorkInProgressMasterViewModel> GetMany(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<WorkInProgressMasterViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressMasterViewModel, bool>> where, Expression<Func<WorkInProgressMasterViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(WorkInProgressMasterViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// GetListCustomerLargeDatabase
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> GetListCustomerLargeDatabase(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        objParam._WorkInProgressMasterViewModel._WorkInProgressMasterCustomerViewModel = await (
                           from custinfo in context.customer_information
                           join custiden in context.customer_identification on custinfo.pk_id equals custiden.fk_customer_information_id
                           select new WorkInProgressMasterCustomerViewModel
                           {
                               CustomerID = custinfo.pk_id,
                               CustomerName = custinfo.full_name,
                               CustomerIdentification = custiden.identification_no
                           }).ToListAsync();
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "GetListCustomerLargeDatabase",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[GetListCustomerLargeDatabase]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("WorkInProgressMasterRepository::GetListCustomerLargeDatabase::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// GetListCompanyLargeDatabase
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> GetListCompanyLargeDatabase(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var data = await context.m_company_code.Where(x => x.is_active == true).ToListAsync();

                        Mapper.Map<List<m_company_code>, List<WorkInProgressMasterCompanyViewModel>>(data, objParam._WorkInProgressMasterViewModel._WorkInProgressMasterCompanyViewModel);
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "GetListCompanyLargeDatabase",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[GetListCompanyLargeDatabase]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("WorkInProgressMasterRepository::GetListCompanyLargeDatabase::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
