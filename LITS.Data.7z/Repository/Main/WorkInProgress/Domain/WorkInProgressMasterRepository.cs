﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressMasterRepository : RepositoryBase<WorkInProgressMasterViewModel>, IWorkInProgressMasterRepository
    {
        private LITSEntities _LITSEntities;

        public WorkInProgressMasterRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(WorkInProgressMasterViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public WorkInProgressMasterViewModel Get(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<WorkInProgressMasterViewModel> GetMany(Expression<Func<WorkInProgressMasterViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<WorkInProgressMasterViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressMasterViewModel, bool>> where, Expression<Func<WorkInProgressMasterViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(WorkInProgressMasterViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<WorkInProgressMasterCustomerViewModel> GetListCustomerLargeDatabase()
        {
            List<WorkInProgressMasterCustomerViewModel> obj = new List<WorkInProgressMasterCustomerViewModel>();

            obj = (
                from custinfo in _LITSEntities.customer_information.ToList()
                join custiden in _LITSEntities.customer_identification.ToList() on custinfo.pk_id equals custiden.fk_customer_information_id
                select new WorkInProgressMasterCustomerViewModel
                {
                    CustomerID = custinfo.pk_id,
                    CustomerName = custinfo.full_name,
                    CustomerIdentification = custiden.identification_no                    
                }).ToList();       

            return obj;
        }

        public List<WorkInProgressMasterCompanyViewModel> GetListCompanyLargeDatabase()
        {
            List<WorkInProgressMasterCompanyViewModel> obj = new List<WorkInProgressMasterCompanyViewModel>();

            var data = _LITSEntities.m_company_code.Where(x => x.is_active == true).ToList();

            Mapper.Map<List<m_company_code>, List<WorkInProgressMasterCompanyViewModel>>(data, obj);

            return obj;
        }

        #endregion
    }

    public static class EntityMapper
    {
        public static T Map<T>(params object[] sources) where T : class
        {
            if (!sources.Any())
            {
                return default(T);
            }

            var initialSource = sources[0];

            var mappingResult = Map<T>(initialSource);

            // Now map the remaining source objects
            if (sources.Count() > 1)
            {
                Map(mappingResult, sources.Skip(1).ToArray());
            }

            return mappingResult;
        }

        private static void Map(object destination, params object[] sources)
        {
            if (!sources.Any())
            {
                return;
            }

            var destinationType = destination.GetType();

            foreach (var source in sources)
            {
                var sourceType = source.GetType();
                Mapper.Map(source, destination, sourceType, destinationType);
            }
        }

        private static T Map<T>(object source) where T : class
        {
            var destinationType = typeof(T);
            var sourceType = source.GetType();

            var mappingResult = Mapper.Map(source, sourceType, destinationType);

            return mappingResult as T;
        }

        public static TResult MergeInto<TResult>(this IMapper mapper, object item1, object item2)
        {
            return mapper.Map(item2, mapper.Map<TResult>(item1));
        }

        public static TResult MergeInto<TResult>(this IMapper mapper, params object[] objects)
        {
            var res = mapper.Map<TResult>(objects.First());
            return objects.Skip(1).Aggregate(res, (r, obj) => mapper.Map(obj, r));
        }

        public static TDestination Map<TSource, TDestination>(this TDestination destination, TSource source)
        {
            return Mapper.Map(source, destination);
        }
    }
}
