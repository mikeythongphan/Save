﻿using System;
using PagedList;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Data.Entity;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Infrastructure.Context;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressTreeRepository : RepositoryBase<WorkInProgressTreeViewModel>, IWorkInProgressTreeRepository
    {
        private LITSEntities _LITSEntities;

        public WorkInProgressTreeRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) 
            : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public void Add(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public WorkInProgressTreeViewModel Get(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<WorkInProgressTreeViewModel> GetMany(Expression<Func<WorkInProgressTreeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<WorkInProgressTreeViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressTreeViewModel, bool>> where, Expression<Func<WorkInProgressTreeViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(WorkInProgressTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public List<WorkInProgressTreeViewModel> GetListTreeProductIsActive()
        {
            List<WorkInProgressTreeViewModel> obj = new List<WorkInProgressTreeViewModel>();

            var dataType = _LITSEntities.m_type.Where(x => x.is_active == true
            && (x.pk_id == 2 || x.parent_id == 2 || x.parent_id == 3)).ToList();

            obj = AutoMapper.Mapper.Map<List<m_type>, List<WorkInProgressTreeViewModel>>(dataType);

            return obj;
        }
    }
}
