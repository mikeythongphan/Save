﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressRepository : RepositoryBase<WorkInProgressViewModel>, IWorkInProgressRepository
    {
        private LITSEntities _LITSEntities;

        public WorkInProgressRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public override void Add(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new WorkInProgressViewModel Get(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<WorkInProgressViewModel> GetMany(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<WorkInProgressViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressViewModel, bool>> where, Expression<Func<WorkInProgressViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public WorkInProgressViewModel LoadIndex(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// SearchData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public WorkInProgressViewModel SearchData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        objParam._WorkInProgressDetailViewModel = new List<WorkInProgressDetailViewModel>();
                        objParam._WorkInProgressDetailChildViewModel = new List<WorkInProgressDetailChildViewModel>();

                        if (objParam._WorkInProgressTreeViewModel != null && objParam._WorkInProgressTreeViewModel.Count() > 0)
                        {
                            foreach (WorkInProgressTreeViewModel obj in objParam._WorkInProgressTreeViewModel)
                            {
                                var varResult = context.sp_search_work_in_progress(obj.ID, objParam._WorkInProgressMasterViewModel.FromDate,
                                    objParam._WorkInProgressMasterViewModel.ToDate, objParam._WorkInProgressMasterViewModel.StatusID,
                                    objParam._WorkInProgressMasterViewModel.CustomerID, objParam._WorkInProgressMasterViewModel.CompanyID,
                                    objParam._WorkInProgressMasterViewModel.ApplicationNo);

                                if (varResult != null && varResult.Count() > 0)
                                {
                                    foreach (var r in varResult)
                                    {
                                        WorkInProgressDetailViewModel w = new WorkInProgressDetailViewModel();
                                        w.ApplicationID = r.ApplicationID == null ? 0 : (int)r.ApplicationID;
                                        w.ApplicationNo = r.ApplicationNo;
                                        w.ApplicationStatus = r.ApplicationStatus;
                                        w.ApplicationStatusID = r.ApplicationStatusID;
                                        w.ApplicationType = r.ApplicationType;
                                        w.ApplicationTypeID = r.ApplicationTypeID == null ? 0 : (int)r.ApplicationTypeID;
                                        w.TeleStatus = r.TeleStatus;
                                        w.TeleStatusID = r.TeleStatusID;

                                        objParam._WorkInProgressDetailViewModel.Add(w);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "SearchData",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("SearchData::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// LoadChildDetail
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public WorkInProgressViewModel LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            WorkInProgressViewModel objResult = new WorkInProgressViewModel();

            objResult._WorkInProgressDetailChildViewModel =
                (from appInfor in _LITSEntities.application_information
                 join custInfor in _LITSEntities.customer_information on appInfor.pk_id equals custInfor.fk_application_information_id
                 join custIden in _LITSEntities.customer_identification on custInfor.pk_id equals custIden.fk_customer_information_id
                 join segment in _LITSEntities.m_customer_segment on appInfor.fk_m_customer_segment_id equals segment.pk_id
                 join channel in _LITSEntities.m_sales_channel on appInfor.fk_m_sales_channel_id equals channel.pk_id
                 join location in _LITSEntities.m_branch_location on appInfor.fk_m_branch_location_id equals location.pk_id
                 where appInfor.pk_id == objParam._WorkInProgressMasterViewModel.ApplicationID
                 select new WorkInProgressDetailChildViewModel
                 {
                     ApplicationID = appInfor.pk_id,
                     ApplicationNo = appInfor.application_no,
                     CustomerID = custInfor.pk_id,
                     CustomerName = custInfor.full_name,
                     IDNumber = custIden.identification_no,
                     CustomerSegmentID = appInfor.fk_m_customer_segment_id,
                     CustomerSegment = segment.name,
                     ChannelID = appInfor.fk_m_sales_channel_id,
                     ChannelName = channel.name,
                     LocationID = appInfor.fk_m_branch_location_id,
                     LocationName = channel.name,
                 }).ToList();

            return objResult;
        }
        #endregion
    }
}
