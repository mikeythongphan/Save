﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Core.Resources;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressRepository : RepositoryBase<WorkInProgressViewModel>, IWorkInProgressRepository
    {
        public WorkInProgressRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}

        #region Base

        public override void Add(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new WorkInProgressViewModel Get(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<WorkInProgressViewModel> GetMany(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<WorkInProgressViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressViewModel, bool>> where, Expression<Func<WorkInProgressViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadIndex(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// SearchData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> SearchData(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        objParam._WorkInProgressDetailViewModel = new List<WorkInProgressDetailViewModel>();

                        if (objParam._WorkInProgressTreeViewModel != null && objParam._WorkInProgressTreeViewModel.Count() > 0)
                        {
                            foreach (WorkInProgressTreeViewModel obj in objParam._WorkInProgressTreeViewModel)
                            {
                                var varResult = context.sp_work_in_progress_search(obj.ID, objParam._WorkInProgressMasterViewModel.FromDate,
                                    objParam._WorkInProgressMasterViewModel.ToDate, objParam._WorkInProgressMasterViewModel.StatusID,
                                    objParam._WorkInProgressMasterViewModel.CustomerID, objParam._WorkInProgressMasterViewModel.CompanyID,
                                    objParam._WorkInProgressMasterViewModel.ApplicationNo).ToList<sp_work_in_progress_search_Result>();

                                await System.Threading.Tasks.Task.WhenAll();

                                if (varResult != null && varResult.Count() > 0)
                                {
                                    foreach (var r in varResult)
                                    {
                                        WorkInProgressDetailViewModel w = new WorkInProgressDetailViewModel();
                                        w.ApplicationID = r.ApplicationID;
                                        w.ApplicationNo = r.ApplicationNo;
                                        w.ApplicationStatus = r.ApplicationStatus;
                                        w.ApplicationStatusID = r.ApplicationStatusID;
                                        w.ApplicationType = r.ApplicationType;
                                        w.ApplicationTypeID = r.ApplicationTypeID;
                                        w.TeleStatus = r.TeleStatus;
                                        w.TeleStatusID = r.TeleStatusID;

                                        objParam._WorkInProgressDetailViewModel.Add(w);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "SearchData",
                            ProcessesId = (int) EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[SearchData]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("WorkInProgressRepository::SearchData::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// LoadChildDetail
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<WorkInProgressViewModel> LoadChildDetail(WorkInProgressViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAny();

            return objParam;
        }
        #endregion
    }
}
