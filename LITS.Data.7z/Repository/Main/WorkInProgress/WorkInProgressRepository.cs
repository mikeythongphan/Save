﻿using System;
using System.Collections.Generic;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Data.Repository.Main.WorkInProgress
{
    public class WorkInProgressRepository : RepositoryBase<WorkInProgressViewModel>, IWorkInProgressRepository
    {
        private LITSEntities _LITSEntities;

        public WorkInProgressRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public WorkInProgressViewModel Get(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<WorkInProgressViewModel> GetMany(Expression<Func<WorkInProgressViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<WorkInProgressViewModel> GetPage<TOrder>(Page page, Expression<Func<WorkInProgressViewModel, bool>> where, Expression<Func<WorkInProgressViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(WorkInProgressViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public WorkInProgressViewModel SearchData(WorkInProgressViewModel objPramWIP, string strAreaName, string strControllerName)
        {
            objPramWIP._WorkInProgressDetailViewModel =
                (from appInfor in _LITSEntities.application_information
                 join custInfo in _LITSEntities.customer_information on appInfor.pk_id equals custInfo.fk_application_information_id
                 join companyInfo in _LITSEntities.m_company_code on custInfo.fk_m_company_code_id equals companyInfo.pk_id
                 join type in _LITSEntities.m_type on appInfor.fk_m_type_id equals type.pk_id
                 join status in _LITSEntities.m_status on appInfor.fk_m_status_id equals status.pk_id                 
                 where appInfor.received_date >= objPramWIP._WorkInProgressMasterViewModel.FromDate
                 && appInfor.received_date <= objPramWIP._WorkInProgressMasterViewModel.ToDate
                 && appInfor.fk_m_status_id == objPramWIP._WorkInProgressMasterViewModel.StatusID
                 //&& appInfor.
                 && (appInfor.application_no.Contains(objPramWIP._WorkInProgressMasterViewModel.ApplicationNo))
                 select new WorkInProgressDetailViewModel
                 {
                     ApplicationID = appInfor.pk_id,
                     ApplicationNo = appInfor.application_no,
                     ReceivedDate = appInfor.received_date,
                     ApplicationType = type.name,
                     ApplicationStatus = status.name,
                     TeleStatus = status.name
                 }).ToList();

            return objPramWIP;
        }

        public WorkInProgressViewModel LoadChildDetail(int appId, string strAreaName, string strControllerName)
        {
            WorkInProgressViewModel objResult = new WorkInProgressViewModel();

            objResult._WorkInProgressDetailChildViewModel =
                (from appInfor in _LITSEntities.application_information
                 join custInfor in _LITSEntities.customer_information on appInfor.pk_id equals custInfor.fk_application_information_id
                 join custIden in _LITSEntities.customer_identification on custInfor.pk_id equals custIden.fk_customer_information_id
                 join segment in _LITSEntities.m_customer_segment on appInfor.fk_m_customer_segment_id equals segment.pk_id
                 join channel in _LITSEntities.m_sales_channel on appInfor.fk_m_sales_channel_id equals channel.pk_id
                 join location in _LITSEntities.m_branch_location on appInfor.fk_m_branch_location_id equals location.pk_id
                 where appInfor.pk_id == appId
                 select new WorkInProgressDetailChildViewModel
                 {
                     ApplicationID = appInfor.pk_id,
                     ApplicationNo = appInfor.application_no,
                     CustomerID = custInfor.pk_id,
                     CustomerName = custInfor.full_name,
                     IDNumber = custIden.identification_no,
                     CustomerSegmentID = appInfor.fk_m_customer_segment_id,
                     CustomerSegment = segment.name,
                     ChannelID = appInfor.fk_m_sales_channel_id,
                     ChannelName = channel.name,
                     LocationID = appInfor.fk_m_branch_location_id,
                     LocationName = channel.name,
                 }).ToList();

            return objResult;
        }
        #endregion
    }
}
