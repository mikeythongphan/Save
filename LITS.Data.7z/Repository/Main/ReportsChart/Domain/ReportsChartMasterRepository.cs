﻿using AutoMapper;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Model.PartialViews.Main.ReportsChart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsChart
{
    public class ReportsChartMasterRepository : RepositoryBase<ReportsChartMasterViewModel>, IReportsChartMasterRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsChartMasterRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Custom

        public List<ReportsChartMasterCustomerViewModel> GetListCustomerLargeDatabase()
        {
            List<ReportsChartMasterCustomerViewModel> obj = new List<ReportsChartMasterCustomerViewModel>();

            obj = (
                from custinfo in _LITSEntities.customer_information.ToList()
                join custiden in _LITSEntities.customer_identification.ToList() on custinfo.pk_id equals custiden.fk_customer_information_id
                select new ReportsChartMasterCustomerViewModel
                {
                    CustomerID = custinfo.pk_id,
                    CustomerName = custinfo.full_name,
                    CustomerIdentification = custiden.identification_no
                }).ToList();

            return obj;
        }

        public List<ReportsChartMasterCompanyViewModel> GetListCompanyLargeDatabase()
        {
            List<ReportsChartMasterCompanyViewModel> obj = new List<ReportsChartMasterCompanyViewModel>();

            var data = _LITSEntities.m_company_code.Where(x => x.is_active == true).ToList();

            Mapper.Map<List<m_company_code>, List<ReportsChartMasterCompanyViewModel>>(data, obj);

            return obj;
        }

        #endregion
    }
}
