﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Model.PartialViews.Main.ReportsChart;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsChart
{
    public class ReportsChartTreeRepository : RepositoryBase<ReportsChartTreeViewModel>, IReportsChartTreeRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsChartTreeRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities)
            : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public ReportsChartTreeViewModel Get(int id)
        {
            throw new NotImplementedException();
        }

        public List<ReportsChartTreeViewModel> GetListTreeProductIsActive()
        {
            List<ReportsChartTreeViewModel> obj = new List<ReportsChartTreeViewModel>();

            var dataType = _LITSEntities.m_type.Where(x => x.is_active == true
            && (x.pk_id == 2 || x.parent_id == 2 || x.parent_id == 3)).ToList();

            obj = AutoMapper.Mapper.Map<List<m_type>, List<ReportsChartTreeViewModel>>(dataType);

            return obj;
        }

        public void Modify(ReportsChartTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Remove(ReportsChartTreeViewModel entity)
        {
            throw new NotImplementedException();
        }

    }
}
