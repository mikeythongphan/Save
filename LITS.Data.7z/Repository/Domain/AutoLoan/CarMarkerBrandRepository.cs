﻿using System;
using AutoMapper;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.AutoLoan;
using LITS.Interface.Repository.Domain.AutoLoan;

namespace LITS.Data.Repository.Domain.AutoLoan
{
    public class CarMarkerBrandRepository : RepositoryBase<CarMarkerBrandViewModel>, ICarMarkerBrandRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CarMarkerBrandRepository(IDatabaseFactory databaseFactory, LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(al_car_marker_brand entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(al_car_marker_brand entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<al_car_marker_brand, bool>> where)
        {
            throw new NotImplementedException();
        }

        public al_car_marker_brand Get(Expression<Func<al_car_marker_brand, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<al_car_marker_brand> GetAll()
        {
            throw new NotImplementedException();
        }

        public new al_car_marker_brand GetById(long id)
        {
            throw new NotImplementedException();
        }

        public new al_car_marker_brand GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<al_car_marker_brand> GetMany(Expression<Func<al_car_marker_brand, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<al_car_marker_brand> GetPage<TOrder>(Page page, Expression<Func<al_car_marker_brand, bool>> where, Expression<Func<al_car_marker_brand, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(al_car_marker_brand entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CarMarkerBrandViewModel> GetListActiveAll()
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListActiveById(int? Id)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListAll()
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListById(int? Id)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListByStatusId(int? StatusId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarMarkerBrandViewModel> GetListByTypeId(int? TypeId)
        {
            List<al_car_marker_brand> objList = _LITSEntities.al_car_marker_brand.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CarMarkerBrandViewModel> resultList = new List<CarMarkerBrandViewModel>();
            foreach (al_car_marker_brand temp in objList)
            {
                CarMarkerBrandViewModel data = Mapper.Map<al_car_marker_brand, CarMarkerBrandViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public new bool Delete(CarMarkerBrandViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CarMarkerBrandViewModel, al_car_marker_brand>(model[0]);
                            data.is_active = false;
                            context.al_car_marker_brand.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public bool Create(CarMarkerBrandViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_car_marker_brand data = AutoMapper.Mapper.Map<CarMarkerBrandViewModel, al_car_marker_brand>(objModel);
                        context.al_car_marker_brand.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public new bool Update(CarMarkerBrandViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_car_marker_brand data = Mapper.Map<CarMarkerBrandViewModel, al_car_marker_brand>(objModel);
                        context.al_car_marker_brand.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
        #endregion
    }
}
