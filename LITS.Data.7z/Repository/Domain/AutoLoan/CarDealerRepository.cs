﻿using System;
using AutoMapper;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.AutoLoan;
using LITS.Interface.Repository.Domain.AutoLoan;

namespace LITS.Data.Repository.Domain.AutoLoan
{
    public class CarDealerRepository : RepositoryBase<CarDealerViewModel>, ICarDealerRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CarDealerRepository(IDatabaseFactory databaseFactory, LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(al_car_dealer entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(al_car_dealer entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<al_car_dealer, bool>> where)
        {
            throw new NotImplementedException();
        }

        public al_car_dealer Get(Expression<Func<al_car_dealer, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<al_car_dealer> GetAll()
        {
            throw new NotImplementedException();
        }

        public new al_car_dealer GetById(long id)
        {
            throw new NotImplementedException();
        }

        public new al_car_dealer GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<al_car_dealer> GetMany(Expression<Func<al_car_dealer, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<al_car_dealer> GetPage<TOrder>(Page page, Expression<Func<al_car_dealer, bool>> where, Expression<Func<al_car_dealer, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(al_car_dealer entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CarDealerViewModel> GetListActiveAll()
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListActiveById(int? Id)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListAll()
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListById(int? Id)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListByStatusId(int? StatusId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CarDealerViewModel> GetListByTypeId(int? TypeId)
        {
            List<al_car_dealer> objList = _LITSEntities.al_car_dealer.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CarDealerViewModel> resultList = new List<CarDealerViewModel>();
            foreach (al_car_dealer temp in objList)
            {
                CarDealerViewModel data = Mapper.Map<al_car_dealer, CarDealerViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public new bool Delete(CarDealerViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CarDealerViewModel, al_car_dealer>(model[0]);
                            data.is_active = false;
                            context.al_car_dealer.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public bool Create(CarDealerViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_car_dealer data = AutoMapper.Mapper.Map<CarDealerViewModel, al_car_dealer>(objModel);
                        context.al_car_dealer.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public new bool Update(CarDealerViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_car_dealer data = Mapper.Map<CarDealerViewModel, al_car_dealer>(objModel);
                        context.al_car_dealer.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
        #endregion
    }
}
