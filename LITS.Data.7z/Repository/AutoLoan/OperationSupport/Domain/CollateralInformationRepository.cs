﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CollateralInformationRepository : RepositoryBase<CollateralInformationViewModel>, ICollateralInformationRepository
    {
        private LITSEntities _LITSEntities;

        public CollateralInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CollateralInformationViewModel Get(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CollateralInformationViewModel> GetMany(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CollateralInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CollateralInformationViewModel, bool>> where, Expression<Func<CollateralInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CollateralInformationViewModel LoadIndex(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varApp = (from alapp in _LITSEntities.al_personal_application
                          join status in _LITSEntities.m_status on alapp.fk_status_id equals status.pk_id
                          join type in _LITSEntities.m_type on alapp.fk_type_id equals type.pk_id
                          join dealer in _LITSEntities.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                          where alapp.fk_application_information_id == objParam.ApplicationInformationID
                          && alapp.is_active == true
                          select new CollateralInformationViewModel
                          {
                              ALApplicationInformationID = alapp.pk_id,
                              ApplicationInformationID = alapp.fk_application_information_id,
                              ApplicationStatusID = alapp.fk_status_id,
                              ApplicationStatus = status.name,
                              ApplicationTypeID = alapp.fk_type_id,
                              ApplicationType = type.name,
                              CarMarkerBrandID = alapp.fk_al_car_marker_brand_id,
                              PropertyStatusID = alapp.fk_m_property_status_id,
                              ModelID = alapp.fk_al_car_model_id,
                              CarTypeID = alapp.fk_al_car_type_id,
                              CarSourceID = alapp.fk_al_car_source_id,
                              YearOfManufacture = alapp.year_of_manufacture,
                              Color = alapp.color,
                              NumberOfSeats = alapp.number_of_seats,
                              ChassisNumber = alapp.chassis_number,
                              PurchasingPriceOrFairMarketValue = alapp.purchasing_price,
                              PurchasingSPContractNumber = alapp.purchasing_sp_contract_number,
                              CollateralValue = alapp.collateral_value,
                              CreateBy = alapp.created_by,
                              CreateDate = alapp.created_date
                          }).FirstOrDefault();

            if (varApp != null)
            {
                objParam = varApp;
            }

            return objParam;
        }

        public CollateralInformationViewModel Save(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        #endregion
    }
}
