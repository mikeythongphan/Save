﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class OperationSupportRepository : RepositoryBase<OperationSupportViewModel>, IOperationSupportRepository
    {
        private LITSEntities _LITSEntities;

        public OperationSupportRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(OperationSupportViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(OperationSupportViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<OperationSupportViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public OperationSupportViewModel Get(Expression<Func<OperationSupportViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OperationSupportViewModel> GetMany(Expression<Func<OperationSupportViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<OperationSupportViewModel> GetPage<TOrder>(Page page, Expression<Func<OperationSupportViewModel, bool>> where, Expression<Func<OperationSupportViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(OperationSupportViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        public OperationSupportViewModel LoadIndex(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel Save(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel Approved(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel Reject(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel NSG(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel SendbackSC(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public OperationSupportViewModel FRM(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
    }
}
