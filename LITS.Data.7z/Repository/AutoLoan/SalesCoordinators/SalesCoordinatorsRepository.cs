﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Domain.Main;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class SalesCoordinatorsRepository : RepositoryBase<SalesCoordinatorsViewModel>, ISalesCoordinatorsRepository
    {
        private readonly LITSEntities _LITSEntities;

        public SalesCoordinatorsRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public override void Add(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new SalesCoordinatorsViewModel Get(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<SalesCoordinatorsViewModel> GetMany(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<SalesCoordinatorsViewModel> GetPage<TOrder>(Page page, Expression<Func<SalesCoordinatorsViewModel, bool>> where, Expression<Func<SalesCoordinatorsViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {            
            #region ApplicationInformation

            var varApp = _LITSEntities.application_information
                .FirstOrDefault(p => p.pk_id == objParam._ApplicationInformationViewModel.ApplicationInformationID);

            objParam._ApplicationInformationViewModel = AutoMapper.Mapper.Map<application_information, ApplicationInformationViewModel>(varApp);            
            
            var varAppDup = _LITSEntities.application_duplication
                .Where(x => x.fk_application_information_id == objParam._ApplicationInformationViewModel.ApplicationInformationID)                
                .ToList();

            foreach(application_duplication obj in varAppDup)
            {
                ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
                ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
                ad.ApplicationInformationID = obj.pk_id;
                ad.ApplicationNo = obj.application_no;
                ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
                ad.StatusID = obj.fk_status_id;
                ad.ApplicationTypeID = obj.fk_type_id;
                ad.CreatedBy = obj.created_by;
                ad.CreatedDate = obj.created_date;

                objParam._ApplicationInformationViewModel._ApplicationDuplicationViewModel.Add(ad);
            }

            #endregion

            #region CustomerInformation



            #endregion

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel Save(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel Submit(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// NSG
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Cancel
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// FRMQueue
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
