﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Core.Main;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class SalesCoordinatorsRepository : RepositoryBase<SalesCoordinatorsViewModel>, ISalesCoordinatorsRepository
    {                
        public SalesCoordinatorsRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}

        #region Base

        public override void Add(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new SalesCoordinatorsViewModel Get(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<SalesCoordinatorsViewModel> GetMany(Expression<Func<SalesCoordinatorsViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<SalesCoordinatorsViewModel> GetPage<TOrder>(Page page, Expression<Func<SalesCoordinatorsViewModel, bool>> where, Expression<Func<SalesCoordinatorsViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(SalesCoordinatorsViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> Save(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> Submit(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// NSG
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// Cancel
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }

        /// <summary>
        /// FRMQueue
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<SalesCoordinatorsViewModel> FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            await System.Threading.Tasks.Task.WhenAll();

            return objParam;
        }
        #endregion
    }
}
