﻿using System;
using PagedList;
using AutoMapper;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;
using LITS.Core.Resources;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerCreditBureauRepository : RepositoryBase<CustomerCreditBureauViewModel>, ICustomerCreditBureauRepository
    {
        public CustomerCreditBureauRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        { }

        #region Base

        public override void Add(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CustomerCreditBureauViewModel Get(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CustomerCreditBureauViewModel> GetMany(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CustomerCreditBureauViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerCreditBureauViewModel, bool>> where, Expression<Func<CustomerCreditBureauViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public async Task<CustomerCreditBureauViewModel> LoadIndex(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await context.al_customer_credit_bureau
                            .Where(p => p.pk_id == objParam._CustomerCreditBureauDetailViewModel_Co1.ApplicationInformationID)
                            .FirstOrDefaultAsync();

                        //if (varApp != null)
                        //    objParam = AutoMapper.Mapper.Map<application_information, CustomerCreditBureauViewModel>(varApp);

                        //var varAppDup = _LITSEntities.application_duplication
                        //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
                        //    .ToList();
                        //if (varAppDup != null)
                        //{
                        //    foreach (application_duplication obj in varAppDup)
                        //    {
                        //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
                        //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
                        //        ad.ApplicationInformationID = obj.pk_id;
                        //        ad.ApplicationNo = obj.application_no;
                        //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
                        //        ad.StatusID = obj.fk_status_id;
                        //        ad.ApplicationTypeID = obj.fk_type_id;
                        //        ad.CreatedBy = obj.created_by;
                        //        ad.CreatedDate = obj.created_date;

                        //        objParam._ApplicationDuplicationViewModel.Add(ad);
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        public async Task<CustomerCreditBureauViewModel> Save(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            al_customer_credit_bureau varData =
                                Mapper.Map<CustomerCreditBureauViewModel, al_customer_credit_bureau>(objParam);
                            context.al_customer_credit_bureau.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
