﻿using System;
using System.Linq;
using System.Text;
using AutoMapper;
using PagedList;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Core.Resources;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerDemostrationRepository : RepositoryBase<CustomerDemostrationViewModel>, ICustomerDemostrationRepository
    {
        public CustomerDemostrationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public override void Add(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CustomerDemostrationViewModel Get(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CustomerDemostrationViewModel> GetMany(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CustomerDemostrationViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerDemostrationViewModel, bool>> where, Expression<Func<CustomerDemostrationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CustomerDemostrationViewModel</returns>
        public async Task<CustomerDemostrationViewModel> LoadIndex(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await (from alapp in context.al_personal_application
                                            join status in context.m_status on alapp.fk_status_id equals status.pk_id
                                            join type in context.m_type on alapp.fk_type_id equals type.pk_id
                                            join dealer in context.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                                            where alapp.fk_application_information_id == objParam.ApplicationInformationID
                                            && alapp.is_active == true
                                            select new CustomerDemostrationViewModel
                                            {
                                                ALApplicationInformationID = alapp.pk_id,
                                                ApplicationInformationID = alapp.fk_application_information_id,
                                                ApplicationStatusID = alapp.fk_status_id,
                                                ApplicationStatus = status.name,
                                                ApplicationTypeID = alapp.fk_type_id,
                                                ApplicationType = type.name,
                                                TotalFDvalue = alapp.total_fd_value,
                                                TotalPropertyOwned = alapp.total_property_owned,
                                                TotalCarOwned = alapp.total_car_owned,
                                                OtherAsset = alapp.other_asset,
                                                MonthlyExpenditure = alapp.monthly_expenditure_vnd,
                                                CreateBy = alapp.created_by,
                                                CreateDate = alapp.created_date
                                            }).FirstOrDefaultAsync();

                        if (varApp != null)
                        {
                            objParam = varApp;
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CustomerDemostrationViewModel</returns>
        public async Task<CustomerDemostrationViewModel> Save(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            al_personal_application varData =
                                Mapper.Map<CustomerDemostrationViewModel, al_personal_application>(objParam);
                            context.al_personal_application.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            #region Exception
                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
