﻿using System;
using PagedList;
using System.Linq;
using AutoMapper;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CarDealerInformationRepository : RepositoryBase<CarDealerInformationViewModel>, ICarDealerInformationRepository
    {
        public CarDealerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public override void Add(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CarDealerInformationViewModel Get(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CarDealerInformationViewModel> GetMany(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CarDealerInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CarDealerInformationViewModel, bool>> where, Expression<Func<CarDealerInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>CarDealerInformationViewModel</returns>
        public async Task<CarDealerInformationViewModel> LoadIndex(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await (from alapp in context.al_personal_application
                                      join status in context.m_status on alapp.fk_status_id equals status.pk_id
                                      join type in context.m_type on alapp.fk_type_id equals type.pk_id
                                      join dealer in context.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                                      where alapp.fk_application_information_id == objParam.ApplicationInformationID
                                      && alapp.is_active == true
                                      select new CarDealerInformationViewModel
                                      {
                                          ALApplicationInformationID = alapp.pk_id,
                                          ApplicationInformationID = alapp.fk_application_information_id,
                                          ApplicationStatusID = alapp.fk_status_id,
                                          ApplicationStatus = status.name,
                                          ApplicationTypeID = alapp.fk_type_id,
                                          ApplicationType = type.name,
                                          CarDealerAddress = dealer.car_dealer_name,
                                          CarDealerCityID = dealer.fk_car_dealer_city_id,
                                          CarDealerDistrictID = dealer.fk_car_dealer_district_id,
                                          CarDealerWards = dealer.car_dealer_wards,
                                          CarDealerILCap = alapp.car_dealer_il_cap,
                                          CarDealerPromissoryDisbursementAvailableLimit = alapp.car_dealer_promissory_disbursement_available_limit,
                                          CarDealerTotalDisbursement = alapp.car_dealer_total_disbursement,
                                          CarDealerPromissoryDisbursementCap = alapp.car_dealer_promissory_disbursement_cap,
                                          CooperationContractActive = alapp.cooperation_contract_active,
                                          CreateBy = alapp.created_by,
                                          CreateDate = alapp.created_date
                                      }).FirstOrDefaultAsync();

                        if (varApp != null)
                        {
                            objParam = varApp;
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("CarDealerInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<CarDealerInformationViewModel> Save(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            al_personal_application varData =
                                Mapper.Map<CarDealerInformationViewModel, al_personal_application>(objParam);
                            context.al_personal_application.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            #region Exception

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("CarDealerInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }
        #endregion
    }
}
