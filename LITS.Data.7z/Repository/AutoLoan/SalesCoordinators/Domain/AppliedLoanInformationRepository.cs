﻿using System;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using System.Linq;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Core.Resources;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class AppliedLoanInformationRepository : RepositoryBase<AppliedLoanInformationViewModel>, IAppliedLoanInformationRepository
    {
        public AppliedLoanInformationRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        { }

        #region Base

        public override void Add(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new AppliedLoanInformationViewModel Get(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<AppliedLoanInformationViewModel> GetMany(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<AppliedLoanInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<AppliedLoanInformationViewModel, bool>> where, Expression<Func<AppliedLoanInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom
        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<AppliedLoanInformationViewModel> LoadIndex(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        #region LoadIndex
                        var varApp = await context.al_personal_application
                            .Where(p => p.pk_id == objParam.ApplicationInformationID && p.is_active == true)
                            .FirstOrDefaultAsync();

                        if (varApp != null)
                        {
                            objParam.ALApplicationInformationID = varApp.pk_id;
                            objParam.AmountRequested = varApp.amount_requested_vnd;
                            objParam.ApplicationInformationID = varApp.fk_application_information_id;
                            objParam.ApplicationStatusID = varApp.fk_status_id;
                            objParam.ApplicationTypeID = varApp.fk_type_id;
                            objParam.CampaignCodeID = varApp.fk_m_campaign_code_id;
                            objParam.CreateBy = varApp.created_by;
                            objParam.CreateDate = varApp.created_date;
                            objParam.CreditDeviationID = varApp.fk_m_credit_deviation_id;
                            objParam.FloatingInterestRateID = varApp.fk_m_floating_interest_rate_id;
                            objParam.IsActive = varApp.is_active;
                            objParam.LoanPurposeID = varApp.fk_m_loan_purpose_id;
                            objParam.LTV = varApp.ltv;
                            objParam.PaymentTypeID = varApp.fk_m_payment_type_id;
                            objParam.ProgramTypeID = varApp.fk_m_program_type_id;
                            objParam.ReasonForDeviationID = varApp.fk_m_reason_for_deviation_id;
                            objParam.TenorsID = varApp.fk_m_loan_tenor_id;
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("AppliedLoanInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<AppliedLoanInformationViewModel> Save(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            #region Save
                            al_personal_application varData =
                                    Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(objParam);
                            context.al_personal_application.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();
                            #endregion

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            #region Exception
                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                AreaName = AreaNameParam,
                                ControllerName = ControllerNameParam,
                                ActionName = "Submit",
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("AppliedLoanInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }
            return objParam;
        }
        #endregion
    }
}
