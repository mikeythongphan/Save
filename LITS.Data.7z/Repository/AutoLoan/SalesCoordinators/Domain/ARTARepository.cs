﻿using System;
using PagedList;
using AutoMapper;
using System.Linq;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class ARTARepository : RepositoryBase<ARTAViewModel>, IARTARepository
    {
        public ARTARepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public override void Add(ARTAViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(ARTAViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<ARTAViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new ARTAViewModel Get(Expression<Func<ARTAViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<ARTAViewModel> GetMany(Expression<Func<ARTAViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<ARTAViewModel> GetPage<TOrder>(Page page, Expression<Func<ARTAViewModel, bool>> where, Expression<Func<ARTAViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public new void Update(ARTAViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>ARTAViewModel</returns>
        public async Task<ARTAViewModel> LoadIndex(ARTAViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        #region LoadIndex
                        var varApp = await context.al_approval_information
                            .Where(p => p.fk_application_information_id == objParam.ApplicationInformationID && p.is_active == true)
                            .FirstOrDefaultAsync();

                        if (varApp != null)
                        {
                            objParam.ALApplicationInformationID = varApp.fk_al_application_information_id;
                            objParam.ApplicationInformationID = varApp.fk_application_information_id;
                            objParam.ApplicationNumber = varApp.application_number;
                            objParam.ApplicationStatusID = varApp.fk_status_id;
                            objParam.ApplicationTypeID = varApp.fk_type_id;
                            objParam.AppliedPremium = varApp.applied_premium;
                            objParam.AppliedSumAssured = varApp.applied_sum_assured;
                            objParam.ARTA = varApp.arta_credit_life;
                            objParam.CreateBy = varApp.created_by;
                            objParam.CreateDate = varApp.created_date;
                            objParam.IsActive = varApp.is_active;
                            objParam.LifeAssured = varApp.life_assured;
                            objParam.PaymentOptionID = varApp.fk_m_payment_type_id;
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns>ARTAViewModel</returns>
        public async Task<ARTAViewModel> Save(ARTAViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            #region Save
                            al_approval_information varData = Mapper.Map<ARTAViewModel, al_approval_information>(objParam);

                            context.al_approval_information.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();
                            #endregion

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            #region Exception
                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }
            return objParam;
        }

        #endregion
    }
}
