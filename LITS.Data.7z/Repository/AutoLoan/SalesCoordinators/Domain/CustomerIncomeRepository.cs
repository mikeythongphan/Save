﻿using System;
using PagedList;
using System.Linq;
using AutoMapper;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerIncomeRepository : RepositoryBase<CustomerIncomeViewModel>, ICustomerIncomeRepository
    {
        public CustomerIncomeRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public override void Add(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CustomerIncomeViewModel Get(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CustomerIncomeViewModel> GetMany(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CustomerIncomeViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerIncomeViewModel, bool>> where, Expression<Func<CustomerIncomeViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public async Task<CustomerIncomeViewModel> LoadIndex(CustomerIncomeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await context.application_information
                            .Where(p => p.pk_id == objParam.ApplicationInformationID)
                            .FirstOrDefaultAsync();

                        //if (varApp != null)
                        //    objParam = AutoMapper.Mapper.Map<application_information, CustomerIncomeViewModel>(varApp);

                        //var varAppDup = _LITSEntities.application_duplication
                        //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
                        //    .ToList();
                        //if (varAppDup != null)
                        //{
                        //    foreach (application_duplication obj in varAppDup)
                        //    {
                        //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
                        //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
                        //        ad.ApplicationInformationID = obj.pk_id;
                        //        ad.ApplicationNo = obj.application_no;
                        //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
                        //        ad.StatusID = obj.fk_status_id;
                        //        ad.ApplicationTypeID = obj.fk_type_id;
                        //        ad.CreatedBy = obj.created_by;
                        //        ad.CreatedDate = obj.created_date;

                        //        objParam._ApplicationDuplicationViewModel.Add(ad);
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "LoadIndex",
                            ProcessesId = (int)EnumList.Process.LITS,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        public async Task<CustomerIncomeViewModel> Save(CustomerIncomeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            customer_income varData =
                                Mapper.Map<CustomerIncomeViewModel, customer_income>(objParam);
                            context.customer_income.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
