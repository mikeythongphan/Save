﻿using System;
using PagedList;
using System.Linq;
using AutoMapper;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using LITS.Core.Resources;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerInformationRepository : RepositoryBase<CustomerInformationViewModel>, ICustomerInformationRepository
    {        
        public CustomerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}

        #region Base

        public override void Add(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new CustomerInformationViewModel Get(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<CustomerInformationViewModel> GetMany(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<CustomerInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerInformationViewModel, bool>> where, Expression<Func<CustomerInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public async Task<CustomerInformationViewModel> LoadIndex(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await context.application_information
                            .Where(p => p.pk_id == objParam._CustomerDetailViewModel_Main.ApplicationInformationID)
                            .FirstOrDefaultAsync();

                        //if (varApp != null)
                        //    objParam = AutoMapper.Mapper.Map<application_information, CustomerInformationViewModel>(varApp);

                        //var varAppDup = _LITSEntities.application_duplication
                        //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
                        //    .ToList();
                        //if (varAppDup != null)
                        //{
                        //    foreach (application_duplication obj in varAppDup)
                        //    {
                        //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
                        //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
                        //        ad.ApplicationInformationID = obj.pk_id;
                        //        ad.ApplicationNo = obj.application_no;
                        //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
                        //        ad.StatusID = obj.fk_status_id;
                        //        ad.ApplicationTypeID = obj.fk_type_id;
                        //        ad.CreatedBy = obj.created_by;
                        //        ad.CreatedDate = obj.created_date;

                        //        objParam._ApplicationDuplicationViewModel.Add(ad);
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        public async Task<CustomerInformationViewModel> Save(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            customer_information varData =
                                Mapper.Map<CustomerInformationViewModel, customer_information>(objParam);
                            context.customer_information.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
