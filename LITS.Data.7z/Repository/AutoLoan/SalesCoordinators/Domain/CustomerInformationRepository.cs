﻿using System;
using PagedList;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerInformationRepository : RepositoryBase<CustomerInformationViewModel>, ICustomerInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CustomerInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CustomerInformationViewModel Get(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CustomerInformationViewModel> GetMany(Expression<Func<CustomerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CustomerInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerInformationViewModel, bool>> where, Expression<Func<CustomerInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CustomerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CustomerInformationViewModel LoadIndex(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            //var varApp = _LITSEntities.application_information
            //    .FirstOrDefault(p => p.pk_id == objParam.ApplicationInformationID);

            //if (varApp != null)
            //    objParam = AutoMapper.Mapper.Map<application_information, CustomerInformationViewModel>(varApp);

            //var varAppDup = _LITSEntities.application_duplication
            //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
            //    .ToList();
            //if (varAppDup != null)
            //{
            //    foreach (application_duplication obj in varAppDup)
            //    {
            //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
            //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
            //        ad.ApplicationInformationID = obj.pk_id;
            //        ad.ApplicationNo = obj.application_no;
            //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
            //        ad.StatusID = obj.fk_status_id;
            //        ad.ApplicationTypeID = obj.fk_type_id;
            //        ad.CreatedBy = obj.created_by;
            //        ad.CreatedDate = obj.created_date;

            //        objParam._ApplicationDuplicationViewModel.Add(ad);
            //    }
            //}

            return objParam;
        }

        public CustomerInformationViewModel Save(CustomerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        #endregion
    }
}
