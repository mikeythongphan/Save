﻿using System;
using AutoMapper;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Domain.Main;
using LITS.Core.Resources;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class ApplicationInformationRepository : RepositoryBase<ApplicationInformationViewModel>, IApplicationInformationRepository
    {        
        public ApplicationInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}

        #region Base

        public override void Add(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new ApplicationInformationViewModel Get(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<ApplicationInformationViewModel> GetMany(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<ApplicationInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<ApplicationInformationViewModel, bool>> where, Expression<Func<ApplicationInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndex
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<ApplicationInformationViewModel> LoadIndex(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await context.application_information.FirstOrDefaultAsync(p => p.pk_id == objParam.ApplicationInformationID);

                        if (varApp != null)
                            objParam = Mapper.Map<application_information, ApplicationInformationViewModel>(varApp);

                        var varAppDup = await context.application_duplication
                            .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
                            .ToListAsync();

                        if (varAppDup != null && varAppDup.Count > 0)
                        {
                            objParam._ApplicationDuplicationViewModel =
                                Mapper.Map<List<application_duplication>, List<ApplicationDuplicationViewModel>>(varAppDup);                            
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public async Task<ApplicationInformationViewModel> Save(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            application_information varData = 
                                Mapper.Map<ApplicationInformationViewModel, application_information>(objParam);
                            context.application_information.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            #region Exception
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
