﻿using System;
using AutoMapper;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class ApplicationInformationRepository : RepositoryBase<ApplicationInformationViewModel>, IApplicationInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public ApplicationInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public override void Add(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public override void Delete(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new ApplicationInformationViewModel Get(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<ApplicationInformationViewModel> GetMany(Expression<Func<ApplicationInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IPagedList<ApplicationInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<ApplicationInformationViewModel, bool>> where, Expression<Func<ApplicationInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public override void Update(ApplicationInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public ApplicationInformationViewModel LoadIndex(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = context.application_information.FirstOrDefault(p => p.pk_id == objParam.ApplicationInformationID);

                        if (varApp != null)
                            objParam = Mapper.Map<application_information, ApplicationInformationViewModel>(varApp);

                        var varAppDup = _LITSEntities.application_duplication
                            .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
                            .ToList();

                        if (varAppDup != null)
                        {
                            foreach (application_duplication obj in varAppDup)
                            {
                                ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
                                ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
                                ad.ApplicationInformationID = obj.pk_id;
                                ad.ApplicationNo = obj.application_no;
                                ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
                                ad.StatusID = obj.fk_status_id;
                                ad.ApplicationTypeID = obj.fk_type_id;
                                ad.CreatedBy = obj.created_by;
                                ad.CreatedDate = obj.created_date;

                                objParam._ApplicationDuplicationViewModel.Add(ad);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        public ApplicationInformationViewModel Save(ApplicationInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            application_information data = Mapper.Map<ApplicationInformationViewModel, application_information>(objParam);
                            context.application_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = "",
                                ActionName = "",
                                AreaName = "",
                                ProcessesId = 4,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
