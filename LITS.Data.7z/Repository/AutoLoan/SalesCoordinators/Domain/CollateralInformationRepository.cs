﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Collections.Generic;
using LITS.Core.Resources;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Logging;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CollateralInformationRepository : RepositoryBase<CollateralInformationViewModel>, ICollateralInformationRepository
    {
        public CollateralInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

        #region Base

        public void Add(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CollateralInformationViewModel Get(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CollateralInformationViewModel> GetMany(Expression<Func<CollateralInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CollateralInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CollateralInformationViewModel, bool>> where, Expression<Func<CollateralInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CollateralInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public async Task<CollateralInformationViewModel> LoadIndex(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    try
                    {
                        var varApp = await (from alapp in context.al_personal_application
                                      join status in context.m_status on alapp.fk_status_id equals status.pk_id
                                      join type in context.m_type on alapp.fk_type_id equals type.pk_id
                                      join dealer in context.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                                      where alapp.fk_application_information_id == objParam.ApplicationInformationID
                                      && alapp.is_active == true
                                      select new CollateralInformationViewModel
                                      {
                                          ALApplicationInformationID = alapp.pk_id,
                                          ApplicationInformationID = alapp.fk_application_information_id,
                                          ApplicationStatusID = alapp.fk_status_id,
                                          ApplicationStatus = status.name,
                                          ApplicationTypeID = alapp.fk_type_id,
                                          ApplicationType = type.name,
                                          CarMarkerBrandID = alapp.fk_al_car_marker_brand_id,
                                          PropertyStatusID = alapp.fk_m_property_status_id,
                                          ModelID = alapp.fk_al_car_model_id,
                                          CarTypeID = alapp.fk_al_car_type_id,
                                          CarSourceID = alapp.fk_al_car_source_id,
                                          YearOfManufacture = alapp.year_of_manufacture,
                                          Color = alapp.color,
                                          NumberOfSeats = alapp.number_of_seats,
                                          ChassisNumber = alapp.chassis_number,
                                          PurchasingPriceOrFairMarketValue = alapp.purchasing_price,
                                          PurchasingSPContractNumber = alapp.purchasing_sp_contract_number,
                                          CollateralValue = alapp.collateral_value,
                                          CreateBy = alapp.created_by,
                                          CreateDate = alapp.created_date
                                      }).FirstOrDefaultAsync();

                        if (varApp != null)
                        {
                            objParam = varApp;
                        }
                    }
                    catch (Exception ex)
                    {
                        #region Exception
                        ExceptionLogger logger = new ExceptionLogger()
                        {
                            ExceptionMessage = ex.Message,
                            ExceptionStackTrace = ex.StackTrace,
                            AreaName = AreaNameParam,
                            ControllerName = ControllerNameParam,
                            ActionName = "Submit",
                            ProcessesId = 4,
                            LogBy = UserPWIDParam,
                            LogTime = DateTime.Now
                        };

                        LogHelper.WriteLogError(
                            "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                            , ex, logger, true);
                        #endregion
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::LoadIndex::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        public async Task<CollateralInformationViewModel> Save(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            using (var context = new LITSEntities())
            {
                if (context.Database.Exists())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            al_personal_application varData =
                                Mapper.Map<CollateralInformationViewModel, al_personal_application>(objParam);
                            context.al_personal_application.Attach(varData);
                            context.Entry(varData).State = EntityState.Modified;
                            await context.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();

                            #region Exception

                            ExceptionLogger logger = new ExceptionLogger()
                            {
                                ExceptionMessage = ex.Message,
                                ExceptionStackTrace = ex.StackTrace,
                                ControllerName = ControllerNameParam,
                                ActionName = "Save",
                                AreaName = AreaNameParam,
                                ProcessesId = (int)EnumList.Process.LITS,
                                LogBy = UserPWIDParam,
                                LogTime = DateTime.Now
                            };

                            LogHelper.WriteLogError(
                                "[" + AreaNameParam + "]" + "[" + ControllerNameParam + "]" + "[Save]" + "]"
                                , ex, logger, true);
                            #endregion
                        }
                    }
                }
                else
                {
                    LogHelper.WriteLogWarning("ApplicationInformationRepository::Save::ConnectionFailure::LITSEntities");
                }
            }

            return objParam;
        }

        #endregion
    }
}
