﻿using System;
using PagedList;
using System.Linq.Expressions;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class ApprovalInformationRepository : RepositoryBase<ApprovalInformationViewModel>, IApprovalInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public ApprovalInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(ApprovalInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(ApprovalInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<ApprovalInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public ApprovalInformationViewModel Get(Expression<Func<ApprovalInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<ApprovalInformationViewModel> GetMany(Expression<Func<ApprovalInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<ApprovalInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<ApprovalInformationViewModel, bool>> where, Expression<Func<ApprovalInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(ApprovalInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom
        public ApprovalInformationViewModel LoadIndex(ApprovalInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varApp = _LITSEntities.approval_information
                .Where(p => p.pk_id == objParam.ApplicationInformationID && p.is_active == true).FirstOrDefault();

            if (varApp != null)
            {
                objParam.ALApplicationInformationID = varApp.pk_id;
                objParam.ApplicationInformationID = varApp.fk_application_information_id;
                objParam.ApplicationStatusID = varApp.fk_status_id;
                objParam.ApplicationTypeID = varApp.fk_type_id;
                objParam.ApprovalCondition = string.Empty;
                objParam.CreateBy = varApp.created_by;
                objParam.CreateDate = varApp.created_date;
                objParam.CancelReasonID = varApp.fk_cancel_reason_id;
                objParam.CommercialInterest = varApp.commercial_interest;
                objParam.IsActive = varApp.is_active;
                objParam.CurrentOutStandingAtSCB = varApp.current_out_standing_at_scb;
                objParam.LTV = varApp.ltv;
                objParam.DateOfDecision = varApp.date_of_decision;
                objParam.DBR2Added = varApp.dbr_percent_added;
            }

            return objParam;
        }

        public ApprovalInformationViewModel Save(ApprovalInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
