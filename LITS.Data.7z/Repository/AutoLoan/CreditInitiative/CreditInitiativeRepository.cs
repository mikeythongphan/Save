﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CreditInitiativeRepository : RepositoryBase<CreditInitiativeViewModel>, ICreditInitiativeRepository
    {
        private LITSEntities _LITSEntities;

        public CreditInitiativeRepository(IDatabaseFactory databaseFactory,
           LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public CreditInitiativeViewModel LoadIndex(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Save(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel ByPass(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel SendBackSC(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel SendBackOS(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Recommend(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Reject(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Cancel(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Approved(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel ReturnCI(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel Print(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel NSG(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel RequeueTeleVerifier(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel DownloadIncomeSheet(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public CreditInitiativeViewModel FRMQueue(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
    }
}
