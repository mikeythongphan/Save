﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class LoanPurposeRepository : RepositoryBase<LoanPurposeViewModel>, ILoanPurposeRepository
    {
        private LITSEntities _LITSEntities;
        public LoanPurposeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_loan_purpose entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_loan_purpose entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_loan_purpose, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_loan_purpose Get(Expression<Func<m_loan_purpose, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_loan_purpose> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_loan_purpose GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_loan_purpose GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_loan_purpose> GetMany(Expression<Func<m_loan_purpose, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_loan_purpose> GetPage<TOrder>(Page page, Expression<Func<m_loan_purpose, bool>> where, Expression<Func<m_loan_purpose, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_loan_purpose entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<LoanPurposeViewModel> GetListActiveAll()
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListActiveById(int? Id)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListAll()
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListById(int? Id)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<LoanPurposeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_loan_purpose> objList = _LITSEntities.m_loan_purpose.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<LoanPurposeViewModel> resultList = new List<LoanPurposeViewModel>();
            foreach (m_loan_purpose temp in objList)
            {
                LoanPurposeViewModel data = Mapper.Map<m_loan_purpose, LoanPurposeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(LoanPurposeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<LoanPurposeViewModel, m_loan_purpose>(model[0]);
                            data.is_active = false;
                            context.m_loan_purpose.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(LoanPurposeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_loan_purpose data = AutoMapper.Mapper.Map<LoanPurposeViewModel, m_loan_purpose>(objModel);
                        context.m_loan_purpose.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(LoanPurposeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_loan_purpose data = Mapper.Map<LoanPurposeViewModel, m_loan_purpose>(objModel);
                        context.m_loan_purpose.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
