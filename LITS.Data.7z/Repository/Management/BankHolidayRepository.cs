﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class BankHolidayRepository : RepositoryBase<BankHolidayViewModel>, IBankHolidayRepository
    {
        private LITSEntities _LITSEntities;

        public BankHolidayRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_bank_holiday entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_bank_holiday entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_bank_holiday, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_bank_holiday Get(Expression<Func<m_bank_holiday, bool>> where)
        {
            throw new NotImplementedException();
        }

        public new IEnumerable<m_bank_holiday> GetAll()
        {
            throw new NotImplementedException();
        }

        public new m_bank_holiday GetById(long id)
        {
            throw new NotImplementedException();
        }

        public new m_bank_holiday GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_bank_holiday> GetMany(Expression<Func<m_bank_holiday, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_bank_holiday> GetPage<TOrder>(Page page, Expression<Func<m_bank_holiday, bool>> where, Expression<Func<m_bank_holiday, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_bank_holiday entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<BankHolidayViewModel> GetListActiveAll()
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListActiveById(int? Id)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListAll()
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListById(int? Id)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BankHolidayViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_bank_holiday> objList = _LITSEntities.m_bank_holiday.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<BankHolidayViewModel> resultList = new List<BankHolidayViewModel>();
            foreach (m_bank_holiday temp in objList)
            {
                BankHolidayViewModel data = Mapper.Map<m_bank_holiday, BankHolidayViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public new bool Delete(BankHolidayViewModel objModel)
        {
            using(var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if(model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<BankHolidayViewModel, m_bank_holiday>(model[0]);
                            data.is_active = false;
                            context.m_bank_holiday.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public bool Create(BankHolidayViewModel objModel)
        {
            using(var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bank_holiday data = AutoMapper.Mapper.Map<BankHolidayViewModel, m_bank_holiday>(objModel);
                        context.m_bank_holiday.Add(data);
                      //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }           
        }

        public new bool Update(BankHolidayViewModel objModel)
        {
            using(var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bank_holiday data = Mapper.Map<BankHolidayViewModel, m_bank_holiday>(objModel);
                        context.m_bank_holiday.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }            
        }
        #endregion
    }
}
