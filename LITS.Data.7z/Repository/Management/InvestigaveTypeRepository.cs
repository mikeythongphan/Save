﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class InvestigaveTypeRepository : RepositoryBase<InvestigaveTypeViewModel>, IInvestigaveTypeRepository
    {
        private LITSEntities _LITSEntities;

        public InvestigaveTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_investigave_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_investigave_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_investigave_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_investigave_type Get(Expression<Func<m_investigave_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_investigave_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_investigave_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_investigave_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_investigave_type> GetMany(Expression<Func<m_investigave_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_investigave_type> GetPage<TOrder>(Page page, Expression<Func<m_investigave_type, bool>> where, Expression<Func<m_investigave_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_investigave_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<InvestigaveTypeViewModel> GetListActiveAll()
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListAll()
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListById(int? Id)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InvestigaveTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_investigave_type> objList = _LITSEntities.m_investigave_type.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<InvestigaveTypeViewModel> resultList = new List<InvestigaveTypeViewModel>();
            foreach (m_investigave_type temp in objList)
            {
                InvestigaveTypeViewModel data = Mapper.Map<m_investigave_type, InvestigaveTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(InvestigaveTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<InvestigaveTypeViewModel, m_investigave_type>(model[0]);
                            data.is_active = false;
                            context.m_investigave_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(InvestigaveTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_investigave_type data = AutoMapper.Mapper.Map<InvestigaveTypeViewModel, m_investigave_type>(objModel);
                        context.m_investigave_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(InvestigaveTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_investigave_type data = Mapper.Map<InvestigaveTypeViewModel, m_investigave_type>(objModel);
                        context.m_investigave_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
