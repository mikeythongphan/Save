﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class MaritalStatusRepository : RepositoryBase<MaritalStatusViewModel>, IMaritalStatusRepository
    {
        private LITSEntities _LITSEntities;

        public MaritalStatusRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_marital_status entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_marital_status entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_marital_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_marital_status Get(Expression<Func<m_marital_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_marital_status> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_marital_status GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_marital_status GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_marital_status> GetMany(Expression<Func<m_marital_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_marital_status> GetPage<TOrder>(Page page, Expression<Func<m_marital_status, bool>> where, Expression<Func<m_marital_status, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_marital_status entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<MaritalStatusViewModel> GetListActiveAll()
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListActiveById(int? Id)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListAll()
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListById(int? Id)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MaritalStatusViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_marital_status> objList = _LITSEntities.m_marital_status.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<MaritalStatusViewModel> resultList = new List<MaritalStatusViewModel>();
            foreach (m_marital_status temp in objList)
            {
                MaritalStatusViewModel data = Mapper.Map<m_marital_status, MaritalStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(MaritalStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<MaritalStatusViewModel, m_marital_status>(model[0]);
                            data.is_active = false;
                            context.m_marital_status.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(MaritalStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_marital_status data = AutoMapper.Mapper.Map<MaritalStatusViewModel, m_marital_status>(objModel);
                        context.m_marital_status.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(MaritalStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_marital_status data = Mapper.Map<MaritalStatusViewModel, m_marital_status>(objModel);
                        context.m_marital_status.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
