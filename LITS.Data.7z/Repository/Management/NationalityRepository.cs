﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class NationalityRepository : RepositoryBase<NationalityViewModel>, INationalityRepository
    {
        private LITSEntities _LITSEntities;

        public NationalityRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_nationality entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_nationality entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_nationality, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_nationality Get(Expression<Func<m_nationality, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_nationality> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_nationality GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_nationality GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_nationality> GetMany(Expression<Func<m_nationality, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_nationality> GetPage<TOrder>(Page page, Expression<Func<m_nationality, bool>> where, Expression<Func<m_nationality, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_nationality entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<NationalityViewModel> GetListActiveAll()
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListActiveById(int? Id)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListAll()
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListById(int? Id)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<NationalityViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_nationality> objList = _LITSEntities.m_nationality.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<NationalityViewModel> resultList = new List<NationalityViewModel>();
            foreach (m_nationality temp in objList)
            {
                NationalityViewModel data = Mapper.Map<m_nationality, NationalityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(NationalityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<NationalityViewModel, m_nationality>(model[0]);
                            data.is_active = false;
                            context.m_nationality.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(NationalityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_nationality data = AutoMapper.Mapper.Map<NationalityViewModel, m_nationality>(objModel);
                        context.m_nationality.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(NationalityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_nationality data = Mapper.Map<NationalityViewModel, m_nationality>(objModel);
                        context.m_nationality.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
