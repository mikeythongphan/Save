﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class IncomeTypeRepository : RepositoryBase<IncomeTypeViewModel>, IIncomeTypeRepository
    {
        private LITSEntities _LITSEntities;

        public IncomeTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_income_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_income_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_income_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_income_type Get(Expression<Func<m_income_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_income_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_income_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_income_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_income_type> GetMany(Expression<Func<m_income_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_income_type> GetPage<TOrder>(Page page, Expression<Func<m_income_type, bool>> where, Expression<Func<m_income_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_income_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<IncomeTypeViewModel> GetListActiveAll()
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListAll()
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListById(int? Id)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IncomeTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_income_type> objList = _LITSEntities.m_income_type.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<IncomeTypeViewModel> resultList = new List<IncomeTypeViewModel>();
            foreach (m_income_type temp in objList)
            {
                IncomeTypeViewModel data = Mapper.Map<m_income_type, IncomeTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(IncomeTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<IncomeTypeViewModel, m_income_type>(model[0]);
                            data.is_active = false;
                            context.m_income_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(IncomeTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_income_type data = AutoMapper.Mapper.Map<IncomeTypeViewModel, m_income_type>(objModel);
                        context.m_income_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(IncomeTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_income_type data = Mapper.Map<IncomeTypeViewModel, m_income_type>(objModel);
                        context.m_income_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
