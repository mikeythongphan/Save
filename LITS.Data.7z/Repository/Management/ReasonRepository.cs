﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class ReasonRepository : RepositoryBase<ReasonViewModel>, IReasonRepository
    {
        private LITSEntities _LITSEntities;
        public ReasonRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_reason entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_reason entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_reason, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_reason Get(Expression<Func<m_reason, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_reason> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_reason GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_reason GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_reason> GetMany(Expression<Func<m_reason, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_reason> GetPage<TOrder>(Page page, Expression<Func<m_reason, bool>> where, Expression<Func<m_reason, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_reason entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<ReasonViewModel> GetListActiveAll()
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListActiveById(int? Id)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListAll()
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListById(int? Id)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ReasonViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_reason> objList = _LITSEntities.m_reason.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<ReasonViewModel> resultList = new List<ReasonViewModel>();
            foreach (m_reason temp in objList)
            {
                ReasonViewModel data = Mapper.Map<m_reason, ReasonViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(ReasonViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<ReasonViewModel, m_reason>(model[0]);
                            data.is_active = false;
                            context.m_reason.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(ReasonViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_reason data = AutoMapper.Mapper.Map<ReasonViewModel, m_reason>(objModel);
                        context.m_reason.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(ReasonViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_reason data = Mapper.Map<ReasonViewModel, m_reason>(objModel);
                        context.m_reason.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
