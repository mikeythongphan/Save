﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class SettingLimitRepository : RepositoryBase<SettingLimitViewModel>, ISettingLimitRepository
    {
        private LITSEntities _LITSEntities;

        public SettingLimitRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_setting_limit entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_setting_limit entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_setting_limit, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_setting_limit Get(Expression<Func<m_setting_limit, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_setting_limit> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_setting_limit GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_setting_limit GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_setting_limit> GetMany(Expression<Func<m_setting_limit, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_setting_limit> GetPage<TOrder>(Page page, Expression<Func<m_setting_limit, bool>> where, Expression<Func<m_setting_limit, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_setting_limit entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<SettingLimitViewModel> GetListActiveAll()
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListActiveById(int? Id)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListAll()
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListById(int? Id)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListByParentId(int? ParentId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.parent_id == ParentId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SettingLimitViewModel> GetListActiveByParentId(int? ParentId)
        {
            List<m_setting_limit> objList = _LITSEntities.m_setting_limit.ToList();
            objList = objList.Where(p => p.is_active == true && p.parent_id == ParentId).ToList();
            List<SettingLimitViewModel> resultList = new List<SettingLimitViewModel>();
            foreach (m_setting_limit temp in objList)
            {
                SettingLimitViewModel data = Mapper.Map<m_setting_limit, SettingLimitViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(SettingLimitViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<SettingLimitViewModel, m_setting_limit>(model[0]);
                            data.is_active = false;
                            context.m_setting_limit.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(SettingLimitViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_setting_limit data = AutoMapper.Mapper.Map<SettingLimitViewModel, m_setting_limit>(objModel);
                        context.m_setting_limit.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(SettingLimitViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_setting_limit data = Mapper.Map<SettingLimitViewModel, m_setting_limit>(objModel);
                        context.m_setting_limit.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
