﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class PropertyStatusRepository : RepositoryBase<PropertyStatusViewModel>, IPropertyStatusRepository
    {
        private LITSEntities _LITSEntities;
        public PropertyStatusRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_property_status entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_property_status entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_property_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_property_status Get(Expression<Func<m_property_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_property_status> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_property_status GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_property_status GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_property_status> GetMany(Expression<Func<m_property_status, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_property_status> GetPage<TOrder>(Page page, Expression<Func<m_property_status, bool>> where, Expression<Func<m_property_status, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_property_status entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<PropertyStatusViewModel> GetListActiveAll()
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.is_active == true).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListActiveById(int? Id)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListAll()
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListById(int? Id)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.pk_id == Id).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PropertyStatusViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_property_status> objList = _LITSEntities.m_property_status.ToList();
            objList = objList.Where(p => p.fk_type_id == TypeId).ToList();
            List<PropertyStatusViewModel> resultList = new List<PropertyStatusViewModel>();
            foreach (m_property_status temp in objList)
            {
                PropertyStatusViewModel data = Mapper.Map<m_property_status, PropertyStatusViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(PropertyStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<PropertyStatusViewModel, m_property_status>(model[0]);
                            data.is_active = false;
                            context.m_property_status.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(PropertyStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_property_status data = AutoMapper.Mapper.Map<PropertyStatusViewModel, m_property_status>(objModel);
                        context.m_property_status.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(PropertyStatusViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_property_status data = Mapper.Map<PropertyStatusViewModel, m_property_status>(objModel);
                        context.m_property_status.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
