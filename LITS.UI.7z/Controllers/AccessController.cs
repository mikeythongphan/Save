﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using LITS.UI.Models;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System.Data.Entity;
using System.Threading.Tasks;
using LITS.Infrastructure.Common;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;

namespace LITS.UI.Controllers
{
    [Description("Access")]
    public class AccessController : BaseController
    {
        private ApplicationDbContext _dbContext;

        public AccessController(IUnitOfWorkManager unitOfWorkManager,
            ApplicationDbContext dbContext)
            : base(unitOfWorkManager)
        {
            this._dbContext = dbContext;
        }

        // GET: Access
        [Description("Access List")]
        public async Task<ActionResult> Index()
        {
            _dbContext = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
            var users = await (from u in _dbContext.Users
                               select new
                               {
                                   UserId = u.Id,
                                   u.UserName,
                                   Roles = _dbContext.Roles.Where(r => u.Roles.Any(ur => ur.RoleId == r.Id)).Select(r => r.Name)
                               }).Select(ra => new UserRoleViewModel
                               {
                                   UserId = ra.UserId,
                                   UserName = ra.UserName,
                                   Roles = ra.Roles
                               }).ToListAsync();

            //return View(users);
            return View("~/Views/Access/Index.cshtml", users);
        }

        // GET: Access/Edit
        [Description("Edit Access")]
        public async Task<ActionResult> Edit(string id)
        {
            _dbContext = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
            var user = await (from u in _dbContext.Users
                              select new
                              {
                                  UserId = u.Id,
                                  u.UserName,
                                  Roles = _dbContext.Roles.Where(r => u.Roles.Any(ur => ur.RoleId == r.Id)).Select(r => r.Name)
                              }).SingleOrDefaultAsync(u => u.UserId == id);
            if (user == null)
                return HttpNotFound();

            var roles = await _dbContext.Roles.ToListAsync();

            var viewModel = new EditUserRoleViewModel
            {
                UserId = user.UserId,
                UserName = user.UserName,
                SelectedRoles = user.Roles,
                Roles = roles
            };

            return View(viewModel);
        }

        // POST: Access/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(EditUserRoleViewModel viewModel)
        {
            _dbContext = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
            if (!ModelState.IsValid)
            {
                viewModel.Roles = await _dbContext.Roles.ToListAsync();
                return View(viewModel);
            }

            var user = _dbContext.Users.Find(viewModel.UserId);
            user.Roles.Clear();
            foreach (var roleId in viewModel.SelectedRoles)
            {
                user.Roles.Add(new IdentityUserRole { RoleId = roleId });
            }
            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}