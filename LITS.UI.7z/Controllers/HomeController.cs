﻿using System.Web.Mvc;
using System.ComponentModel;
using LITS.Infrastructure.Configuration;
using LITS.Model.Views.Main;
using LITS.Interface.Service.Management;


namespace LITS.UI.Controllers
{
    [Authorize]
    [Description("Home")]
    public class HomeController : BaseController
    {
        private readonly LITS.Interface.Service.Main.WorkInProgress.IWorkInProgressService _WorkInProgressService;
        private readonly LITS.Interface.Service.Main.CreateNewLoan.ICreateNewLoanService _CreateNewLoanService;

        public HomeController(IUnitOfWorkManager unitOfWorkManager, IMessageService messageService,
            LITS.Interface.Service.Main.WorkInProgress.IWorkInProgressService workInProgressService,
            LITS.Interface.Service.Main.CreateNewLoan.ICreateNewLoanService CreateNewLoanService)
            : base(unitOfWorkManager, messageService)
        {
            this._CreateNewLoanService = CreateNewLoanService;
            this._WorkInProgressService = workInProgressService;
        }

        [Description("Index")]
        public ActionResult Index()
        {                       
            return View();
        }

        [Description("About us")]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        [Description("Contact us")]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}