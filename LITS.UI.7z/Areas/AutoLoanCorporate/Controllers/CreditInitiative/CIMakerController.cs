﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Model.Views.Main;
using LITS.UI.Custom;

namespace LITS.UI.Areas.AutoLoanCorporate.Controllers
{
    [Authorize]
    public class CIMakerController : Controller
    {

        #region variables



        #endregion

        // GET: CIMaker
        [ExceptionHandler]
        public ActionResult Index()
        {
            return View("~/Areas/AutoLoanCorporate/Views/CreditInitiative/CreditInitiative.cshtml");
        }

        #region ApplicationInput

        public ActionResult _ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        #endregion

        #region CompanyIncome

        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMVATGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMVATGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMVATGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMVATGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }


        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMBankGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMBankGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMBankGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_TypeOfIGMBankGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }


        public ActionResult CreditInitiative_CompanyIncome_CPPGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_CPPGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_CPPGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_CPPGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }

        public ActionResult CreditInitiative_CompanyIncome_OtherIncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_OtherIncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_OtherIncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult CreditInitiative_CompanyIncome_OtherIncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        #endregion

        #region BorrowerCreditBureau
        public ActionResult CreditInitiative_BorrowerCreditBureau_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }

        public ActionResult CreditInitiative_BorrowerCreditBureau_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult CreditInitiative_BorrowerCreditBureau_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        #endregion

        #region LegalRepresentativeInformation
        public ActionResult CreditInitiative_LegalInformation_IdentifCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult CreditInitiative_LegalInformation_IdentifCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult CreditInitiative_LegalInformation_IdentifCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult CreditInitiative_LegalInformation_IdentifCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }
        #endregion

        #region ElegibilityCheck
        public ActionResult CreditInitiative_ElegibilityCheck_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ElegibilityCheck/_ElegibilityCheck_Grid.cshtml");
        }

        public ActionResult CreditInitiative_ElegibilityCheck_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ElegibilityCheck/_ElegibilityCheck_Grid.cshtml");
        }

        public ActionResult CreditInitiative_ElegibilityCheck_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ElegibilityCheck/_ElegibilityCheck_Grid.cshtml");
        }

        public ActionResult CreditInitiative_ElegibilityCheck_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/ElegibilityCheck/_ElegibilityCheck_Grid.cshtml");
        }
        #endregion

        #region Log
        public ActionResult CreditInitiative_Log_PendingLogGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_PendingLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_PendingLogGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_PendingLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_PendingLogGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_PendingLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_PendingLogGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_PendingLogGrid.cshtml");
        }


        public ActionResult CreditInitiative_Log_TeleSendbackLogGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_TeleSendbackLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_TeleSendbackLogGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_TeleSendbackLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_TeleSendbackLogGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_TeleSendbackLogGrid.cshtml");
        }
        public ActionResult CreditInitiative_Log_TeleSendbackLogGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/CreditInitiative/PartialViews/Log/_Log_TeleSendbackLogGrid.cshtml");
        }
        #endregion
    }
}
