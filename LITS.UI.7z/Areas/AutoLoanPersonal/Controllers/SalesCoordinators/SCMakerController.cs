﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

#region Infrastructure
using LITS.UI.Custom;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
#endregion

#region Interface

using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Interface.Service.AutoLoan.SalesCoordinators;

#endregion 

#region Service

using LITS.Service.AutoLoan.SalesCoordinators;

#endregion

#region Model

using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;

#endregion

namespace LITS.UI.Areas.AutoLoanPersonal.Controllers
{
    public class SCMakerController : BaseController
    {
        private readonly ISalesCoordinatorsService _SalesCoordinatorsService;
        private readonly IApplicationInformationService _ApplicationInformationService;
        private readonly ICustomerInformationService _CustomerInformationService;
        private readonly ICustomerCreditBureauService _CustomerCreditBureauService;
        private readonly ICustomerDemostrationService _CustomerDemostrationService;
        private readonly ICustomerIncomeService _CustomerIncomeService;
        private readonly IAppliedLoanInformationService _AppliedLoanInformationService;
        private readonly IARTAService _ARTAService;

        public SCMakerController(ISalesCoordinatorsService SalesCoordinatorsService,
            IApplicationInformationService ApplicationInformationService,
            ICustomerInformationService CustomerInformationService,
            ICustomerCreditBureauService CustomerCreditBureauService,
            ICustomerDemostrationService CustomerDemostrationService,
            ICustomerIncomeService CustomerIncomeService,
            IAppliedLoanInformationService AppliedLoanInformationService,
            IARTAService ARTAService,
        IUnitOfWorkManager unitOfWorkManager)
            : base(unitOfWorkManager)
        {
            this._SalesCoordinatorsService = SalesCoordinatorsService;
            this._ApplicationInformationService = ApplicationInformationService;
            this._CustomerInformationService = CustomerInformationService;
            this._CustomerCreditBureauService = CustomerCreditBureauService;
            this._CustomerDemostrationService = CustomerDemostrationService;
            this._CustomerIncomeService = CustomerIncomeService;
            this._AppliedLoanInformationService = AppliedLoanInformationService;
            this._ARTAService = ARTAService;
        }

        #region Variables
        const string AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid = "AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid";
        const string AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid = "AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid";
        const string SalesCoordinators_CustomersInformation_MainBorrower_IdentifyCationGrid = "SalesCoordinators_CustomersInformation_MainBorrower_IdentifyCationGrid";
        #endregion

        // GET: SCMaker
        [ExceptionHandler]
        public ActionResult Index(int? Id)
        {
            Id = 8;

            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            SalesCoordinatorsViewModel obj = new SalesCoordinatorsViewModel();

            obj._ApplicationInformationViewModel.ApplicationInformationID = (int)Id;

            //Edit form
            if (Id.HasValue && Id > 0)
            {
                obj = _SalesCoordinatorsService.LoadIndex(obj, area, controller, User.Identity.Name);
                Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid] = obj._ApplicationInformationViewModel._ApplicationDuplicationViewModel;
            }
            //New form
            else
            {
                obj = new SalesCoordinatorsViewModel();
                Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid] = obj._ApplicationInformationViewModel._ApplicationDuplicationViewModel;
            }

            return View("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/SalesCoordinators.cshtml", obj);
        }

        #region ApplicationInput_DeduplicateGrid

        public ActionResult ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }


        #endregion

        #region CustomersInformation

        #region _MainBorrower_IdentifyCationGrid
        public ActionResult MainBorrower_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        #endregion

        #region _CoBorrower1_IdentifyCationGrid
        public ActionResult CoBorrower1_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        #endregion

        #region _CoBorrower2_IdentifyCationGrid
        public ActionResult _CoBorrower2_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        #endregion

        #region _CoBorrower2_IdentifyCationGrid
        public ActionResult CoBorrower3_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        #endregion

        #endregion

        #region CustomersIncome

        #region MainBorrower

        #region SalariedClient

        #region Income1
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        #endregion

        #region CarRentalIncome
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }


        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }


        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }

        public ActionResult SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }

        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        #endregion

        #endregion

        #region CoBorrower1

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml");
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml");
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml");
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGridCallback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        #endregion

        #endregion

        #region CoBorrower2

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower2/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower2/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower2/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower2/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }


        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        #endregion

        #endregion

        #region CoBorrower3

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }

        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }


        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        #endregion

        #endregion

        #endregion

        #region CustomersCreditBureau

        #region CoBorrower1
        public ActionResult CoBorrower1_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }

        public ActionResult CoBorrower1_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        #endregion

        #region CoBorrower2
        public ActionResult CoBorrower2_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }

        public ActionResult CoBorrower2_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        #endregion

        #region CoBorrower3
        public ActionResult CoBorrower3_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }

        public ActionResult CoBorrower3_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        #endregion

        #region MainBorrower
        public ActionResult MainBorrower_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }

        public ActionResult MainBorrower_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml",Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        #endregion

        #endregion

        #region CarSalesInformation
        public ActionResult CarSalesInformation_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }
        #endregion


    }
}
