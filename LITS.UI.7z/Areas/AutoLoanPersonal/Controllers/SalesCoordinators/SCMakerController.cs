﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;

#region Infrastructure
using LITS.UI.Custom;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
#endregion

#region Interface
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Interface.Service.AutoLoan.SalesCoordinators;
using LITS.Interface.Service.Management;
#endregion 

#region Service

using LITS.Service.AutoLoan.SalesCoordinators;

#endregion

#region Model

using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;
using LITS.Model.Domain.Main;
using LITS.Model.Domain.AutoLoan;


#endregion

namespace LITS.UI.Areas.AutoLoanPersonal.Controllers
{
    [Authorize]
    public class SCMakerController : BaseController
    {
        private readonly ISalesCoordinatorsService _SalesCoordinatorsService;
        private readonly IApplicationInformationService _ApplicationInformationService;
        private readonly ICustomerInformationService _CustomerInformationService;
        private readonly ICustomerCreditBureauService _CustomerCreditBureauService;
        private readonly ICustomerDemostrationService _CustomerDemostrationService;
        private readonly ICustomerIncomeService _CustomerIncomeService;
        private readonly IAppliedLoanInformationService _AppliedLoanInformationService;
        private readonly IARTAService _ARTAService;

        public SCMakerController(ISalesCoordinatorsService SalesCoordinatorsService,
            IApplicationInformationService ApplicationInformationService,
            ICustomerInformationService CustomerInformationService,
            ICustomerCreditBureauService CustomerCreditBureauService,
            ICustomerDemostrationService CustomerDemostrationService,
            ICustomerIncomeService CustomerIncomeService,
            IAppliedLoanInformationService AppliedLoanInformationService,
            IARTAService ARTAService,
            IUnitOfWorkManager unitOfWorkManager, IMessageService messageService)
            : base(unitOfWorkManager, messageService)
        {
            this._SalesCoordinatorsService = SalesCoordinatorsService;
            this._ApplicationInformationService = ApplicationInformationService;
            this._CustomerInformationService = CustomerInformationService;
            this._CustomerCreditBureauService = CustomerCreditBureauService;
            this._CustomerDemostrationService = CustomerDemostrationService;
            this._CustomerIncomeService = CustomerIncomeService;
            this._AppliedLoanInformationService = AppliedLoanInformationService;
            this._ARTAService = ARTAService;
        }

        #region Variables
        // Session grid
        const string AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid = "AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid";
        const string AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid = "AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid";
        const string AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid = "AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid";
        const string SalesCoordinators_CustomersInformation_MainBorrower_IdentifyCationGrid = "SalesCoordinators_CustomersInformation_MainBorrower_IdentifyCationGrid";

        // Session meta data
        const string AutoLoanPersonal_SalesCoordinators_M_ProductViewModel = "AutoLoanPersonal_SalesCoordinators_M_ProductViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_ProgramTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_ProgramTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PaymentTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_PaymentTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PropertySaleViewModel = "AutoLoanPersonal_SalesCoordinators_M_PropertySaleViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PropertyStatusViewModel = "AutoLoanPersonal_SalesCoordinators_M_PropertyStatusViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PropertyTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_PropertyTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_StatusViewModel = "AutoLoanPersonal_SalesCoordinators_M_StatusViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_TradingAreaViewModel = "AutoLoanPersonal_SalesCoordinators_M_TradingAreaViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_TypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_TypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_BranchCodeViewModel = "AutoLoanPersonal_SalesCoordinators_M_BranchCodeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_BranchLocationViewModel = "AutoLoanPersonal_SalesCoordinators_M_BranchLocationViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_LoanPurposeViewModel = "AutoLoanPersonal_SalesCoordinators_M_LoanPurposeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_LoanTenorViewModel = "AutoLoanPersonal_SalesCoordinators_M_LoanTenorViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_FloatingInterestRateViewModel = "AutoLoanPersonal_SalesCoordinators_M_FloatingInterestRateViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CustomerTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CustomerTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_SalesChannelViewModel = "AutoLoanPersonal_SalesCoordinators_M_SalesChannelViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CustomerSegmentViewModel = "AutoLoanPersonal_SalesCoordinators_M_CustomerSegmentViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_ReasonViewModel = "AutoLoanPersonal_SalesCoordinators_M_ReasonViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CDDViewModel = "_M_CDDViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CicViewModel = "AutoLoanPersonal_SalesCoordinators_M_CicViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CityViewModel = "AutoLoanPersonal_SalesCoordinators_M_CityViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CompanyTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CompanyTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_BusinessNatureViewModel = "AutoLoanPersonal_SalesCoordinators_M_BusinessNatureViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_BusinessTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_BusinessTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_BorrowerTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_BorrowerTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_IndustryViewModel = "AutoLoanPersonal_SalesCoordinators_M_IndustryViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_OccupationViewModel = "AutoLoanPersonal_SalesCoordinators_M_OccupationViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_EmploymentTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_EmploymentTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_LabourContractTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_LabourContractTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_IncomeTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_IncomeTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CreditBureauTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CreditBureauTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CampaignCodeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CampaignCodeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CreditDeviationViewModel = "AutoLoanPersonal_SalesCoordinators_M_CreditDeviationViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CustomerRelationshipViewModel = "AutoLoanPersonal_SalesCoordinators_M_CustomerRelationshipViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CompanyCodeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CompanyCodeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarRepaymentCycle = "AutoLoanPersonal_SalesCoordinators_M_CarRepaymentCycle";
        const string AutoLoanPersonal_SalesCoordinators_M_HouseRepaymentCycle = "AutoLoanPersonal_SalesCoordinators_M_HouseRepaymentCycle";
        const string AutoLoanPersonal_SalesCoordinators_M_PaymentMethodViewModel = "AutoLoanPersonal_SalesCoordinators_M_PaymentMethodViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PeriodOfSubmittedBSViewModel = "AutoLoanPersonal_SalesCoordinators_M_PeriodOfSubmittedBSViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_DistrictViewModel = "AutoLoanPersonal_SalesCoordinators_M_DistrictViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_PositionViewModel = "AutoLoanPersonal_SalesCoordinators_M_PositionViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarMarkerBrandViewModel = "AutoLoanPersonal_SalesCoordinators_M_CarMarkerBrandViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarModelViewModel = "AutoLoanPersonal_SalesCoordinators_M_CarModelViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CarTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarSourceViewModel = "AutoLoanPersonal_SalesCoordinators_M_CarSourceViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CarDealerViewModel = "AutoLoanPersonal_SalesCoordinators_M_CarDealerViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_NationalityViewModel = "AutoLoanPersonal_SalesCoordinators_M_NationalityViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_ResidenceOwnershipViewModel = "AutoLoanPersonal_SalesCoordinators_M_ResidenceOwnershipViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_CurrentResidentTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_CurrentResidentTypeViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_MaritalStatusViewModel = "AutoLoanPersonal_SalesCoordinators_M_MaritalStatusViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_EducationViewModel = "AutoLoanPersonal_SalesCoordinators_M_EducationViewModel";
        const string AutoLoanPersonal_SalesCoordinators_M_IdentificationTypeViewModel = "AutoLoanPersonal_SalesCoordinators_M_IdentificationTypeViewModel";

        #endregion

        // GET: SCMaker
        [ExceptionHandler]
        public async Task<ActionResult> Index(int? ApplicationInformationID = 1030)
        {
            // Params call service
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            SalesCoordinatorsViewModel obj = new SalesCoordinatorsViewModel();
            obj._ApplicationInformationViewModel.ApplicationInformationID = ApplicationInformationID.Value;

            // Call service
            obj = await _SalesCoordinatorsService.LoadIndex(obj, area, controller, User.Identity.Name);

            // Set session for meta data (data for datasource combobox & combobox grid)
            Session[AutoLoanPersonal_SalesCoordinators_M_ProductViewModel] = obj._M_ProductViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_ProgramTypeViewModel] = obj._M_ProgramTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PaymentTypeViewModel] = obj._M_PaymentTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PropertySaleViewModel] = obj._M_PropertySaleViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PropertyStatusViewModel] = obj._M_PropertyStatusViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PropertyTypeViewModel] = obj._M_PropertyTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_StatusViewModel] = obj._M_StatusViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_TradingAreaViewModel] = obj._M_TradingAreaViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_TypeViewModel] = obj._M_TypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_BranchCodeViewModel] = obj._M_BranchCodeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_BranchLocationViewModel] = obj._M_BranchLocationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_LoanPurposeViewModel] = obj._M_LoanPurposeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_LoanTenorViewModel] = obj._M_LoanTenorViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_FloatingInterestRateViewModel] = obj._M_FloatingInterestRateViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CustomerTypeViewModel] = obj._M_CustomerTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_SalesChannelViewModel] = obj._M_SalesChannelViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CustomerSegmentViewModel] = obj._M_CustomerSegmentViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_ReasonViewModel] = obj._M_ReasonViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CDDViewModel] = obj._M_CDDViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CicViewModel] = obj._M_CicViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CityViewModel] = obj._M_CityViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CompanyTypeViewModel] = obj._M_CompanyTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_BusinessNatureViewModel] = obj._M_BusinessNatureViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_BusinessTypeViewModel] = obj._M_BusinessTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_BorrowerTypeViewModel] = obj._M_BorrowerTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_IndustryViewModel] = obj._M_IndustryViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_OccupationViewModel] = obj._M_OccupationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_EmploymentTypeViewModel] = obj._M_EmploymentTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_LabourContractTypeViewModel] = obj._M_LabourContractTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_IncomeTypeViewModel] = obj._M_IncomeTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CreditBureauTypeViewModel] = obj._M_CreditBureauTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CampaignCodeViewModel] = obj._M_CampaignCodeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CreditDeviationViewModel] = obj._M_CreditDeviationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CustomerRelationshipViewModel] = obj._M_CustomerRelationshipViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CompanyCodeViewModel] = obj._M_CompanyCodeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarRepaymentCycle] = obj._M_CarRepaymentCycle;
            Session[AutoLoanPersonal_SalesCoordinators_M_HouseRepaymentCycle] = obj._M_HouseRepaymentCycle;
            Session[AutoLoanPersonal_SalesCoordinators_M_PaymentMethodViewModel] = obj._M_PaymentMethodViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PeriodOfSubmittedBSViewModel] = obj._M_PeriodOfSubmittedBSViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_DistrictViewModel] = obj._M_DistrictViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_PositionViewModel] = obj._M_PositionViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarMarkerBrandViewModel] = obj._M_CarMarkerBrandViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarModelViewModel] = obj._M_CarModelViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarTypeViewModel] = obj._M_CarTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarSourceViewModel] = obj._M_CarSourceViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CarDealerViewModel] = obj._M_CarDealerViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_NationalityViewModel] = obj._M_NationalityViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_ResidenceOwnershipViewModel] = obj._M_ResidenceOwnershipViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_CurrentResidentTypeViewModel] = obj._M_CurrentResidentTypeViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_MaritalStatusViewModel] = obj._M_MaritalStatusViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_EducationViewModel] = obj._M_EducationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_M_IdentificationTypeViewModel] = obj._M_IdentificationTypeViewModel;

            // Set session for grid
            Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid] = obj._ApplicationInformationViewModel._ApplicationDuplicationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid] = obj._CarSalesInformationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1._LoanBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1._CardBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2._LoanBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2._CardBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3._LoanBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3._CardBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main._LoanBureauViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid] = obj._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main._CardBureauViewModel; ;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co1_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_5._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co1_Income_6._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co1_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co1_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co1_Income_1._CustomerBonusMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co1_Income_2._CustomerBonusMonthlyViewModel; ;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co1_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co2_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co2_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_5._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co2_Income_6._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co2_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co2_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co2_Income_1._CustomerBonusMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co2_Income_2._CustomerBonusMonthlyViewModel; ;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co2_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co3_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Co3_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_5._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Co3_Income_6._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co3_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Co3_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co3_Income_1._CustomerBonusMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co3_Income_2._CustomerBonusMonthlyViewModel; ;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Co3_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Main_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._CarRentalIncomeViewModel_Main_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_5._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid] = obj._CustomerIncomeViewModel._HouseRentalIncomeViewModel_Main_Income_6._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Main_Income_3._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid] = obj._CustomerIncomeViewModel._OtherIncomeViewModel_Main_Income_4._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Main_Income_1._CustomerBonusMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Main_Income_2._CustomerBonusMonthlyViewModel; ;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid] = obj._CustomerIncomeViewModel._SalariedClientIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_1._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_EligibleCredit;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel_IGMVAT;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalCredit;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid] = obj._CustomerIncomeViewModel._SelfEmployedIncomeViewModel_Main_Income_2._CustomerIncomeMonthlyViewModel_IGMBankStatement_TotalLoan;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid] = obj._CustomerInformationViewModel._CustomerDetailViewModel_Co1._CustomerIdentificationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid] = obj._CustomerInformationViewModel._CustomerDetailViewModel_Co2._CustomerIdentificationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid] = obj._CustomerInformationViewModel._CustomerDetailViewModel_Co2._CustomerIdentificationViewModel;
            Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid] = obj._CustomerInformationViewModel._CustomerDetailViewModel_Main._CustomerIdentificationViewModel;

            return View("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/SalesCoordinators.cshtml", obj);
        }

        #region ApplicationInput_DeduplicateGrid
        public ActionResult ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }
        public ActionResult ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_ApplicationInput_DeduplicateGrid]);
        }

        #endregion

        #region CustomersInformation

        #region MainBorrower_IdentifyCationGrid
        public ActionResult MainBorrower_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }

            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.PlaceOfIssuance = item.PlaceOfIssuance;
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.NationalityID = item.NationalityID;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }

            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        public ActionResult MainBorrower_IdentifyCationGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }

            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_MainBorrower_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_IdentifyCationGrid]);
        }
        #endregion

        #region CoBorrower1_IdentifyCationGrid
        public ActionResult CoBorrower1_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.PlaceOfIssuance = item.PlaceOfIssuance;
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.NationalityID = item.NationalityID;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower1_IdentifyCationGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower1_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_IdentifyCationGrid]);
        }
        #endregion

        #region CoBorrower2_IdentifyCationGrid
        public ActionResult CoBorrower2_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower2_IdentifyCationGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower2_IdentifyCationGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.PlaceOfIssuance = item.PlaceOfIssuance;
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.NationalityID = item.NationalityID;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower2_IdentifyCationGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower2_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_IdentifyCationGrid]);
        }
        #endregion

        #region CoBorrower3_IdentifyCationGrid
        public ActionResult CoBorrower3_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.PlaceOfIssuance = item.PlaceOfIssuance;
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.NationalityID = item.NationalityID;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        public ActionResult CoBorrower3_IdentifyCationGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersInformation/_CoBorrower3_IdentifyCationGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_IdentifyCationGrid]);
        }
        #endregion

        #endregion

        #region CustomersIncome

        #region MainBorrower

        #region SalariedClient

        #region Income1
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_MonthlyInComeGrid]);
        }


        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income1_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income1_BonusGrid]);
        }
        #endregion

        #region Income2
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_MonthlyInComeGrid]);
        }


        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult MainBorrower_SalariedClient_Income2_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SalariedClient_Income2_BonusGrid]);
        }
        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        public ActionResult MainBorrower_Other_Income4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult MainBorrower_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_IncomeGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_EligibleCreditInGrid]);
        }

        public ActionResult MainBorrower_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult MainBorrower_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        #endregion

        #endregion

        #region CoBorrower1

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income1_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower1_SalariedClient_Income2_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SalariedClient_Income2_BonusGrid]);
        }
        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower1_Other_Income4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_IncomeGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        #endregion

        #endregion

        #region CoBorrower2

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income1_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower2_SalariedClient_Income2_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SalariedClient_Income2_BonusGrid]);
        }
        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower2_Other_Income4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_IncomeGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        #endregion

        #endregion

        #region CoBorrower3

        #region SalariedClient

        #region Income1
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income1_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income1_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income1_BonusGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_MonthlyInComeGrid]);
        }


        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_AddNewRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_UpdateRow(CustomerBonusMonthlyViewModel item)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerBonusMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.BonusTypeID = item.BonusTypeID;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        public ActionResult CoBorrower3_SalariedClient_Income2_BonusGrid_DeleteRow(int? GUIID)
        {
            List<CustomerBonusMonthlyViewModel> listData = (List<CustomerBonusMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SalariedClient_Income2_BonusGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SalariedClient_Income2_BonusGrid]);
        }
        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome1_IncomeGrid]);
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome2_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome3_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome4_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome5_IncomeGrid]);
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        public ActionResult CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_HouseRentalIncome_RentalIncome6_IncomeGrid]);
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid]);
        }

        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income1_IncomeGrid]);
        }
        #endregion
        #region Income2
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income2_IncomeGrid]);
        }
        #endregion
        #region Income3
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income3_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income3_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income3_IncomeGrid]);
        }
        #endregion
        #region Income4
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        public ActionResult CoBorrower3_Other_Income4_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_Other_Income4_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_Other_Income4_IncomeGrid]);
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_IncomeGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid]);
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_IncomeGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_IncomeGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_IncomeGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid]);
        }

        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow(CustomerIncomeMonthlyViewModel item)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIncomeMonthlyViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.Monthly = item.Monthly;
                        modelItem.FirstTime = item.FirstTime;
                        modelItem.SecondTime = item.SecondTime;
                        modelItem.ThirdTime = item.ThirdTime;
                        modelItem.FourthTime = item.FourthTime;
                        modelItem.FifthTime = item.FifthTime;
                        modelItem.InputVerification = item.InputVerification;
                        modelItem.Remark = item.Remark;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }
        public ActionResult CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIncomeMonthlyViewModel> listData = (List<CustomerIncomeMonthlyViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersIncome/_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid]);
        }

        #endregion

        #endregion

        #endregion

        #region CustomersCreditBureau

        #region CoBorrower1
        public ActionResult CoBorrower1_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.initial_loan = item.initial_loan;
                        modelItem.fk_m_tenor_id = item.fk_m_tenor_id;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.outstanding = item.outstanding;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }
        public ActionResult CoBorrower1_CreditBureauGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditBureauGrid]);
        }

        public ActionResult CoBorrower1_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.outstanding = item.outstanding;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        public ActionResult CoBorrower1_CreditCardGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower1_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower1_CreditCardGrid]);
        }
        #endregion

        #region CoBorrower2
        public ActionResult CoBorrower2_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.initial_loan = item.initial_loan;
                        modelItem.fk_m_tenor_id = item.fk_m_tenor_id;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.outstanding = item.outstanding;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }
        public ActionResult CoBorrower2_CreditBureauGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditBureauGrid]);
        }

        public ActionResult CoBorrower2_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.outstanding = item.outstanding;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        public ActionResult CoBorrower2_CreditCardGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower2_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower2_CreditCardGrid]);
        }
        #endregion

        #region CoBorrower3
        public ActionResult CoBorrower3_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.initial_loan = item.initial_loan;
                        modelItem.fk_m_tenor_id = item.fk_m_tenor_id;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.outstanding = item.outstanding;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }
        public ActionResult CoBorrower3_CreditBureauGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditBureauGrid]);
        }

        public ActionResult CoBorrower3_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.outstanding = item.outstanding;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        public ActionResult CoBorrower3_CreditCardGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_CoBorrower3_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CoBorrower3_CreditCardGrid]);
        }
        #endregion

        #region MainBorrower
        public ActionResult MainBorrower_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.initial_loan = item.initial_loan;
                        modelItem.fk_m_tenor_id = item.fk_m_tenor_id;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.outstanding = item.outstanding;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }
        public ActionResult MainBorrower_CreditBureauGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditBureauGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditBureauGrid]);
        }

        public ActionResult MainBorrower_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_AddNewRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_UpdateRow(LoanBureauViewModel item)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    LoanBureauViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.is_scb_loan = item.is_scb_loan;
                        modelItem.secured_type = item.secured_type;
                        modelItem.group_loan_name = item.group_loan_name;
                        modelItem.outstanding = item.outstanding;
                        modelItem.interest_rate = item.interest_rate;
                        modelItem.emi = item.emi;
                        modelItem.is_auto_cal_emi = item.is_auto_cal_emi;
                        modelItem.source = item.source;
                        modelItem.bank = item.bank;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        public ActionResult MainBorrower_CreditCardGrid_DeleteRow(int? GUIID)
        {
            List<LoanBureauViewModel> listData = (List<LoanBureauViewModel>)Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CustomersCreditBureau/_MainBorrower_CreditCardGrid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_MainBorrower_CreditCardGrid]);
        }
        #endregion

        #endregion

        #region CarSalesInformation
        public ActionResult CarSalesInformation_Grid_Callback()
        {

            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_AddNewRow(CarSalesInformationViewModel item)
        {
            List<CarSalesInformationViewModel> listData = (List<CarSalesInformationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_UpdateRow(CarSalesInformationViewModel item)
        {
            List<CarSalesInformationViewModel> listData = (List<CarSalesInformationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CarSalesInformationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.CarSalesName = item.CarSalesName;
                        modelItem.PhoneNumber = item.PhoneNumber;
                    }
                    Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }

        public ActionResult CarSalesInformation_Grid_DeleteRow(int? GUIID)
        {
            List<CarSalesInformationViewModel> listData = (List<CarSalesInformationViewModel>)Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/AutoLoanPersonal/Views/SalesCoordinators/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml", Session[AutoLoanPersonal_SalesCoordinators_CarSalesInformation_Grid]);
        }
        #endregion


    }
}
