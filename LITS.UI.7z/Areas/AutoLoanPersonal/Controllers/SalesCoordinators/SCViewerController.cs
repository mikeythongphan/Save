﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.UI.Custom;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
using LITS.Interface.Service.Management;


#region Interface

using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Interface.Service.AutoLoan.SalesCoordinators;

#endregion 

#region Service

using LITS.Service.AutoLoan.SalesCoordinators;

#endregion

#region Model

using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;

#endregion

namespace LITS.UI.Areas.AutoLoanPersonal.Controllers
{
    [Authorize]
    public class SCViewerController : BaseController
    {
        private readonly ISalesCoordinatorsService salesCoordinatorsService;
        private readonly IApplicationInformationService applicationInformationService;
        private readonly ICustomerInformationService customerInformationService;

        public SCViewerController(ISalesCoordinatorsService _salesCoordinatorsService,
            IApplicationInformationService _applicationInformationService,
            ICustomerInformationService _customerInformationService,
            IUnitOfWorkManager unitOfWorkManager, IMessageService messageService)
            : base(unitOfWorkManager, messageService)
        {
            this.salesCoordinatorsService = _salesCoordinatorsService;
            this.applicationInformationService = _applicationInformationService;
            this.customerInformationService = _customerInformationService;
        }
    }
}
