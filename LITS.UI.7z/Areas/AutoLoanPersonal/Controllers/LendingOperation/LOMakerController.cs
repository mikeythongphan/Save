﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Service.Management;


#region Infrastructure
using LITS.UI.Custom;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
#endregion

#region Interface

using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Interface.Service.AutoLoan.LendingOperation;

#endregion 

#region Service

using LITS.Service.AutoLoan.LendingOperation;

#endregion

#region Model

using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.AutoLoan;

#endregion

namespace LITS.UI.Areas.AutoLoanPersonal.Controllers
{
    [Authorize]
    public class LOMakerController : BaseController
    {
        private readonly ILendingOperationService _LendingOperationService;
        private readonly IDisbursementInformationService _DisbursementInformationService;
        private readonly IDisbursementService _DisbursementService;
        private readonly IInsuranceService _InsuranceService;
        private readonly IPersonalDetailService _PersonalDetailService;
        private readonly IPostDisbursementConditionService _PostDisbursementConditionService;
        private readonly IPropertyInformationService _PropertyInformationService;        

        public LOMakerController(ILendingOperationService LendingOperationService,
            IDisbursementInformationService DisbursementInformationService,
            IDisbursementService DisbursementService,
            IInsuranceService InsuranceService,
            IPersonalDetailService PersonalDetailService,
            IPostDisbursementConditionService PostDisbursementConditionService,
            IPropertyInformationService PropertyInformationService,            
            IUnitOfWorkManager unitOfWorkManager, IMessageService messageService)
            : base(unitOfWorkManager, messageService)
        {
            this._LendingOperationService = LendingOperationService;
            this._DisbursementInformationService = DisbursementInformationService;
            this._DisbursementService = DisbursementService;
            this._InsuranceService = InsuranceService;
            this._PersonalDetailService = PersonalDetailService;
            this._PostDisbursementConditionService = PostDisbursementConditionService;
            this._PropertyInformationService = PropertyInformationService;            
        }

        #region Variables



        #endregion

        // GET: LOMaker
        [ExceptionHandler]
        public ActionResult Index(int? Id)
        {
            Id = 8;

            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            LendingOperationViewModel obj = new LendingOperationViewModel();

            obj._DisbursementInformationViewModel.ApplicationInformationID = (int)Id;

            //Edit form
            if (Id.HasValue && Id > 0)
            {
                obj = _LendingOperationService.LoadIndex(obj, area, controller, User.Identity.Name);                
            }
            //New form
            else
            {
                obj = new LendingOperationViewModel();                
            }

            return View("~/Areas/AutoLoanPersonal/Views/LendingOperation/LendingOperation.cshtml", obj);
        }
    }
}
