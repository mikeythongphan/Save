﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LITS.UI.Areas.Main.Controllers.CreateNewLoan
{
    public class FRMWorkInProgressMasterController : Controller
    {
        // GET: Main/CreateNewLoanMaster
        public ActionResult Index()
        {
            return View();
        }
    }
}