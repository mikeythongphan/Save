﻿using LITS.Infrastructure.Configuration;
using LITS.Interface.Service.Main.ReportsChart;
using LITS.UI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Service.Management;

namespace LITS.UI.Areas.Main.Controllers
{
    [Authorize]
    public class ReportsChartMakerController : BaseController
    {
        // GET: ReportsChartMaker
        private readonly IReportsChartService _ReportsChartService;

        public ReportsChartMakerController(IUnitOfWorkManager unitOfWorkManager, IMessageService messageService,
            IReportsChartService reportsChartService)
            : base(unitOfWorkManager, messageService)
        {
            this._ReportsChartService = reportsChartService;
        }

        #region Variables
        const string ReportsChart_TreeList = "ReportsChart_TreeList";
        const string ReportsChart_Detail_Grid = "ReportsChart_Detail_Grid";
        const string cbCustomerName_ReportsChart = "cbCustomerName_ReportsChart";
        const string cbCompanyName_ReportsChart = "cbCompanyName_ReportsChart";
        #endregion

        public ActionResult Index()
        {
            LITS.Model.Views.Main.ReportsChartViewModel obj = new Model.Views.Main.ReportsChartViewModel();
            obj = _ReportsChartService.LoadIndex();
            Session[ReportsChart_TreeList] = obj._ReportsChartTreeViewModel;
            Session[ReportsChart_Detail_Grid] = null;
            Session[cbCustomerName_ReportsChart] = obj._ReportsChartMasterViewModel._ReportsChartMasterCustomerViewModel;
            Session[cbCompanyName_ReportsChart] = obj._ReportsChartMasterViewModel._ReportsChartMasterCompanyViewModel;
            return View("~/Areas/Main/Views/ReportsChart/ReportsChart.cshtml", obj);
        }

        public ActionResult ReportsChart_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/ReportsChart/PartialViews/_TreeList.cshtml", Session[ReportsChart_TreeList]);
        }

        public ActionResult ReportsChart_Detail_Grid_Callback(string treeListSelected, DateTime? fromDate, DateTime? toDate,
            int? status, string applicationNo, string customerName, string companyName)
        {

            return PartialView("~/Areas/Main/Views/ReportsChart/PartialViews/_Detail_Grid.cshtml", Session[ReportsChart_Detail_Grid]);
        }
    }
}