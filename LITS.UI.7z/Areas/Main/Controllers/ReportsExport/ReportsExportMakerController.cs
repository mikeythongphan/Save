﻿using LITS.Infrastructure.Configuration;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.UI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Service.Management;

namespace LITS.UI.Areas.Main.Controllers
{
    [Authorize]
    public class ReportsExportMakerController : BaseController
    {
        // GET: ReportsExportMaker
        private readonly IReportsExportService _ReportsExportService;

        public ReportsExportMakerController(IUnitOfWorkManager unitOfWorkManager, IMessageService messageService,
            IReportsExportService ReportsExportService)
          : base(unitOfWorkManager, messageService)
        {
            this._ReportsExportService = ReportsExportService;
        }

        #region Variables
        const string ReportsExport_TreeList = "ReportsExport_TreeList";
        const string ReportsExport_Detail_Grid = "ReportsExport_Detail_Grid";
        const string cbCustomerName_ReportsExport = "cbCustomerName_ReportsExport";
        const string cbCompanyName_ReportsExport = "cbCompanyName_ReportsExport";
        #endregion

        public ActionResult Index()
        {
            LITS.Model.Views.Main.ReportsExportViewModel obj = new Model.Views.Main.ReportsExportViewModel();
            obj = _ReportsExportService.LoadIndex();
            Session[ReportsExport_TreeList] = obj._ReportsExportTreeViewModel;
            Session[ReportsExport_Detail_Grid] = null;
            Session[cbCustomerName_ReportsExport] = obj._ReportsExportMasterViewModel._ReportsExportMasterCustomerViewModel;
            Session[cbCompanyName_ReportsExport] = obj._ReportsExportMasterViewModel._ReportsExportMasterCompanyViewModel;
            return View("~/Areas/Main/Views/ReportsExport/ReportsExport.cshtml", obj);
        }

        public ActionResult ReportsExport_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/ReportsExport/PartialViews/_TreeList.cshtml", Session[ReportsExport_TreeList]);
        }

        public ActionResult ReportsExport_Detail_Grid_Callback(string treeListSelected, DateTime? fromDate, DateTime? toDate,
            int? status, string applicationNo, string customerName, string companyName)
        {

            return PartialView("~/Areas/Main/Views/ReportsExport/PartialViews/_Detail_Grid.cshtml", Session[ReportsExport_Detail_Grid]);
        }



    }
}