﻿using LITS.Infrastructure.Configuration;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.UI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LITS.UI.Areas.Main.Controllers
{
    public class ReportsExportMakerController : Controller
    {
        // GET: Main/Maker

        private readonly IReportsExportService _ReportsExportService;

        public ReportsExportMakerController(IUnitOfWorkManager unitOfWorkManager,
            IReportsExportService ReportsExportService)
        //  : base(unitOfWorkManager)
        {
            this._ReportsExportService = ReportsExportService;
        }


        #region Variables
        const string ReportsExport_TreeList = "ReportsExport_TreeList";
        const string ReportsExport_Detail_Grid = "ReportsExport_Detail_Grid";
        const string cbCustomerName_ReportsExport = "cbCustomerName_ReportsExport";
        const string cbCompanyName_ReportsExport = "cbCompanyName_ReportsExport";
        #endregion
        public ActionResult Index()
        {
            LITS.Model.Views.Main.ReportsExportViewModel obj = new Model.Views.Main.ReportsExportViewModel();
            obj = _ReportsExportService.LoadIndex();
            Session[ReportsExport_TreeList] = obj._ReportsExportTreeViewModel;
            Session[ReportsExport_Detail_Grid] = null;
            Session[cbCustomerName_ReportsExport] = obj._ReportsExportMasterViewModel._ReportsExportMasterCustomerViewModel;
            Session[cbCompanyName_ReportsExport] = obj._ReportsExportMasterViewModel._ReportsExportMasterCompanyViewModel;
            return View("~/Areas/Main/Views/ReportsExport/ReportsExport.cshtml", obj);
        }
        public ActionResult ReportsExport_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/ReportsExport/PartialViews/_TreeList.cshtml", Session[ReportsExport_TreeList]);
        }
        public ActionResult ReportsExport_Detail_Grid_Callback(string treeListSelected, DateTime? fromDate, DateTime? toDate,
            int? status, string applicationNo, string customerName, string companyName)
        {
            //if (!string.IsNullOrEmpty(treeListSelected) || fromDate.HasValue || toDate.HasValue
            //    || status.HasValue || !string.IsNullOrEmpty(applicationNo) || !string.IsNullOrEmpty(customerName) || !string.IsNullOrEmpty(companyName))
            //{
            //    // Select TreeList
            //    List<WorkInProgressTreeViewModel> _WorkInProgressTreeViewModel = new List<WorkInProgressTreeViewModel>();
            //    foreach (var s in treeListSelected.Split(','))
            //    {
            //        _WorkInProgressTreeViewModel.Add(new WorkInProgressTreeViewModel()
            //        {
            //            ID = Convert.ToInt32(s)
            //        });
            //    };

            //    // Master Select Field
            //    WorkInProgressMasterViewModel _WorkInProgressMasterViewModel = new WorkInProgressMasterViewModel()
            //    {
            //        FromDate = fromDate,
            //        ToDate = toDate,
            //        StatusID = status,
            //        ApplicationNo = applicationNo,
            //        CustomerName = customerName,
            //        CompanyName = companyName
            //    };

            //    // obj for params function search data
            //    LITS.Model.Views.Main.WorkInProgressViewModel obj = new Model.Views.Main.WorkInProgressViewModel()
            //    {
            //        _WorkInProgressMasterViewModel = _WorkInProgressMasterViewModel,
            //        _WorkInProgressTreeViewModel = _WorkInProgressTreeViewModel
            //    };

            //    // Call function search data
            //    var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            //    var controller = ControllerContext.RouteData.Values["controller"].ToString();

            //    LITS.Model.Views.Main.WorkInProgressViewModel data = new Model.Views.Main.WorkInProgressViewModel();
            //    data = _WorkInProgressService.SearchData(obj, area, controller);

            //    Session[WorkInProgress_Detail_Grid] = data._WorkInProgressDetailViewModel;
            //}

            return PartialView("~/Areas/Main/Views/ReportsExport/PartialViews/_Detail_Grid.cshtml", Session[ReportsExport_Detail_Grid]);
        }
    }
}