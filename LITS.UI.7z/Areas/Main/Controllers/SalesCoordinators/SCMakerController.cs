﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Service.Main.SalesCoordinators;
using LITS.Model.Views.Main;
using LITS.Infrastructure.Configuration;


namespace LITS.UI.Areas.Main.Controllers
{
    public class SCMakerController : Controller
    {
        private readonly ISalesCoordinatorsService salesCoordinatorsService;
        private readonly IApplicationInformationService applicationInformationService;
        private readonly ICustomerInformationService customerInformationService;

        public SCMakerController(ISalesCoordinatorsService _salesCoordinatorsService,
            IApplicationInformationService _applicationInformationService,
            ICustomerInformationService _customerInformationService,
            IUnitOfWorkManager unitOfWorkManager) 
            //: base(unitOfWorkManager)
        {
            this.salesCoordinatorsService = _salesCoordinatorsService;
            this.applicationInformationService = _applicationInformationService;
            this.customerInformationService = _customerInformationService;
        }

        // GET: Maker
        public ActionResult Index()
        {
            SalesCoordinatorsViewModel obj = new SalesCoordinatorsViewModel();
            var app = applicationInformationService.GetAll();
            var cust = customerInformationService.GetAll();

            obj.applicationInformationViewModel.Add(app);
            obj.customerInformationViewModel.Add(cust);

            return View("~/Views/Main/SalesCoordinators/SalesCoordinatorsView.cshtml", obj);            
        }

        // GET: Maker/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Maker/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Maker/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Maker/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Maker/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Maker/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Maker/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
