﻿using LITS.Model.PartialViews.Main.CreateNewLoan;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Common;
using LITS.Interface.Service.Main.CreateNewLoan;
using Newtonsoft.Json;
using LITS.Model.Domain.Main;
using LITS.Interface.Service.Management;


namespace LITS.UI.Areas.Main.Controllers
{
    [Authorize]
    public class CreateNewLoanMakerController : BaseController
    {
        private readonly ICreateNewLoanService _CreateNewLoanService;

        public CreateNewLoanMakerController(IUnitOfWorkManager unitOfWorkManager, IMessageService messageService,
            ICreateNewLoanService createNewLoanService)
            : base(unitOfWorkManager, messageService)
        {
            this._CreateNewLoanService = createNewLoanService;
        }


        #region Variables
        // Step1
        const string CreateNewLoan_TreeList = "CreateNewLoan_TreeList";
        // Step2
        const string Step2_CoBorrower1_CompanyGrid = "Step2_CoBorrower1_CompanyGrid";
        const string Step2_CoBorrower1_IdentifiGrid = "Step2_CoBorrower1_IdentifiGrid";
        const string Step2_CoBorrower2_CompanyGrid = "Step2_CoBorrower2_CompanyGrid";
        const string Step2_CoBorrower2_IdentifiGrid = "Step2_CoBorrower2_IdentifiGrid";
        const string Step2_CoBorrower3_CompanyGrid = "Step2_CoBorrower3_CompanyGrid";
        const string Step2_CoBorrower3_IdentifiGrid = "Step2_CoBorrower3_IdentifiGrid";
        const string Step2_Corporate_IdentifiGrid = "Step2_Corporate_IdentifiGrid";
        const string Step2_MainBorrower_CompanyGrid = "Step2_MainBorrower_CompanyGrid";
        const string Step2_MainBorrower_IdentifiGrid = "Step2_MainBorrower_IdentifiGrid";

        const string Step2_M_IdentificationTypeViewModel = "Step2_M_IdentificationTypeViewModel";
        const string Step2_M_CompanyTypeViewModel = "Step2_M_CompanyTypeViewModel";
        const string Step2_M_DistrictViewModel = "Step2_M_DistrictViewModel";
        const string Step2_M_CityViewModel = "Step2_M_CityViewModel";
        const string Step2_M_NationalityViewModel = "Step2_M_NationalityViewModel";
        const string Step2_M_InitialViewModel = "Step2_M_InitialViewModel";
        const string Step2_M_CustomerRelationshipViewModel = "Step2_M_CustomerRelationshipViewModel";
        // Step3
        const string Step3_Content = "Step3_Content";
        const string Step3_CompanyGrid = "Step3_CompanyGrid";
        const string Step3_DeDuplicateGrid = "Step3_DeDuplicateGrid";
        const string Step3_IdentifiGrid = "Step3_IdentifiGrid";

        const string Step3_M_IdentificationTypeViewModel = "Step3_M_IdentificationTypeViewModel";
        const string Step3_M_CompanyTypeViewModel = "Step3_M_CompanyTypeViewModel";
        const string Step3_M_ApplicationTypeViewModel = "Step3_M_ApplicationTypeViewModel";
        const string Step3_M_NationalityViewModel = "Step3_M_NationalityViewModel";


        #endregion

        #region Index
        // GET: CreateNewLoanMaker
        public async Task<ActionResult> Index()
        {
            // Call service
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();
            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();
            obj = await _CreateNewLoanService.LoadIndexStep1(obj, area, controller, User.Identity.Name);

            // Set Session data grid
            // Step1
            Session[CreateNewLoan_TreeList] = obj._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree;
            // Step2
            Session[Step2_CoBorrower1_CompanyGrid] = null;
            Session[Step2_CoBorrower1_IdentifiGrid] = null;
            Session[Step2_CoBorrower2_CompanyGrid] = null;
            Session[Step2_CoBorrower2_IdentifiGrid] = null;
            Session[Step2_CoBorrower3_CompanyGrid] = null;
            Session[Step2_CoBorrower3_IdentifiGrid] = null;
            Session[Step2_Corporate_IdentifiGrid] = null;
            Session[Step2_MainBorrower_CompanyGrid] = null;
            Session[Step2_MainBorrower_IdentifiGrid] = null;
            // Step3
            Session[Step3_Content] = null;
            Session[Step3_CompanyGrid] = null;
            Session[Step3_DeDuplicateGrid] = null;
            Session[Step3_IdentifiGrid] = null;

            // Set Session data combo grid
            // Step2
            Session[Step2_M_IdentificationTypeViewModel] = null;
            Session[Step2_M_CompanyTypeViewModel] = null;
            Session[Step2_M_DistrictViewModel] = null;
            Session[Step2_M_CityViewModel] = null;
            Session[Step2_M_NationalityViewModel] = null;
            Session[Step2_M_InitialViewModel] = null;
            Session[Step2_M_CustomerRelationshipViewModel] = null;
            // Step3
            Session[Step3_M_IdentificationTypeViewModel] = null;
            Session[Step3_M_CompanyTypeViewModel] = null;
            Session[Step3_M_ApplicationTypeViewModel] = null;
            Session[Step3_M_NationalityViewModel] = null;

            return View("~/Areas/Main/Views/CreateNewLoan/CreateNewLoan.cshtml", obj);
        }

        #endregion

        #region Grid
        #region CreateNewLoan_TreeList
        public ActionResult CreateNewLoan_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step1_TreeList.cshtml", Session[CreateNewLoan_TreeList]);
        }
        #endregion

        #region Step2_CoBorrower1_CompanyGrid
        public ActionResult Step2_CoBorrower1_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_CompanyGrid.cshtml", Session[Step2_CoBorrower1_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower1_CompanyGrid_AddNewRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower1_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower1_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_CompanyGrid.cshtml", Session[Step2_CoBorrower1_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower1_CompanyGrid_UpdateRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower1_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CompanyInformationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.CompanyName = item.CompanyName;
                        modelItem.CompanyCode = item.CompanyCode;
                        modelItem.CompanyCAT = item.CompanyCAT;
                        modelItem.CompanyTypeID = item.CompanyTypeID;
                    }
                    Session[Step2_CoBorrower1_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_CompanyGrid.cshtml", Session[Step2_CoBorrower1_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower1_CompanyGrid_DeleteRow(int? GUIID)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower1_CompanyGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower1_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_CompanyGrid.cshtml", Session[Step2_CoBorrower1_CompanyGrid]);
        }

        #endregion

        #region Step2_CoBorrower1_IdentifiGrid
        public ActionResult Step2_CoBorrower1_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_IdentifiGrid.cshtml", Session[Step2_CoBorrower1_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower1_IdentifiGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower1_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower1_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_IdentifiGrid.cshtml", Session[Step2_CoBorrower1_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower1_IdentifiGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower1_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.Nationality = item.Nationality;
                    }
                    Session[Step2_CoBorrower1_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_IdentifiGrid.cshtml", Session[Step2_CoBorrower1_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower1_IdentifiGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower1_IdentifiGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower1_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_IdentifiGrid.cshtml", Session[Step2_CoBorrower1_IdentifiGrid]);
        }
        #endregion

        #region Step2_CoBorrower2_CompanyGrid
        public ActionResult Step2_CoBorrower2_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_CompanyGrid.cshtml", Session[Step2_CoBorrower2_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower2_CompanyGrid_AddNewRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower2_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower2_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_CompanyGrid.cshtml", Session[Step2_CoBorrower2_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower2_CompanyGrid_UpdateRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower2_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CompanyInformationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.CompanyName = item.CompanyName;
                        modelItem.CompanyCode = item.CompanyCode;
                        modelItem.CompanyCAT = item.CompanyCAT;
                        modelItem.CompanyTypeID = item.CompanyTypeID;
                    }
                    Session[Step2_CoBorrower2_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_CompanyGrid.cshtml", Session[Step2_CoBorrower2_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower2_CompanyGrid_DeleteRow(int? GUIID)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower2_CompanyGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower2_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_CompanyGrid.cshtml", Session[Step2_CoBorrower2_CompanyGrid]);
        }
        #endregion

        #region Step2_CoBorrower2_IdentifiGrid
        public ActionResult Step2_CoBorrower2_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_IdentifiGrid.cshtml", Session[Step2_CoBorrower2_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower2_IdentifiGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower2_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower2_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_IdentifiGrid.cshtml", Session[Step2_CoBorrower2_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower2_IdentifiGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower2_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.Nationality = item.Nationality;
                    }
                    Session[Step2_CoBorrower2_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_IdentifiGrid.cshtml", Session[Step2_CoBorrower2_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower2_IdentifiGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower2_IdentifiGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower2_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_IdentifiGrid.cshtml", Session[Step2_CoBorrower2_IdentifiGrid]);
        }
        #endregion

        #region Step2_CoBorrower3_CompanyGrid
        public ActionResult Step2_CoBorrower3_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_CompanyGrid.cshtml", Session[Step2_CoBorrower3_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower3_CompanyGrid_AddNewRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower3_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower3_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_CompanyGrid.cshtml", Session[Step2_CoBorrower3_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower3_CompanyGrid_UpdateRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower3_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CompanyInformationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.CompanyName = item.CompanyName;
                        modelItem.CompanyCode = item.CompanyCode;
                        modelItem.CompanyCAT = item.CompanyCAT;
                        modelItem.CompanyTypeID = item.CompanyTypeID;
                    }
                    Session[Step2_CoBorrower3_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_CompanyGrid.cshtml", Session[Step2_CoBorrower3_CompanyGrid]);
        }

        public ActionResult Step2_CoBorrower3_CompanyGrid_DeleteRow(int? GUIID)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower3_CompanyGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower3_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_CompanyGrid.cshtml", Session[Step2_CoBorrower3_CompanyGrid]);
        }
        #endregion

        #region Step2_CoBorrower3_IdentifiGrid
        public ActionResult Step2_CoBorrower3_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_IdentifiGrid.cshtml", Session[Step2_CoBorrower3_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower3_IdentifiGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower3_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_CoBorrower3_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_IdentifiGrid.cshtml", Session[Step2_CoBorrower3_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower3_IdentifiGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower3_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.Nationality = item.Nationality;
                    }
                    Session[Step2_CoBorrower3_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_IdentifiGrid.cshtml", Session[Step2_CoBorrower3_IdentifiGrid]);
        }

        public ActionResult Step2_CoBorrower3_IdentifiGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower3_IdentifiGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_CoBorrower3_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_IdentifiGrid.cshtml", Session[Step2_CoBorrower3_IdentifiGrid]);
        }
        #endregion

        #region Step2_Corporate_IdentifiGrid
        public ActionResult Step2_Corporate_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_Corporate_IdentifiGrid.cshtml", Session[Step2_Corporate_IdentifiGrid]);
        }

        public ActionResult Step2_Corporate_IdentifiGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_Corporate_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_Corporate_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_Corporate_IdentifiGrid.cshtml", Session[Step2_Corporate_IdentifiGrid]);
        }

        public ActionResult Step2_Corporate_IdentifiGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_Corporate_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.Nationality = item.Nationality;
                    }
                    Session[Step2_Corporate_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_Corporate_IdentifiGrid.cshtml", Session[Step2_Corporate_IdentifiGrid]);
        }

        public ActionResult Step2_Corporate_IdentifiGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_Corporate_IdentifiGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_Corporate_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_Corporate_IdentifiGrid.cshtml", Session[Step2_Corporate_IdentifiGrid]);
        }
        #endregion

        #region Step2_MainBorrower_CompanyGrid
        public ActionResult Step2_MainBorrower_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_CompanyGrid.cshtml", Session[Step2_MainBorrower_CompanyGrid]);
        }

        public ActionResult Step2_MainBorrower_CompanyGrid_AddNewRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_MainBorrower_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_MainBorrower_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_CompanyGrid.cshtml", Session[Step2_MainBorrower_CompanyGrid]);
        }

        public ActionResult Step2_MainBorrower_CompanyGrid_UpdateRow(CompanyInformationViewModel item)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_MainBorrower_CompanyGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CompanyInformationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.CompanyName = item.CompanyName;
                        modelItem.CompanyCode = item.CompanyCode;
                        modelItem.CompanyCAT = item.CompanyCAT;
                        modelItem.CompanyTypeID = item.CompanyTypeID;
                    }
                    Session[Step2_MainBorrower_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_CompanyGrid.cshtml", Session[Step2_MainBorrower_CompanyGrid]);
        }

        public ActionResult Step2_MainBorrower_CompanyGrid_DeleteRow(int? GUIID)
        {
            List<CompanyInformationViewModel> listData = (List<CompanyInformationViewModel>)Session[Step2_MainBorrower_CompanyGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_MainBorrower_CompanyGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_CompanyGrid.cshtml", Session[Step2_MainBorrower_CompanyGrid]);
        }
        #endregion

        #region Step2_MainBorrower_IdentifiGrid
        public ActionResult Step2_MainBorrower_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_IdentifiGrid.cshtml", Session[Step2_MainBorrower_IdentifiGrid]);
        }

        public ActionResult Step2_MainBorrower_IdentifiGrid_AddNewRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_MainBorrower_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    item.GUIID = (listData.Count > 0) ? listData.OrderByDescending(s => s.GUIID).FirstOrDefault().GUIID + 1 : 1;
                    listData.Add(item);

                    Session[Step2_MainBorrower_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_IdentifiGrid.cshtml", Session[Step2_MainBorrower_IdentifiGrid]);
        }

        public ActionResult Step2_MainBorrower_IdentifiGrid_UpdateRow(CustomerIdentificationViewModel item)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_MainBorrower_IdentifiGrid];
            if (listData != null)
            {
                if (ModelState.IsValid)
                {
                    CustomerIdentificationViewModel modelItem = listData.SingleOrDefault(x => x.GUIID == item.GUIID);
                    if (modelItem != null)
                    {
                        modelItem.IdentificationTypeID = item.IdentificationTypeID;
                        modelItem.IdentificationNo = item.IdentificationNo;
                        modelItem.IssuedDate = item.IssuedDate;
                        modelItem.ExpriedDate = item.ExpriedDate;
                        modelItem.Nationality = item.Nationality;
                    }
                    Session[Step2_MainBorrower_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid Value.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_IdentifiGrid.cshtml", Session[Step2_MainBorrower_IdentifiGrid]);
        }

        public ActionResult Step2_MainBorrower_IdentifiGrid_DeleteRow(int? GUIID)
        {
            List<CustomerIdentificationViewModel> listData = (List<CustomerIdentificationViewModel>)Session[Step2_MainBorrower_IdentifiGrid];
            if (listData != null)
            {
                if (GUIID.HasValue && GUIID > 0)
                {
                    listData.Remove(listData.SingleOrDefault(x => x.GUIID == GUIID));
                    Session[Step2_MainBorrower_IdentifiGrid] = listData;
                }
                else
                    ViewData["EditError"] = "Invalid ID.";
            }
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_IdentifiGrid.cshtml", Session[Step2_MainBorrower_IdentifiGrid]);
        }
        #endregion

        #region Step3_CompanyGrid
        public ActionResult Step3_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_CompanyGrid.cshtml", Session[Step3_CompanyGrid]);
        }


        #endregion

        #region Step3_DeDuplicateGrid
        public ActionResult Step3_DeDuplicateGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_DeDuplicateGrid.cshtml", Session[Step3_DeDuplicateGrid]);
        }


        #endregion

        #region Step3_IdentifiGrid
        public ActionResult Step3_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_IdentifiGrid.cshtml", Session[Step3_IdentifiGrid]);
        }


        #endregion

        #endregion

        #region CallbackPanel
        public async Task<ActionResult> cpStep2_Callback(int? nodeKeySelected, int? typeSelected)
        {
            // Params Call service
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();
            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();

            // Set CreateNewLoanStep1ViewModel
            obj._CreateNewLoanStep1ViewModel.ProductTypeID = nodeKeySelected;
            obj._CreateNewLoanStep1ViewModel.ApplicationTypeID = typeSelected;

            // Set CreateNewLoanStep2ViewModel
            obj._CreateNewLoanStep2ViewModel.ProductTypeID = nodeKeySelected;
            obj._CreateNewLoanStep2ViewModel.ApplicationTypeID = typeSelected;
            obj._CreateNewLoanStep2ViewModel.CreateDate = DateTime.Now;

            // Call Service
            obj = await _CreateNewLoanService.LoadIndexStep2(obj, area, controller, User.Identity.Name);

            // Set contain step3
            Session[Step3_Content] = null;
            // Set Session data grid
            Session[Step2_CoBorrower1_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo1;
            Session[Step2_CoBorrower1_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1;
            Session[Step2_CoBorrower2_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo2;
            Session[Step2_CoBorrower2_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2;
            Session[Step2_CoBorrower3_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo3;
            Session[Step2_CoBorrower3_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3;
            Session[Step2_Corporate_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationLegalRepresentative;
            Session[Step2_MainBorrower_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyMain;
            Session[Step2_MainBorrower_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain;

            // Set Session data combo grid
            Session[Step2_M_IdentificationTypeViewModel] = obj._CreateNewLoanStep2ViewModel._M_IdentificationTypeViewModel;
            Session[Step2_M_CompanyTypeViewModel] = obj._CreateNewLoanStep2ViewModel._M_CompanyTypeViewModel;
            Session[Step2_M_DistrictViewModel] = obj._CreateNewLoanStep2ViewModel._M_DistrictViewModel;
            Session[Step2_M_CityViewModel] = obj._CreateNewLoanStep2ViewModel._M_CityViewModel;
            Session[Step2_M_NationalityViewModel] = obj._CreateNewLoanStep2ViewModel._M_NationalityViewModel;
            Session[Step2_M_InitialViewModel] = obj._CreateNewLoanStep2ViewModel._M_InitialViewModel;
            Session[Step2_M_CustomerRelationshipViewModel] = obj._CreateNewLoanStep2ViewModel._M_CustomerRelationshipViewModel;

            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2.cshtml", obj);
        }

        public ActionResult cpStep3_Callback(int? nodeKeySelected, int? typeSelected)
        {
            var obj = (Model.Views.Main.CreateNewLoanViewModel)Session[Step3_Content];

            // Set Session data grid
            Session[Step3_CompanyGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3CompanyBlackList;
            Session[Step3_DeDuplicateGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3DuplicateViewModel;
            Session[Step3_IdentifiGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3CustomerBlackList;

            // Set Session data combo grid
            Session[Step3_M_IdentificationTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_IdentificationTypeViewModel;
            Session[Step3_M_CompanyTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_CompanyTypeViewModel;
            Session[Step3_M_ApplicationTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_ApplicationTypeViewModel;
            Session[Step3_M_NationalityViewModel] = obj._CreateNewLoanStep3ViewModel._M_NationalityViewModel;

            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3.cshtml", obj);
        }

        #endregion

        #region Submit
        // Step2 submit
        [HttpPost]
        public async Task<ActionResult> frmCreateNewLoanMaker_OnSubmit(Model.Views.Main.CreateNewLoanViewModel item)
        {
            // Params Call service
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            // Set CreateNewLoanStep3ViewModel
            item._CreateNewLoanStep3ViewModel.ProductTypeID = item._CreateNewLoanStep2ViewModel.ProductTypeID;
            item._CreateNewLoanStep3ViewModel.ApplicationTypeID = item._CreateNewLoanStep2ViewModel.ApplicationTypeID;
            item._CreateNewLoanStep3ViewModel.CreateDate = DateTime.Now;

            // Set model from session
            // Step2
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo1 = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower1_CompanyGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1 = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower1_IdentifiGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo2 = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower2_CompanyGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2 = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower2_IdentifiGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo3 = (List<CompanyInformationViewModel>)Session[Step2_CoBorrower3_CompanyGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3 = (List<CustomerIdentificationViewModel>)Session[Step2_CoBorrower3_IdentifiGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationLegalRepresentative = (List<CustomerIdentificationViewModel>)Session[Step2_Corporate_IdentifiGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyMain = (List<CompanyInformationViewModel>)Session[Step2_MainBorrower_CompanyGrid];
            item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain = (List<CustomerIdentificationViewModel>)Session[Step2_MainBorrower_IdentifiGrid];

            // Set Active for case
            // AL_Personal
            // Main-Borrower
            if (!string.IsNullOrEmpty(item._CreateNewLoanStep2ViewModel.CustomerNameMain))
            {
                item._CreateNewLoanStep2ViewModel.IsActiveMain = true;
            }

            // Co-Borrower 1
            if ((!string.IsNullOrEmpty(item._CreateNewLoanStep2ViewModel.CustomerNameCo1))
                || (item._CreateNewLoanStep2ViewModel.DateOfBirthCo1.HasValue)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo1.Count > 0)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1.Count > 0))
            {
                item._CreateNewLoanStep2ViewModel.IsActiveCo1 = true;
            }

            // Co-Borrower 2
            if ((!string.IsNullOrEmpty(item._CreateNewLoanStep2ViewModel.CustomerNameCo2))
                || (item._CreateNewLoanStep2ViewModel.DateOfBirthCo2.HasValue)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo2.Count > 0)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2.Count > 0))
            {
                item._CreateNewLoanStep2ViewModel.IsActiveCo2 = true;
            }

            // Co-Borrower 3
            if ((!string.IsNullOrEmpty(item._CreateNewLoanStep2ViewModel.CustomerNameCo3))
                || (item._CreateNewLoanStep2ViewModel.DateOfBirthCo3.HasValue)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo3.Count > 0)
                || (item._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3.Count > 0))
            {
                item._CreateNewLoanStep2ViewModel.IsActiveCo3 = true;
            }

            // AL_Corporate
            if (!string.IsNullOrEmpty(item._CreateNewLoanStep2ViewModel.CompanyName))
            {
                item._CreateNewLoanStep2ViewModel.IsActiveCompany = true;
                item._CreateNewLoanStep2ViewModel.IsActiveLegalRepresentative = true;
            }

            // Call Service
            item = await _CreateNewLoanService.Submit(item, area, controller, User.Identity.Name);
            // Set Session for step3
            Session[Step3_Content] = item;

            return Json(item._ReturnMessageViewModel);
        }


        #endregion




    }
}