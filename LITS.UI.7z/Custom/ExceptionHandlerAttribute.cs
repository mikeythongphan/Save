﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Infrastructure.Context;
using LITS.UI.Custom;

namespace LITS.UI.Custom
{
    public class ExceptionHandlerAttribute : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            if (!filterContext.ExceptionHandled)
            {
                var areaName = filterContext.RouteData.DataTokens.Keys.Contains("area") ? filterContext.RouteData.DataTokens["area"].ToString() : "";
                var controllerName = filterContext.RouteData.Values.Keys.Contains("controller") ? filterContext.RouteData.Values["controller"].ToString() : "";
                var actionName = filterContext.RouteData.Values.Keys.Contains("action") ? filterContext.RouteData.Values["action"].ToString() : "";
                ExceptionLogger logger = new ExceptionLogger()
                {
                    ExceptionMessage = filterContext.Exception.Message,
                    ExceptionStackTrace = filterContext.Exception.StackTrace,
                    ControllerName = controllerName,
                    ActionName = actionName,
                    AreaName = areaName,
                    ProcessesId = 4,                    
                    LogTime = DateTime.Now
                };

                ADCSEntities ctx = new ADCSEntities();
                ctx.ExceptionLoggers.Add(logger);
                ctx.SaveChanges();

                LogManager.LogError(string.Format(@"Area Name:[{0}],Controller Name:[{1}],Action Name:[{2}] Abnormal information",
                    logger.AreaName, logger.ControllerName, logger.ActionName), filterContext.Exception);

                filterContext.ExceptionHandled = true;
            }
        }
    }
}