﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.UI.Models;
using Microsoft.AspNet.Identity.Owin;
using System.Web.Routing;


namespace LITS.UI.Custom
{
    public class CustomActionFilterAttribute : ActionFilterAttribute
    {
        private const string CONTROLLER = "controller";
        private const string ACTION = "action";

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                if (HttpContext.Current.Session["LoginCredentials"] == null)
                {
                    HttpContext.Current.GetOwinContext().Authentication.SignOut();
                    HttpContext.Current.Session.Abandon();
                    filterContext.Result = new RedirectResult("~/");
                }
                else
                {
                    RouteValueDictionary routeValues = filterContext.RouteData.Values;
                    object areaName;
                    if (filterContext.RouteData.DataTokens.TryGetValue("area", out areaName))
                    {
                        //Case custom
                    }
                }
            }
            base.OnActionExecuting(filterContext);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            base.OnActionExecuted(filterContext);
        }

        public static string GetUserIPAddress()
        {
            var context = System.Web.HttpContext.Current;
            string ip = String.Empty;

            if (context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                ip = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
            else if (!String.IsNullOrWhiteSpace(context.Request.UserHostAddress))
                ip = context.Request.UserHostAddress;

            if (ip == "::1")
                ip = "127.0.0.1";

            return ip;
        }


    }

}